<?php

/**
 * Registers a new post type
 * @uses $wp_post_types Inserts new post type object into the list
 *
 * @param string  Post type key, must not exceed 20 characters
 * @param array|string  See optional args description above.
 * @return object|WP_Error the registered post type object, or an error object
 */
if ( !function_exists('saasmaxcore_portfolio') ) {
	function saasmaxcore_portfolio() {

		$labels = array(
			'name'               => esc_html__( 'Portfolios', 'saasmaxcore' ),
			'singular_name'      => esc_html__( 'Portfolio', 'saasmaxcore' ),
			'add_new'            => _x( 'Add New Portfolio', 'saasmaxcore', 'saasmaxcore' ),
			'add_new_item'       => esc_html__( 'Add New Portfolio', 'saasmaxcore' ),
			'edit_item'          => esc_html__( 'Edit Portfolio', 'saasmaxcore' ),
			'new_item'           => esc_html__( 'New Portfolio', 'saasmaxcore' ),
			'view_item'          => esc_html__( 'View Portfolio', 'saasmaxcore' ),
			'search_items'       => esc_html__( 'Search Portfolios', 'saasmaxcore' ),
			'not_found'          => esc_html__( 'No Portfolios found', 'saasmaxcore' ),
			'not_found_in_trash' => esc_html__( 'No Portfolios found in Trash', 'saasmaxcore' ),
			'parent_item_colon'  => esc_html__( 'Parent Portfolio:', 'saasmaxcore' ),
			'menu_name'          => esc_html__( 'Portfolios', 'saasmaxcore' ),
		);

		$args = array(
			'labels'              => $labels,
			'hierarchical'        => false,
			'description'         => 'description',
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 11,
			'menu_icon'           => 'dashicons-portfolio',
			'show_in_nav_menus'   => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => false,
			'has_archive'         => true,
			'query_var'           => true,
			'can_export'          => true,
			'rewrite'             => true,
			'capability_type'     => 'page',
			'supports'            => array(
				'title',
				'editor',
				'thumbnail',
				'revisions',
			),
		);

		register_post_type( 'portfolio', $args );
	}
}

add_action( 'init', 'saasmaxcore_portfolio' );

register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
register_activation_hook( __FILE__, 'saasmaxcore_flush_rewrites' );
function saasmaxcore_flush_rewrites() {
	saasmaxcore_portfolio();
	flush_rewrite_rules();
}