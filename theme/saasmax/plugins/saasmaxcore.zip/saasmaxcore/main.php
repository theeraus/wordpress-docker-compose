<?php 
/**
 * Plugin Name: SaasMax Core
 * Description: This is a helper plugin for SaasMax theme.
 * Plugin URI: http://quomodosoft.com/plugins
 * Author: Mehedi Hasan Nahid
 * Author URI: http://quomodosoft.com
 * Version: 1.0.0
 * License: GPL2
 * Text Domain: saasmaxcore
 */

/**
 * CONSTANT FOR DIR
 *  @param string $[name] name of the constant
 *  @param string directory url
 */
define('SAASMAXCORE_DIR', plugin_dir_url( __FILE__ ));
define('SAASMAXCORE_JS', plugins_url( '/assets/js', __FILE__ ));
define('SAASMAXCORE_CSS', plugins_url( '/assets/css', __FILE__ ));
define('SAASMAXCORE_IMG', plugins_url( '/assets/img', __FILE__ ));

/**
 * INITIALIZE
 */
if ( !defined('ABSPATH') ) {
	exit;
}
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

/**
 * ENQUEUE SCRIPTS
 *
 * @param string $handle Script name
 * @param string $src Script url
 * @param array $deps (optional) Array of script names on which this script depends
 * @param string|bool $ver (optional) Script version (used for cache busting), set to null to disable
 * @param bool $in_footer (optional) Whether to enqueue the script before </head> or before </body>
 */
function saasmaxcore_toolkit_scripts() {
	wp_enqueue_style( 'saasmaxcore-widgets',SAASMAXCORE_CSS . '/widgets.css', '', '1.0.0', 'all' );
	wp_enqueue_style( 'saasmaxcore-addons', SAASMAXCORE_CSS . '/addons.css', '', '1.0.0', 'all' );
	wp_enqueue_style( 'saasmaxcore-overwrite', SAASMAXCORE_CSS . '/overwrite.css', array('kc-general'), '1.0.0', 'all' );
	wp_enqueue_style( 'saasmaxcore', SAASMAXCORE_CSS . '/core-inline.css', '', '1.0.0', 'all' );

	/*------------------------
		REGISTER CSS
	-------------------------*/
	wp_register_style( 'slick', SAASMAXCORE_CSS . '/slick.min.css', '', '1.0.0', 'all' );
	wp_register_style( 'owl-carousel', SAASMAXCORE_CSS . '/owl.carousel.css', '', '1.0.0', 'all' );
	wp_register_style( 'timeCircles', SAASMAXCORE_CSS . '/TimeCircles.css', '', '1.0.0', 'all' );
	wp_register_style( 'modal-video', SAASMAXCORE_CSS . '/modal-video.min.css', '', '1.0.0', 'all' );
	wp_register_style( 'odometer', SAASMAXCORE_CSS . '/odometer.css', '', '1.0.0', 'all' );
	wp_register_style( 'twentytwenty', SAASMAXCORE_CSS . '/twentytwenty.css', '', '1.0.0', 'all' );
	wp_register_style( 'easyTicker', SAASMAXCORE_CSS . '/easy-ticker.css', '', '1.0.0', 'all' );

	/*------------------------
		REGISTER SCRIPTS
	-------------------------*/
	wp_register_script( 'slick', SAASMAXCORE_JS . '/slick.min.js', array('jquery'),'1.0.0', true );
	wp_register_script( 'owl-carousel', SAASMAXCORE_JS . '/owl.carousel.min.js', array('jquery'),'2.0.0', true );
	wp_register_script( 'timeCircles', SAASMAXCORE_JS . '/TimeCircles.js', array('jquery'),'1.0.0', true );
	wp_register_script( 'modal-video', SAASMAXCORE_JS . '/modal-video.min.js', array('jquery'),'1.0.0', true );
	wp_register_script( 'odometer', SAASMAXCORE_JS . '/odometer.min.js', array('jquery'),'1.0.0', true );
	wp_register_script( 'event-move', SAASMAXCORE_JS . '/event.move.js', array('jquery'),'1.0.0', true );
	wp_register_script( 'twentytwenty', SAASMAXCORE_JS . '/twentytwenty.js', array('jquery','event-move'),'1.0.0', true );
	wp_register_script( 'easyTicker', SAASMAXCORE_JS . '/easy-ticker.min.js', array('jquery'),'1.0.0', true );

	/*------------------------
		REGISTER SINGLE SCRIPTS
	--------------------------*/
	wp_register_script( 'instafeed', SAASMAXCORE_JS . '/instafeed.min.js', array('jquery'),'1.0.0', true );
	wp_register_script( 'ajaxchimp', SAASMAXCORE_JS . '/ajaxchimp.js', array('jquery'),'1.0.0', true );
	wp_register_script( 'ParallaxLayerScroll', SAASMAXCORE_JS . '/parallax-layer-scroll.js', array('jquery','jquery-effects-core'),'1.0.0', true );
	wp_register_script( 'countdown', SAASMAXCORE_JS . '/countdown.min.js', array('jquery'),'1.0.0', true );
	wp_register_script( 'qrcode', SAASMAXCORE_JS . '/qrcode.min.js', array('jquery'),'1.0.0', true );
	
	/*------------------------
		CALL SCRIPTS
	--------------------------*/
	wp_enqueue_script( 'appear', SAASMAXCORE_JS . '/appear.js',array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'masonry', array('jquery' , 'imagesloaded') );
	wp_enqueue_script( 'isotope', SAASMAXCORE_JS . '/isotope.pkgd.min.js',array('jquery'),'1.0',true );
	wp_enqueue_script( 'saasmaxcore', SAASMAXCORE_JS . '/active.js', array( 'jquery','appear','countdown','odometer','owl-carousel' ), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'saasmaxcore_toolkit_scripts',10 );

/**
 * Admin Enqueue scripts Backend
 *
 * @param string $handle Script name
 * @param string $src Script url
 * @param array $deps (optional) Array of script names on which this script depends
 * @param string|bool $ver (optional) Script version (used for cache busting), set to null to disable
 * @param bool $in_footer (optional) Whether to enqueue the script before </head> or before </body>
 * @param  string $hook get for the posts id
 */
function saasmaxcore_admin_enqueue_scripts($hook) {
	
	wp_enqueue_style( 'admin-style', SAASMAXCORE_CSS . '/admin.css', array(), '1.0.0', 'all' );
	wp_enqueue_script( 'widget-admin', SAASMAXCORE_JS . '/widget-admin.js',array('jquery'), '1.0.0',true );

    if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
        $post_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
    }

    if ( "post.php" == $hook  ) {
        $post_format = get_post_format($post_id);
		wp_enqueue_script( 'saasmaxcore-admin', SAASMAXCORE_JS . '/admin.js',array('jquery'), '1.0.0',true );
        wp_localize_script("saasmaxcore-admin","post_format",array("format"=>$post_format));
    }elseif( "post-new.php" == $hook ){
		wp_enqueue_script( 'saasmaxcore-admin', SAASMAXCORE_JS . '/admin.js',array('jquery'), '1.0.0',true );
    	wp_localize_script("saasmaxcore-admin","post_format",array("format"=>'none'));
    }

}
add_action( 'admin_enqueue_scripts', 'saasmaxcore_admin_enqueue_scripts' );

if ( file_exists( dirname(__FILE__).'/post/post.php' ) ) {
	require_once(dirname(__FILE__).'/post/post.php');
}

/*---------------------------
	FRAMEWORK
----------------------------*/
if ( is_plugin_active( 'cmb2/init.php' ) ) {
    require_once( dirname(__FILE__) . '/framework/metabox.php' );
}
if (file_exists( dirname(__FILE__) . '/framework/csf/cs-framework.php')) {
	require_once( dirname(__FILE__) . '/framework/csf/cs-framework.php' );
}

/*---------------------------
	DEMO IMPORTER
----------------------------*/

/*--------------------------
	ADDONS
----------------------------*/
/*if ( file_exists( dirname(__FILE__) . '/addons/addons.php' ) ) {
	require_once( dirname(__FILE__) . '/addons/addons.php' );
}*/

/*---------------------------
	WIDGETS
-----------------------------*/
if ( file_exists( dirname(__FILE__) . '/widgets/widgets.php' ) ) {
	require_once( dirname(__FILE__) . '/widgets/widgets.php' );
}