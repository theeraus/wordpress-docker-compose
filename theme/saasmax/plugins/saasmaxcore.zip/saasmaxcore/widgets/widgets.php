<?php
/*-------------------------
	POST WIDGET
--------------------------*/
if ( file_exists(dirname(__FILE__) . '/post.php' ) ) {
	require_once(dirname(__FILE__) . '/post.php');
}

/*-------------------------
	TICKER POST WIDGET
--------------------------*/
if ( file_exists(dirname(__FILE__) . '/ticker.php' ) ) {
	require_once(dirname(__FILE__) . '/ticker.php');
}

/*-------------------------
	TICKER POST WIDGET
--------------------------*/
if ( file_exists(dirname(__FILE__) . '/ticker_two.php' ) ) {
	require_once(dirname(__FILE__) . '/ticker_two.php');
}


/*-------------------------
	SOCIAL WIDGET
--------------------------*/
if ( file_exists(dirname(__FILE__) . '/social.php' ) ) {
	require_once(dirname(__FILE__) . '/social.php');
}

/*-------------------------
	INSTAGRAM WIDGET
--------------------------*/
if ( file_exists(dirname(__FILE__) . '/instagram.php' ) ) {
	require_once(dirname(__FILE__) . '/instagram.php');
}

/*-------------------------
	SUBSCRIBE WIDGET
--------------------------*/
if ( file_exists(dirname(__FILE__) . '/subscribe.php' ) ) {
	require_once(dirname(__FILE__) . '/subscribe.php');
}

/*-------------------------
	CONTACT WIDGET
--------------------------*/
if ( file_exists(dirname(__FILE__) . '/contact.php' ) ) {
	require_once(dirname(__FILE__) . '/contact.php');
}

/*-------------------------
	ABOUT WIDGET
--------------------------*/
if ( file_exists(dirname(__FILE__) . '/about.php' ) ) {
	require_once(dirname(__FILE__) . '/about.php');
}