<?php
add_action('init','agencycore_post_slide_addons',99);
if( !function_exists('agencycore_post_slide_addons') ){
    function agencycore_post_slide_addons(){
        if( function_exists('kc_add_map') ){
            kc_add_map(array(
                'agencycore_post_slide' => array(
                    'name' => esc_html__('Post Carousel','agencycore'),
                    'icon' => 'agencycore_icon blog_icon',
                    'category' => 'Appro',
                    'params' => array(
                        'General' => array(
                            array(
                                'type'			=> 'post_taxonomy',
                                'label'			=> __( 'Content Type', 'agencycore' ),
                                'name'			=> 'post_taxonomy',
                                'description'	=> __( 'Choose supported content type such as post, custom post type, etc.', 'agencycore' ),
                            ),
                            array(
                                'type'			=> 'dropdown',
                                'label'			=> __( 'Order by', 'agencycore' ),
                                'name'			=> 'order_by',
                                'admin_label'	=> true,
                                'options' 		=> array(
                                    'ID'		=> __(' Post ID', 'agencycore'),
                                    'author'	=> __(' Author', 'agencycore'),
                                    'title'		=> __(' Title', 'agencycore'),
                                    'name'		=> __(' Post name (post slug)', 'agencycore'),
                                    'type'		=> __(' Post type (available since Version 4.0)', 'agencycore'),
                                    'date'		=> __(' Date', 'agencycore'),
                                    'modified'	=> __(' Last modified date', 'agencycore'),
                                    'rand'		=> __(' Random order', 'agencycore'),
                                    'comment_count'	=> __(' Number of comments', 'agencycore')
                                )
                            ),
                            array(
                                'type'			=> 'dropdown',
                                'label'			=> __( 'Order post', 'agencycore' ),
                                'name'			=> 'order_list',
                                'admin_label'	=> true,
                                'options' 		=> array(
                                    'ASC'		=> __(' ASC', 'agencycore'),
                                    'DESC'		=> __(' DESC', 'agencycore'),
                                )
                            ),
                            array(
                                'type' => 'toggle',
                                'name' => 'show_image',
                                'label' => esc_html__('Show Thumbnail','agencycore'),
                                'value' => 'yes'
                            ),
                            array(
                                'type' => 'toggle',
                                'name' => 'show_title',
                                'label' => esc_html__('Show Title','agencycore'),
                                'value' => 'yes'
                            ),
                            array(
                                'type' => 'toggle',
                                'name' => 'show_meta',
                                'label' => esc_html__('Show Post Meta','agencycore'),
                                'value' => 'yes'
                            ),
                            array(
                                'type' => 'toggle',
                                'name' => 'show_content',
                                'label' => esc_html__('Show Content','agencycore'),
                                'value' => 'yes'
                            ),
                            array(
                                'type' => 'toggle',
                                'name' => 'show_readmore',
                                'label' => esc_html__('Show Read More','agencycore'),
                                'value' => 'yes'
                            ),
                            array(
                                'type' => 'number_slider',
                                'name' => 'word_count','options' => array(
                                    'min' => 1,
                                    'max' => 100,
                                    'show_input' => true
                                ),
                                'value' => 20,
                                'label' => esc_html__('Word Count','agencycore'),
                                'description' => esc_html__('How many word will show.','agencycore')
                            ),
                            array(
                                'name' => 'wrap_class',
                                'label' => esc_html__('Wrapper Class Name','agencycore'),
                                'type' => 'text',
                                'description' => esc_html__('Custom class for wrapper of the shortcode widget.','agencycore')
                            )  
                        ),
                        'Options' => array(
                            array(
                                'name'        => 'item_on_large',
                                'label'       => esc_html__('Item On Large Device', 'saasmaxcore'),
                                'type'        => 'number_slider',
                                'description' => esc_html__('Please set slide item on large device', 'saasmaxcore'),
                                'options'     => array(
                                    'min'        => 1,
                                    'max'        => 20,
                                    'show_input' => true
                                ),
                                'value' => '5',
                            ),
                            array(
                                'name'        => 'item_on_medium',
                                'label'       => esc_html__('Item On Medium Device', 'saasmaxcore'),
                                'type'        => 'number_slider',
                                'description' => esc_html__('Please set slide item on medium device', 'saasmaxcore'),
                                'options'     => array(
                                    'min'        => 1,
                                    'max'        => 20,
                                    'show_input' => true
                                ),
                                'value' => '5',
                            ),
                            array(
                                'name'        => 'item_on_tablet',
                                'label'       => esc_html__('Item On Tablet Device', 'saasmaxcore'),
                                'type'        => 'number_slider',
                                'description' => esc_html__('Please set slide item on tablet device', 'saasmaxcore'),
                                'options'     => array(
                                    'min'        => 1,
                                    'max'        => 20,
                                    'show_input' => true
                                ),
                                'value' => '3',
                            ),
                            array(
                                'name'        => 'item_on_mobile',
                                'label'       => esc_html__('Item On Mobile Device', 'saasmaxcore'),
                                'type'        => 'number_slider',
                                'description' => esc_html__('Please set slide item on mobile device', 'saasmaxcore'),
                                'options'     => array(
                                    'min'        => 1,
                                    'max'        => 10,
                                    'show_input' => true
                                ),
                                'value' => '1',
                            ),
                            array(
                                'name'        => 'margin',
                                'label'       => esc_html__('Slide Margin', 'saasmaxcore'),
                                'type'        => 'number_slider',
                                'description' => esc_html__('Please set slide margin', 'saasmaxcore'),
                                'options'     => array(
                                    'min'        => 0,
                                    'max'        => 100,
                                    'show_input' => true
                                ),
                                'value' => '20',
                            ),
                            array(
                                'name'        => 'autoplay',
                                'label'       => esc_html__('Slide Autoplay', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__('Please set slide autoplay yes or no.', 'saasmaxcore'),
                                'options'     => array(
                                    'true'  => esc_html('Yes','saasmaxcore'),
                                    'false' => esc_html('No','saasmaxcore'),
                                ),
                                'value' => 'false',
                            ),
                            array(
                                'name'        => 'autoplaytimeout',
                                'label'       => esc_html__('Autoplay Timeout', 'saasmaxcore'),
                                'type'        => 'number_slider',
                                'description' => esc_html__('Please set slide autoplay timeout', 'saasmaxcore'),
                                'options'     => array(
                                    'min'        => 500,
                                    'max'        => 10000,
                                    'show_input' => true
                                ),
                                'value' => '2000',
                            ),
                            array(
                                'name'        => 'slide_speed',
                                'label'       => esc_html__('Slide Speed', 'saasmaxcore'),
                                'type'        => 'number_slider',
                                'description' => esc_html__('Please set slide speed', 'saasmaxcore'),
                                'options'     => array(
                                    'min'        => 500,
                                    'max'        => 5000,
                                    'show_input' => true
                                ),
                                'value' => '1000',
                            ),
                            array(
                                'name'        => 'loop',
                                'label'       => esc_html__('Slide Loop', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__('Please set the slider loop yes or no', 'saasmaxcore'),
                                'options'     => array(
                                    'true'  => esc_html('Yes','saasmaxcore'),
                                    'false' => esc_html('No','saasmaxcore'),
                                ),
                                'value' => 'true',
                            ),
                            array(
                                'name'        => 'nav',
                                'label'       => esc_html__('Slide Navigaion', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__('Please set the slider navigation', 'saasmaxcore'),
                                'options'     => array(
                                    'true'  => esc_html('Yes','saasmaxcore'),
                                    'false' => esc_html('No','saasmaxcore'),
                                ),
                                'value' => 'true',
                            ),
                            array(
                                'name'        => 'nav_position',
                                'label'       => esc_html__('Navigaion Position', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__('Please set the slider navigation position', 'saasmaxcore'),
                                'options'     => array(
                                    'inside_nav' => esc_html('Inside','saasmaxcore'),
                                    'outside_nav'  => esc_html('Outside','saasmaxcore'),
                                ),
                                'value' => 'inside_nav',
                            ),
                            array(
                                'name'        => 'nav_next_icon',
                                'label'       => esc_html__('Navigaion Next Icon', 'saasmaxcore'),
                                'type'        => 'icon_picker',
                                'description' => esc_html__('Please set the slider navigation next icon.', 'saasmaxcore'),
                                'relation'    => array(
                                    'show_when' => 'true',
                                    'parent'    => 'nav',
                                ),
                                'value' => 'sl sl-arrow-right',
                            ),
                            array(
                                'name'        => 'nav_prev_icon',
                                'label'       => esc_html__('Navigaion Prev Icon', 'saasmaxcore'),
                                'type'        => 'icon_picker',
                                'description' => esc_html__('Please set the slider navigation prev icon.', 'saasmaxcore'),
                                'relation'    => array(
                                    'show_when' => 'true',
                                    'parent'    => 'nav',
                                ),
                                'value' => 'sl sl-arrow-left',
                            ),
                            array(
                                'name'        => 'dots',
                                'label'       => esc_html__('Slide Dots', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__('Please set the slider dots', 'saasmaxcore'),
                                'options'     => array(
                                    'true'  => esc_html('Yes','saasmaxcore'),
                                    'false' => esc_html('No','saasmaxcore'),
                                ),
                                'value' => 'false',
                            ),
                            array(
                                'name'        => 'center',
                                'label'       => esc_html__('Slide Center', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__('Please set the slider center', 'saasmaxcore'),
                                'options'     => array(
                                    'true'  => esc_html('Yes','saasmaxcore'),
                                    'false' => esc_html('No','saasmaxcore'),
                                ),
                                'value' => 'false',
                            ),
                        ),
                        'Style' => array(
                            array(
                                'name' => 'agencycore_post_slide_style',
                                'type' => 'css',
                                'options' => array(
                                    array(
                                        "screens" => "any,1024,999,767,479",
                                        'Boxes' => array(
                                            array('property' => 'color', 'label' => 'Color'),
                                            array('property' => 'background-color', 'label' => 'Background Color'),
                                            array('property' => 'font-family', 'label' => 'Font Family'),
                                            array('property' => 'font-size', 'label' => 'Font Size'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight'),
                                            array('property' => 'line-height', 'label' => 'Line Height'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform'),
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'box-shadow', 'label' => 'Hover Box Shadow', 'selector' => ':hover'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin')
                                        ),
                                        'Content Box' => array(
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.post-content'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.post-content'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.post-content'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.post-content'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.post-content'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.post-content'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.post-content'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.post-content'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.post-content'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.post-content'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.post-content'),
                                            array('property' => 'box-shadow', 'label' => 'Hover Box Shadow', 'selector' => ':hover .post-content'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.post-content'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.post-content'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.post-content')
                                        ),
                                        'Title' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.post-content .post-title'),
                                            array('property' => 'color', 'label' => 'Hover Color','selector' => ':hover .post-content .post-title'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.post-content .post-title'),
                                            array('property' => 'background-color', 'label' => 'Hover Background Color', 'selector' => ':hover .post-content .post-title'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.post-content .post-title'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.post-content .post-title'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.post-content .post-title'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.post-content .post-title'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.post-content .post-title'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.post-content .post-title'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.post-content .post-title'),
                                            array('property' => 'float', 'label' => 'Float', 'selector' => '.post-content .post-title'),
                                            array('property' => 'width', 'label' => 'Widht','selector' => '.post-content .post-title'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.post-content .post-title'),
                                            array('property' => 'display', 'label' => 'Display', 'selector' => '.post-content .post-title'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.post-content .post-title'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.post-content .post-title'),
                                            array('property' => 'box-shadow', 'label' => 'Hover Box Shadow', 'selector' => ':hover .post-content .post-title'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.post-content .post-title'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.post-content .post-title'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.post-content .post-title')              
                                        ),
                                        'Desc' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.post-content .desc'),
                                            array('property' => 'color', 'label' => 'Hover Color','selector' => ':hover .post-content .desc'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.post-content .desc'),
                                            array('property' => 'background-color', 'label' => 'Hover Background Color', 'selector' => ':hover .post-content .desc'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.post-content .desc'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.post-content .desc'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.post-content .desc'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.post-content .desc'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.post-content .desc'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.post-content .desc'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.post-content .desc'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.post-content .desc'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.post-content .desc'),
                                            array('property' => 'box-shadow', 'label' => 'Hover Box Shadow', 'selector' => ':hover .post-content .desc'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.post-content .desc'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.post-content .desc'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.post-content .desc') 
                                        ),
                                        'Button' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => 'a.bttn'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => 'a.bttn'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => 'a.bttn'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => 'a.bttn'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => 'a.bttn'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => 'a.bttn'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => 'a.bttn'),
                                            array('property' => 'text-align', 'label' => 'Align', 'selector' => 'a.bttn'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => 'a.bttn'),
                                            array('property' => 'float', 'label' => 'Float', 'selector' => 'a.bttn'),
                                            array('property' => 'width', 'label' => 'Widht','selector' => 'a.bttn'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => 'a.bttn'),
                                            array('property' => 'display', 'label' => 'Display', 'selector' => 'a.bttn'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => 'a.bttn'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => 'a.bttn'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => 'a.bttn'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => 'a.bttn'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => 'a.bttn')                                            
                                        ),                                        
                                        'Button Hover' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => 'a.bttn:hover'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'text-align', 'label' => 'Align', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'width', 'label' => 'Widht','selector' => 'a.bttn:hover'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'display', 'label' => 'Display', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => 'a.bttn:hover'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => 'a.bttn:hover')   
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            ));
        }
    }
}



if( !function_exists('agencycore_post_slide_content') ){
    function agencycore_post_slide_content( $atts, $content = '' ){
        extract( $atts );
        $wrp_class = apply_filters( 'kc-el-class', $atts );
        $orderby   = isset( $order_by ) ? $order_by : 'ID';
        $order     = isset( $order_list ) ? $order_list : 'ASC';    
        wp_enqueue_script( 'owl-carousel' );
        wp_enqueue_style( 'owl-carousel' );
        
        
        $large_desktop = ( !empty($large_desktop) ? $large_desktop : 3 );
        $desktop       = ( !empty($desktop) ? $desktop : 3 );
        $tablet        = ( !empty($tablet) ? $tablet : 2 );
        $phone         = ( !empty($mobile) ? $mobile : 1 );
        
        
        $element_attribute = array();
        $responsive = array(
            '0'=>array(
                'items' => $item_on_mobile
            ),
            '600'=>array(
                'items' => $item_on_tablet
            ),
            '1000'=>array(
                'items' => $item_on_medium
            ),
            '1200'=>array(
                'items' => $item_on_large
            ),
        );

        /*$nav_text = array(
            '<i class=\''.$nav_prev_icon.'\'></i>',
            '<i class=\''.$nav_next_icon.'\'></i>'
        );*/

        $owl_option = array(
            'items'           => $large_desktop,
            'margin'          => $margin,
            'autoplay'        => $autoplay,
            'autoplaySpeed'   => $autoplaytimeout,
            'smartSpeed'      => $slide_speed,
            'loop'            => $loop,
            'nav'             => $nav,
            'dots'            => $dots,
            'center'          => $center,
            /*'navText'         => $nav_text,*/
            'responsiveClass' => true,
            'responsive'      => $responsive,
        );
        
        $owl_option = json_encode( $owl_option );
        
        $post_taxonomy_data = explode( ',', $post_taxonomy );
        $taxonomy_term 	= array();
        $post_type 		= 'post';
        if( isset($post_taxonomy_data) ){
            foreach( $post_taxonomy_data as  $post_taxonomy ){
                
                $post_taxonomy_tmp 	= explode( ':', $post_taxonomy );
                $post_type          = $post_taxonomy_tmp[0];
                
                if( isset( $post_taxonomy_tmp[1] ) ){
			         $taxonomy_term[] = $post_taxonomy_tmp[1];
                }
                
            }
        }
        
        $taxonomy_objects 		= get_object_taxonomies( $post_type, 'objects' );
        $taxonomy 				= key( $taxonomy_objects );
        
        $args = array(
            'post-type' => $post_type,
            'orderby'   => $orderby,
            'order' 	=> $order
        );
        
        if( count($taxonomy_term) ){
            $tax_query = array(
                'relation' => 'OR'
            );
            
            foreach( $taxonomy_term as $term ){
                $tax_query[] = array(
                    'taxonomy' => $taxonomy,
                    'field'    => 'slug',
                    'terms'    => $term,
                );
                
            }
            
            $args['tax_query'] = $tax_query;
            
        }
        
        $the_query = new WP_Query( $args );
        if($the_query->have_posts()){
            
        $data = '<div class="'.implode(' ',$wrp_class).'" >';
        $data .= '<div class="owl-carousel" data-owl-carousel=\''.$owl_option.'\' >';
        
        ob_start();
        while($the_query->have_posts()){
            $the_query->the_post();
            if( $show_image === 'yes' ){
                if(has_post_thumbnail()){
                   $thumbnail = '<figure class="post_image">'.get_the_post_thumbnail().'</figure>'; 
                }else{
                    $thumbnail = '';
                }
            }
            if(get_the_title() && $show_title === 'yes' ){
                $title = '<h2 class="post-title"><a href="'.get_the_permalink().'">'.get_the_title().'</a></h2>';
            }else{
                $title = '';
            }
            
            if( $show_meta === 'yes' ){
                $post_meta = '<ul class="post_meta"><li><span class="sl-user"></span>'.esc_html('By:').'  '.get_the_author().'</li><li><span class="sl-calender"></span> '.get_the_date(get_option('date_format')).'</li></ul>';
            }
            
            $word_count = (isset($word_count) ? $word_count : 20 );
            
           if( $show_readmore === 'yes' ){
               $read_more = '<a href="'.get_the_permalink().'" class="read-more">'.esc_html__('Read More','agencycore').'</a>'; 
            }else{
                $read_more = '';
            }
            if (! post_password_required() && ( comments_open() || get_comments_number() )) { 
                $comment_count = get_comments_number_text('No comment','1 Comment','% Comments');
                $comment_count = '<span><i class="fa fa-comments-o"></i> '.$comment_count.'</span>'; 
            }
            
            if( $show_content === 'yes' ){
                $post_content = '<div class="desc">'.wpautop(wp_trim_words(get_the_content(), $word_count ,'[...]')).'</div>';
            }else{
                $post_content = '';
            }
            echo '<div class="post_slide">
                    '.( isset($thumbnail) ? $thumbnail : '' ).'
                    <div class="post-content">
                        '.( isset($post_meta) ? $post_meta : '' ).'
                        '.( isset($title) ? $title : '' ).'
                        '.(isset($post_content) ? $post_content : '' ).'
                        <div class="footer-content">'.(isset($read_more) ? $read_more : '' ).(isset($comment_count) ? $comment_count : '' ).'</div>
                    </div>
                </div>';
        }
        //wp_reset_query();
        $data .= ob_get_clean();
        $data .= '</div>';
        $data .= '</div>';
        }else{
            $data = '<h4>'.esc_html('There are no posts here').'</h4>';
        }
        return $data;
    }
    
}

add_shortcode('agencycore_post_slide','agencycore_post_slide_content')
?>