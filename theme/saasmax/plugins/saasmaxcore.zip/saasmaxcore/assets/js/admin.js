;(function ($) {
    $(document).ready(function () {

        $("#post-formats-select .post-format").on("click", function () {
        	
            if ($(this).attr("id") == "post-format-gallery") {
                $("#_saasmaxcore_gallery_images").show();
            } else {
                $("#_saasmaxcore_gallery_images").hide();
            }        	

            if ($(this).attr("id") == "post-format-audio") {
                $("#_saasmaxcore_audio").show();
            } else {
                $("#_saasmaxcore_audio").hide();
            }

            if ($(this).attr("id") == "post-format-video") {
                $("#_saasmaxcore_video").show();
            } else {
                $("#_saasmaxcore_video").hide();
            }

        });
        //alert(post_format.format);
        if (post_format.format != "gallery") {
            $("#_saasmaxcore_gallery_images").hide();
        }else{
        	$("#_saasmaxcore_gallery_images").show();
        }
        if (post_format.format != "audio") {
            $("#_saasmaxcore_audio").hide();
        }else{
        	$("#_saasmaxcore_audio").show();
        }
        if (post_format.format != "video") {
            $("#_saasmaxcore_video").hide();
        }else{
        	$("#_saasmaxcore_video").show();
        }

    });
})(jQuery);