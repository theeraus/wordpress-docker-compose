;(function ($) {
    "use strict";
console.log(owl_data);
    jQuery(document).ready(function (owl_data) {
        /*---------------------------
			    HOME SLIDER
			-----------------------------*/
        var activeSlider = $("#any-slider-" + owl_data.slide_randdom_id);
        activeSlider.owlCarousel({
            merge: true,
            smartSpeed: 1000,
            loop: owl_data.loop,
            nav: owl_data.nav,
            navText: ['<i class="ti ti-angle-left"></i>', '<i class="ti ti-angle-right"></i>'],
            autoplay: owl_data.autoplay,
            autoplayTimeout: 'owl_data.autoplay_timeout',
            margin: 0,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 1
                },
                1200: {
                    items: 1
                }
            }
        });
    });
})(jQuery);
wp_enqueue_script( 'anyslide', plugins_url( '../assets/js/anyslide.js', __FILE__ ), array('jquery', 'owl-carousel'), false, true );
$slide_active_data = array(
	'slide_randdom_id' => $r_id,
	'item_on_large'    => $item_on_large,
	'item_on_medium'   => $item_on_medium,
	'item_on_tablet'   => $item_on_tablet,
	'item_on_mobile'   => $item_on_mobile,
	'margin'           => $margin,
	'autoplay'         => $autoplay,
	'autoplaytimeout'  => $autoplaytimeout,
	'slide_speed'      => $slide_speed,
	'loop'             => $loop,
	'nav'              => $nav,
	'nav_prev_icon'    => $nav_prev_icon,
	'nav_next_icon'    => $nav_next_icon,
	'dots'             => $dots,
	'center'           => $center,
);
wp_localize_script('anyslide', 'data', $slide_active_data);