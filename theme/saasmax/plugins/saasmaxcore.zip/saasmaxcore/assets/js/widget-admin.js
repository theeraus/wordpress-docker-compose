;(function ($) {
    $(document).ready(function () {
        $('button#author_image').click(function(e){
             var imageUploader = wp.media({
                'title'  : 'Upload Author Image',
                'button' : {
                    'text' : 'Insert Image'
                },
                'multiple' : false
             });

             imageUploader.open();
             var button = $(this);
             imageUploader.on("select", function(){
                 
                 var image = imageUploader.state().get("selection").first().toJSON(); 
                 var link  = image.url;   
                 button.next('input.img_link').val(link);
                 button.parent('.author-image').find('img').attr('src',link);

             });
            e.preventDefault();
          });
    });
})(jQuery);