<?php

add_action('init', 'image_slider_addon', 99);
if (!function_exists('image_slider_addon')) {
	function image_slider_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'image_slider' => array(
					'name'        => esc_html__('Image Carousel', 'saasmaxcore'),
					'icon'        => 'bi-slider-image',
					'description' => esc_html__('Use this addon for image carousel slider.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
							array(
								'name'        => 'slide_images',
								'label'       => esc_html__('Upload image Images', 'saasmaxcore'),
								'type'        => 'attach_images',
								'description' => esc_html__('Upload minimum 7 images for image slides.', 'saasmaxcore'),
							),
							array(
								'name'        => 'click_action',
								'label'       => esc_html__('Image On Click', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Image on click event.', 'saasmaxcore'),
								'options'     => array(
									'no_action'  => esc_html('No Action','saasmaxcore'),
									'open_popup' => esc_html('Open In Popup','saasmaxcore'),
								),
								'value' => 'true',
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Options' => array(
							array(
								'name'        => 'item_on_large',
								'label'       => esc_html__('Item On Large Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on large device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 20,
									'show_input' => true
								),
								'value' => '5',
							),
							array(
								'name'        => 'item_on_medium',
								'label'       => esc_html__('Item On Medium Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on medium device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 20,
									'show_input' => true
								),
								'value' => '5',
							),
							array(
								'name'        => 'item_on_tablet',
								'label'       => esc_html__('Item On Tablet Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on tablet device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 20,
									'show_input' => true
								),
								'value' => '3',
							),
							array(
								'name'        => 'item_on_mobile',
								'label'       => esc_html__('Item On Mobile Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on mobile device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 10,
									'show_input' => true
								),
								'value' => '1',
							),
							array(
								'name'        => 'margin',
								'label'       => esc_html__('Slide Margin', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide margin', 'saasmaxcore'),
								'options'     => array(
									'min'        => 0,
									'max'        => 100,
									'show_input' => true
								),
								'value' => '20',
							),
							array(
								'name'        => 'autoplay',
								'label'       => esc_html__('Slide Autoplay', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set slide autoplay yes or no.', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'true',
							),
							array(
								'name'        => 'autoplaytimeout',
								'label'       => esc_html__('Autoplay Timeout', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide autoplay timeout', 'saasmaxcore'),
								'options'     => array(
									'min'        => 500,
									'max'        => 10000,
									'show_input' => true
								),
								'value' => '2000',
							),
							array(
								'name'        => 'slide_speed',
								'label'       => esc_html__('Slide Speed', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide speed', 'saasmaxcore'),
								'options'     => array(
									'min'        => 500,
									'max'        => 5000,
									'show_input' => true
								),
								'value' => '1000',
							),
							array(
								'name'        => 'loop',
								'label'       => esc_html__('Slide Loop', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider loop yes or no', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'true',
							),
							array(
								'name'        => 'nav',
								'label'       => esc_html__('Slide Navigaion', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider navigation', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'true',
							),
							array(
								'name'        => 'nav_next_icon',
								'label'       => esc_html__('Navigaion Next Icon', 'saasmaxcore'),
								'type'        => 'icon_picker',
								'description' => esc_html__('Please set the slider navigation next icon.', 'saasmaxcore'),
								'relation'    => array(
									'show_when' => 'true',
									'parent'    => 'nav',
								),
								'value' => 'sl sl-arrow-right',
							),
							array(
								'name'        => 'nav_prev_icon',
								'label'       => esc_html__('Navigaion Prev Icon', 'saasmaxcore'),
								'type'        => 'icon_picker',
								'description' => esc_html__('Please set the slider navigation prev icon.', 'saasmaxcore'),
								'relation'    => array(
									'show_when' => 'true',
									'parent'    => 'nav',
								),
								'value' => 'sl sl-arrow-left',
							),
							array(
								'name'        => 'center',
								'label'       => esc_html__('Slide Center', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider center', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'true',
							),
						),
						'Style' => array(
							array(
								'name'    => 'image_slider_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										"screens" => "any,1024,999,767,479",
										'Images'  => array(
											array('property' => 'width', 'label' => 'Width', 'selector' => '.single-image-slide'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.single-image-slide'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-image-slide'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-image-slide'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-image-slide'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-image-slide'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single-image-slide'),
										),
										'Navigaton'  => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-nav > div'),
											array('property' => 'background-color', 'label' => 'Background', 'selector' => '.owl-nav > div'),
											array('property' => 'color', 'label' => 'Hover Color', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'background-color', 'label' => 'Hover Background', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.owl-nav > div'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-nav > div'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-nav > div'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-nav > div'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-nav > div'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-nav > div'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-nav > div'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-nav > div'),
										),
										'Boxes' => array(
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'background', 'label' => 'Background'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'margin', 'label' => 'Margin'),
										),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('image_slider_content')) {
	function image_slider_content($atts, $content = '') {
		extract($atts);
		$r_id = rand(365,455);
		$master_class = apply_filters('kc-el-class', $atts);

		if( !empty( $slide_images ) ){
			$images_array = explode(',', $slide_images);
		}else{
			$images_array = '';
		}

		if ( !empty( $images_array ) ) {
			$slide_images_content = '';
			foreach ($images_array as $single_image ) {
			$slide_images_content .='
			<div class="single-image-slide">';
				if ( $click_action == 'open_popup' ) {					
					wp_enqueue_script('prettyPhoto');
					wp_enqueue_style( 'prettyPhoto');					
					$slide_images_content .='
					<a class="kc-image-link kc-pretty-photo" data-lightbox="kc-lightbox"  href="'.esc_url( wp_get_attachment_image_url( $single_image, 'full' ) ).'"><img src="'.wp_get_attachment_url( $single_image ).'" alt="'.get_the_title( $single_image ).'"></a>';
				}else{
					$slide_images_content .='
					<img src="'.wp_get_attachment_url( $single_image ).'" alt="'.get_the_title( $single_image ).'">';
				}				
			$slide_images_content.='
			</div>';
			}
		}

		$data = '
		<script>
			(function($){
				$(document).on("ready",function(){
				    /*---------------------------
				        IMAGE SLIDER
				    -----------------------------*/
				    var $imageCarousel = $(\'#image-slider-'.$r_id.'\');
				    $imageCarousel.owlCarousel({
				        merge          : true,
				        smartSpeed     : '.$slide_speed.',
				        loop           : '.$loop.',
				        nav            : '.$nav.',
				        center         : '.$center.',
				        navText        : [\'<i class="'.$nav_prev_icon.'"></i>\', \'<i class="'.$nav_next_icon.'"></i>\'],
				        autoplay       : '.$autoplay.',
				        autoplayTimeout: '.$autoplaytimeout.',
				        margin         : '.$margin.',
				        responsiveClass: true,
				        responsive     : {
				            0: {
				                items: '.$item_on_mobile.'
				            },
				            600: {
				                items: '.$item_on_tablet.'
				            },
				            1000: {
				                items: '.$item_on_medium.'
				            },
				            1200: {
				                items: '.$item_on_medium.'
				            },
				            1900: {
				                items: '.$item_on_large.'
				            }
				        }
				    });
				});
			})(jQuery);
		</script>
		<div class="image-slider-area">
			<div id="image-slider-'.$r_id.'" class="image-slider ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
				'.(isset( $slide_images_content ) ? $slide_images_content : '').'
			</div>
		</div>';
		return $data;
	}
}
add_shortcode('image_slider', 'image_slider_content');
?>