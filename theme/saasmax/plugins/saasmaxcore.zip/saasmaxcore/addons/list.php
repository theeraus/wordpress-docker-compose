<?php

add_action('init', 'saasmaxcore_list_addon', 99);
if (!function_exists('saasmaxcore_list_addon')) {
	function saasmaxcore_list_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_list' => array(
					'name'        => esc_html__('Listing Items', 'saasmaxcore'),
					'icon'        => 'sl-list',
					'description' => esc_html__('Use this addon for list item.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
                            array(
                                'name'        => 'list_type',
                                'label'       => esc_html__('List Type', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__( 'Select the list type which you want to show.', 'saasmaxcore' ),
                                'options'     => array(
                                    'default' => 'Default List',
                                    'custom'  => 'Custom List',
                                ),
                                'value' => 'default',
                            ),
                            array(
                                'name'        => 'default_list',
                                'label'       => esc_html__('Default List Content', 'saasmaxcore'),
                                'type'        => 'textarea',
                                'description' => esc_html__( 'Enter the value every item will be separate with a line break.', 'saasmaxcore' ),
                                'relation'    => array(
                                    'parent'    => 'list_type',
                                    'show_when' => 'default',
                                ),
                                'value' => base64_encode("Full customizable with drag & drop visual editor with undo/redo. \nGroup selection, rulers with guides, copy & paste layers options. \nPopout editor to edit everything in one place without scrolling. \nYou can use this theme any purpose for your any business. \nSeo ready theme you can use for any kind of business purpose. \nYou can reach out globally and make happay in your life. \nTotally user friendly and most customizable features included.")
                            ),
                            array(
                                'name'        => 'show_list_icon',
                                'label'       => esc_html__('Show Icon Attribute ?', 'saasmaxcore'),
                                'type'        => 'toggle',
                                'description' => esc_html__( 'If you want to show icon in every features item you can on by toggle.', 'saasmaxcore' ),
                                'value'       => 'no',
                                'relation'    => array(
                                    'parent'    => 'list_type',
                                    'show_when' => 'default',
                                ),
                            ),
                            array(
                                'name'     => 'list_icon',
                                'label'    => esc_html__('Icon Attribute', 'saasmaxcore'),
                                'type'     => 'icon_picker',
                                'value'    => 'fa fa-check',
                                'relation' => array(
                                    'parent'    => 'show_list_icon',
                                    'show_when' => 'yes',
                                ),
                            ),
                            array(
                                'type'        => 'group',
                                'label'       => esc_html__('Custom List Content', 'saasmaxcore'),
                                'name'        => 'custom_list',
                                'description' => esc_html__( 'Repeat this fields with each item created, Each item corresponding list element.', 'saasmaxcore' ),
                                'options'     => array('add_text' => esc_html__('Add new price list', 'saasmaxcore')),
                                'value'       => base64_encode( json_encode(array(
                                    "1" => array(
                                        "list_content" => "Full customizable with drag & drop visual editor with undo/redo.",
                                    ),
                                    "2" => array(
                                        "list_content" => "Full customizable with drag & drop visual editor with undo/redo.",
                                    ),
                                    "3" => array(
                                        "list_content" => "Popout editor to edit everything in one place without scrolling.",
                                    ),
                                    "4" => array(
                                        "list_content" => "ou can use this theme any purpose for your any business.",
                                    ),
                                    "5" => array(
                                        "list_content" => "You can reach out globally and make happay in your life.",
                                    ),
                                ) ) ),
                                'params' => array(
                                    array(
                                        'type'        => 'text',
                                        'label'       => esc_html__( 'List Content', 'saasmaxcore' ),
                                        'title'       => esc_html__( 'List Content', 'saasmaxcore' ),
                                        'name'        => 'list_content',
                                        'description' => esc_html__( 'Enter your list name.', 'saasmaxcore' ),
                                        'admin_label' => true,
                                    ),
                                    array(
                                        'name'        => 'show_custom_list_icon',
                                        'label'       => esc_html__('Show Icon Attribute ?', 'saasmaxcore'),
                                        'type'        => 'toggle',
                                        'description' => esc_html__( 'If you want to show icon in every list item you can on by toggle.', 'saasmaxcore' ),
                                        'value'       => 'no',
                                        'relation'    => array(
                                            'parent'    => 'list_type',
                                            'show_when' => 'custom',
                                        ),
                                    ),
                                    array(
                                        'name'     => 'custom_icon',
                                        'label'    => esc_html__('Icon Attribute', 'saasmaxcore'),
                                        'type'     => 'icon_picker',
                                        'value'    => 'sl sl-paper-plane',
                                        'relation' => array(
                                            'parent'    => 'show_custom_item_icon',
                                            'show_when' => 'yes',
                                        ),
                                    ),
                                ),
                                'relation' => array(
                                    'parent'    => 'list_type',
                                    'show_when' => 'custom',
                                ),
                            ),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
                        'Style' => array(
                            array(
                                'name'    => 'saasmaxcore_list_addon_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        'screens' => "any,1024,999,767,479",
                                        'ICON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.list-content li i'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.list-content li i'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.list-content li i'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.list-content li i'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.list-content li i'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.list-content li i'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.list-content li i'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.list-content li i'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.list-content li i'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.list-content li i'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.list-content li i'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.list-content li i'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.list-content li i'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.list-content li i'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.list-content li i'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.list-content li i'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.list-content li i'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.list-content li i'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.list-content li i'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.list-content li i'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.list-content li i'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.list-content li i'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.list-content li i'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.list-content li i'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.list-content li i'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.list-content li i'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.list-content li i'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.list-content li i'),
                                        ),
                                        'ITEMS'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.list-content li'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.list-content li'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.list-content li'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.list-content li'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.list-content li'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.list-content li'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.list-content li'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.list-content li'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.list-content li'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.list-content li'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.list-content li'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.list-content li'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.list-content li'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.list-content li'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.list-content li'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.list-content li'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.list-content li'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.list-content li'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.list-content li'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.list-content li'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.list-content li'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.list-content li'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.list-content li'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.list-content li'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.list-content li'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.list-content li'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.list-content li'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.list-content li'),
                                        ),
                                        'ITEM BEFORE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.list-content li:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.list-content li:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.list-content li:before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.list-content li:before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.list-content li:before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.list-content li:before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.list-content li:before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.list-content li:before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.list-content li:before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.list-content li:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.list-content li:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.list-content li:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.list-content li:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.list-content li:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.list-content li:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.list-content li:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.list-content li:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.list-content li:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.list-content li:before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.list-content li:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.list-content li:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.list-content li:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.list-content li:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.list-content li:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.list-content li:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.list-content li:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.list-content li:before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.list-content li:before'),
                                        ),
                                        'ITEM AFTER'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.list-content li:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.list-content li:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.list-content li:after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.list-content li:after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.list-content li:after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.list-content li:after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.list-content li:after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.list-content li:after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.list-content li:after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.list-content li:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.list-content li:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.list-content li:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.list-content li:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.list-content li:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.list-content li:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.list-content li:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.list-content li:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.list-content li:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.list-content li:after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.list-content li:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.list-content li:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.list-content li:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.list-content li:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.list-content li:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.list-content li:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.list-content li:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.list-content li:after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.list-content li:after'),
                                        ),
                                        'ITEM HOVER' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.list-content li:hover'),
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.list-content li:hover'),
                                            array('property' => 'color', 'label' => 'Icon Color', 'selector' => '.list-content li:hover i'),
                                            array('property' => 'background-color', 'label' => 'Icon Background', 'selector' => '.list-content li:hover i'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.list-content li:hover'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.list-content li:hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.list-content li:hover'),
                                        ),
                                        'BOX' => array(
                                            array('property' => 'background', 'label' => 'Background'),
                                            array('property' => 'color', 'label' => 'Color'),
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_list_content')) {
	function saasmaxcore_list_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'list_type'             => '',
			'default_list'          => '',
			'show_list_icon'        => '',
			'list_icon'             => '',
			'custom_list'           => '',
			'list_content'             => '',
			'show_custom_list_icon' => '',
			'custom_list_icon'      => '',
			'custom_class'              => '',
		), $atts));
		$master_class = apply_filters('kc-el-class', $atts);

        // Features Type
        if ( 'default' == $list_type ) {

            if ( !empty( $default_list ) ) {

                if ( !empty( $list_icon ) ) {
                    $icon = $list_icon;
                }else{
                    $icon = '';
                }
                $pros = explode( "\n", $default_list );

                if( count( $pros ) ) {

                    $features_list = '<div class="list-content"><ul>';

                    foreach( $pros as $pro ) {
                        if ( 'yes' == $show_list_icon ) {
                            $features_list .= '<li><i class="'. esc_attr( $icon ) .'"></i> '. esc_html( $pro ) .' </li>';
                        } else {
                            $features_list .= '<li>'. esc_html( $pro ) .' </li>';
                        }
                    }

                    $features_list .= '</ul></div>';
                }
            }

        }elseif ( 'custom' == $list_type ) {

            $custom_list = $custom_list;
            array_shift($custom_list);
            if( count( $custom_list ) ) {

                $features_list = '<div class="list-content"><ul>';

                foreach( $custom_list as $single_features ) {
                    $icon = $single_features->custom_icon;
                    if ( 'yes' == $single_features->show_custom_list_icon ) {
                        $features_list .= '<li><i class="'. esc_attr( $icon ) .'"></i> '. esc_html( $single_features->list_content ) .' </li>';
                    } else {
                        $features_list .= '<li>'. esc_html( $single_features->list_content ) .' </li>';
                    }
                }
                $features_list .= '</ul></div>';
            }
        }

        // Button Shortcode Data.
		$data = '<div class="list-content-box ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
            '.(isset( $features_list ) ? $features_list : '').'
        </div>';
		return $data;
	}
}
add_shortcode('saasmaxcore_list', 'saasmaxcore_list_content');
?>