<?php

add_action('init', 'saasmaxcore_comparison_addon', 99);
if (!function_exists('saasmaxcore_comparison_addon')) {
	function saasmaxcore_comparison_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
			'saasmaxcore_comparison' => array(
				'name'			=> esc_html__( 'Before After Slider', 'saasmaxcore' ),
				'category'		=> 'THEME CORE',
				'icon'			=> 'bi-accordion-horizontal',
				'description'	=> esc_html__( 'The addon for before after slider images and details', 'saasmaxcore' ),
				'params' => array(
					'general' => array(
						array(
							'type'			=> 'attach_image',
							'label'			=> esc_html__( 'Before Image', 'saasmaxcore' ),
							'name'			=> 'before_image',
							'description'	=> esc_html__( 'Set the before image.', 'saasmaxcore'),
							'value'			=> '',
						),
						array(
							'type'			=> 'attach_image',
							'label'			=> esc_html__( 'After Image', 'saasmaxcore' ),
							'name'			=> 'after_image',
							'description'	=> esc_html__( 'Set the after image.', 'saasmaxcore'),
							'value'			=> '',
						),
					),
					'Options' => array(
						array(
							'type'			=> 'select',
							'label'			=> esc_html__( 'Image Orientation', 'saasmaxcore' ),
							'name'			=> 'orientation',
							'description'	=> esc_html__( 'Orientation of the before and after images ( horizontal or vertical )', 'saasmaxcore'),
							'options'	=> array(
								'horizontal' =>	esc_html__( 'Horizontal', 'saasmaxcore' ),
								'vertical'   =>	esc_html__( 'Vertical', 'saasmaxcore' ),
							),
							'value'			=> 'horizontal',
						),
						array(
							'type'			=> 'text',
							'label'			=> esc_html__( 'Image Offset', 'saasmaxcore' ),
							'name'			=> 'image_offset',
							'description'	=> esc_html__( 'How much of the before image is visible when the page loads ( max value 0.9 and minimum value 0.1 )', 'saasmaxcore'),
							'value'			=> '0.5',
						),
						array(
							'type'			=> 'select',
							'label'			=> esc_html__( 'Display Overlay ?', 'saasmaxcore' ),
							'name'			=> 'no_overlay',
							'description'	=> esc_html__( 'Do not show the overlay with before and after', 'saasmaxcore'),
							'options'	=> array(
								'false' =>	esc_html__( 'Yes!', 'saasmaxcore' ),
								'true'  =>	esc_html__( 'No!', 'saasmaxcore' ),
							),
							'value'			=> 'false',
						),
						array(
							'type'			=> 'text',
							'label'			=> esc_html__( 'Before Label', 'saasmaxcore' ),
							'name'			=> 'before_text',
							'description'	=> esc_html__( 'Set a custom before label', 'saasmaxcore'),
							'value'			=> 'Before',
							'relation' => array(
						        'parent'    => 'no_overlay',
						        'show_when' => 'false',
						    ),
						),
						array(
							'type'			=> 'text',
							'label'			=> esc_html__( 'After Label', 'saasmaxcore' ),
							'name'			=> 'after_text',
							'description'	=> esc_html__( 'Set a custom after label', 'saasmaxcore'),
							'value'			=> 'After',
							'relation' => array(
						        'parent'    => 'no_overlay',
						        'show_when' => 'false',
						    ),
						),
						array(
							'type'        => 'select',
							'label'       => esc_html__( 'Overlay Label Position', 'saasmaxcore' ),
							'name'        => 'label_position',
							'description' => esc_html__( 'Chose the overlay label position where you want to show', 'saasmaxcore'),
							'options'     => array(
								'label_top'    =>	esc_html__( 'Top', 'saasmaxcore' ),
								'label_center' =>	esc_html__( 'Center', 'saasmaxcore' ),
								'label_bottom' =>	esc_html__( 'Bottom', 'saasmaxcore' ),
							),
							'relation' => array(
						        'parent'    => 'no_overlay',
						        'show_when' => 'false',
						    ),
							'value'			=> 'label_center',
						),
						array(
							'type'			=> 'select',
							'label'			=> esc_html__( 'Move Slider On Hover ?', 'saasmaxcore' ),
							'name'			=> 'move_slider_on_hover',
							'description'	=> esc_html__( 'Move slider on mouse hover?', 'saasmaxcore'),
							'options'	=> array(
								'true'  =>	esc_html__( 'Yes!', 'saasmaxcore' ),
								'false' =>	esc_html__( 'No!', 'saasmaxcore' ),
							),
							'value'			=> 'false',
						),
						array(
							'type'			=> 'select',
							'label'			=> esc_html__( 'Move Slider With Handle Only ?', 'saasmaxcore' ),
							'name'			=> 'move_with_handle_only',
							'description'	=> esc_html__( 'Allow a user to swipe anywhere on the image to control slider movement', 'saasmaxcore'),
							'options'	=> array(
								'true'  =>	esc_html__( 'Yes!', 'saasmaxcore' ),
								'false' =>	esc_html__( 'No!', 'saasmaxcore' ),
							),
							'value'			=> 'false',
						),
						array(
							'type'			=> 'select',
							'label'			=> esc_html__( 'Click To Move ?', 'saasmaxcore' ),
							'name'			=> 'click_to_move',
							'description'	=> esc_html__( 'Allow a user to click (or tap) anywhere on the image to move the slider to that location.', 'saasmaxcore'),
							'options'	=> array(
								'true'  =>	esc_html__( 'Yes!', 'saasmaxcore' ),
								'false' =>	esc_html__( 'No!', 'saasmaxcore' ),
							),
							'value'			=> 'true',
						),
						array(
							'type'			=> 'text',
							'label'			=> esc_html__( 'Extra Class', 'saasmaxcore' ),
							'name'			=> 'extra_class',
							'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							'value'			=> ''
						)
					),
					'styling' => array(
						array(
							'name'	=> 'saasmaxcore_comparison_style',
							'type'	=> 'css',
							'options' => array(
								array(
									"screens" => "any,1024,999,767,479",
									'Image Warp' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.image-comparison'),
										array('property' => 'background', 'label' => 'Background', 'selector' => '.image-comparison'),
										array('property' => 'display', 'label' => 'Display', 'selector' => '.image-comparison'),
										array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.image-comparison'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.image-comparison'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.image-comparison'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.image-comparison'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.image-comparison'),
										array('property' => 'font-style', 'label' => 'Font Style', 'selector' => '.image-comparison'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.image-comparison'),
										array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.image-comparison'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.image-comparison'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.image-comparison'),
										array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.image-comparison'),
									),
									'Label' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'background', 'label' => 'Background', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'font-style', 'label' => 'Font Style', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.twentytwenty-before-label:before,.twentytwenty-after-label:before'),
									),
									'Overlay' => array(
										array('property' => 'background', 'label' => 'Background', 'selector' => '.twentytwenty-overlay:hover'),
									),
									'Box' => array(
										array('property' => 'background', 'label' => 'Background'),
										array('property' => 'text-align', 'label' => 'Text Align'),
										array('property' => 'border', 'label' => 'Border'),
										array('property' => 'border-radius', 'label' => 'Border Radius'),
										array('property' => 'margin', 'label' => 'Margin'),
										array('property' => 'padding', 'label' => 'Padding'),
										array('property' => 'overflow', 'label' => 'Overflow'),
									)
								)
							)
						)
					),
					'animate' => array(
						array(
							'name'    => 'animate',
							'type'    => 'animate'
						)
					)
				)
			)

			));
		}
	}
}

if (!function_exists('saasmaxcore_comparison_content')) {
	function saasmaxcore_comparison_content($atts, $content = '') {
		extract($atts);
		$rand = rand(254,958);
		wp_enqueue_style( 'twentytwenty' );
		wp_enqueue_script( 'twentytwenty' );
		$script = '
			;(function($){
				$(function(){
		            $("#image-comparison-'.$rand.'").twentytwenty({
		                default_offset_pct: '.$image_offset.',
		                orientation: "'.$orientation.'",
		                before_label: "'.$before_text.'",
		                after_label: "'.$after_text.'",
		                no_overlay: '.$no_overlay.',
		                move_slider_on_hover: '.$move_slider_on_hover.',
		                move_with_handle_only: '.$move_with_handle_only.', 
		                click_to_move: '.$click_to_move.',
		            });
		        });
			})(jQuery);
		';
		wp_add_inline_script( 'saasmaxcore', $script );
		$el_classes = apply_filters( 'kc-el-class', $atts );
		$el_classes[] = 'image-comparison-warp';
		if( !empty( $extra_class ) ){
			$el_classes[] = $extra_class;
		}

		if ( !empty( $before_image ) ) {
			$link_ = wp_get_attachment_image_url( $before_image,'full' );
			$before_title = get_the_title( $before_image );
			$before_image = '<div class="before-image"><img src="'.esc_url( $link_ ).'" alt="'.esc_attr( $before_title ).'"></div>';
		}else{
			$before_image = '';
		}

		if ( !empty( $after_image ) ) {
			$link = wp_get_attachment_image_url( $after_image,'full' );
			$after_title = get_the_title( $after_image );
			$after_image = '<div class="after-image"><img src="'.esc_url( $link ).'" alt="'.esc_attr( $after_title ).'"></div>';
		}else{
			$after_image = '';
		}

		if ( !empty( $before_image )  || !empty( $after_image ) ) {
			$comparison = '<div id="image-comparison-'.$rand.'" class="image-comparison '.esc_attr( $label_position ).'">'. $before_image . $after_image . '</div>';
		}

		$output = '
		<div class="' . esc_attr(implode(' ', $el_classes )) . '">
			'.(isset( $comparison ) ? $comparison : '').'
		</div>';
		return $output;
	}
}
add_shortcode('saasmaxcore_comparison', 'saasmaxcore_comparison_content');
?>