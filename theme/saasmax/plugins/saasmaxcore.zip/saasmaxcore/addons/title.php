<?php

add_action('init', 'saasmaxcore_area_title' , 99 );
if(!function_exists('saasmaxcore_area_title')){
    function saasmaxcore_area_title(){
       if( function_exists('kc_add_map') ){
           kc_add_map(array(
                'saasmaxcore_title' => array(
                    'name'        => esc_html__('Area Title','saasmaxcore'),
                    'icon'        => 'sl-directions',
                    'description' => esc_html__( 'Use this addon for area title.', 'saasmaxcore' ),
                    'category'    => 'THEME CORE',
                    'params'      => array(
                        'General' => array(
                            array(
                                'name'  => 'add_area_icon',
                                'label' => esc_html__('Enable Area Icon','saasmaxcore'),
                                'type'  => 'toggle',
                                'value' => 'no',
                            ),
                            array(
                                'name'    => 'icon_type',
                                'label'   => esc_html__('Icon Type','saasmaxcore'),
                                'type'    => 'select',
                                'options' => array(
                                    'font_icon'  => 'Font Icon',
                                    'image_icon' => 'Image Icon',
                                ),
                                'value'    => 'font_icon',
                                'relation' => array(
                                    'parent'    => 'add_area_icon',
                                    'show_when' => 'yes',
                                )
                            ),
                            array(
                                'name'     => 'font_icon',
                                'label'    => esc_html__('Select Icon','saasmaxcore'),
                                'type'     => 'icon_picker',
                                'relation' => array(
                                    'parent'    => 'icon_type',
                                    'show_when' => 'font_icon',
                                )
                            ),
                            array(
                                'name'     => 'image_icon',
                                'label'    => esc_html__('Upload Icon','saasmaxcore'),
                                'type'     => 'attach_image',
                                'relation' => array(
                                    'parent'    => 'icon_type',
                                    'show_when' => 'image_icon',
                                ),
                                'value' => '',
                            ),
                            array(
                                'name'  => 'title_bg_text',
                                'label' => esc_html__('Title Background Text','saasmaxcore'),
                                'type'  => 'text',
                            ),
                            array(
                                'name'  => 'area_title',
                                'label' => esc_html__('Title','saasmaxcore'),
                                'type'  => 'text',
                            ),
                            array(
                                'name'    => 'heading_type',
                                'label'   => esc_html__('Heading Type','saasmaxcore'),
                                'type'    => 'select',
                                'options' => array(
                                    'h1'  => 'H1',
                                    'h2'  => 'H2',
                                    'h3'  => 'H3',
                                    'h4'  => 'H4',
                                    'h5'  => 'H5',
                                    'h6'  => 'H6',
                                    'div' => 'DIV',
                                    'p'   => 'P',
                                ),
                                'value'       => 'h2',
                                'description' => esc_html__('Default Heading: H2','saasmaxcore'),
                            ),
                            array(
                                'name'  => 'area_subtitle',
                                'label' => esc_html__('Sub Title','saasmaxcore'),
                                'type'  => 'text',
                            ),
                            array(
                                'name'    => 'subtitle_position',
                                'label'   => esc_html__('Subtitle Positon','saasmaxcore'),
                                'type'    => 'select',
                                'options' => array(
                                    'before_title' => 'Before Title',
                                    'after_title'  => 'After Title',
                                ),
                                'value'       => 'after_title',
                                'description' => esc_html__('Subtitle Positon : Default After Title.','saasmaxcore'),
                            ),
                            array(
                                'name'  => 'area_description',
                                'label' => esc_html__('Area Descripton','saasmaxcore'),
                                'type'  => 'textarea',
                            ),
                            array(
                                'name'        => 'custom_class',
                                'label'       => esc_html__('Custom Class','saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__('Add your extra custom any class if you set ( white ) it will get automatically white text color.','saasmaxcore'),
                            ),
                        ),
                        'Style' => array(
                            array(
                                'name'    => 'saasmaxcore_area_title_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        "screens" => "any,1024,999,767,479",
                                        'Icon'=> array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.area_icon'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.area_icon'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.area_icon'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.area_icon'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.area_icon'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.area_icon'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.area_icon'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.area_icon'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.area_icon'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.area_icon'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.area_icon'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.area_icon'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.area_icon'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.area_icon'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.area_icon'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.area_icon'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.area_icon'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.area_icon'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.area_icon'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.area_icon'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_icon'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.area_icon'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_icon'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_icon'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_icon'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.area_icon'),
                                        ),
                                        'Background Text' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.title_bg_text'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.title_bg_text'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.title_bg_text'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.title_bg_text'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.title_bg_text'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.title_bg_text'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.title_bg_text'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.title_bg_text'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.title_bg_text'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.title_bg_text'),
                                            array('property' => 'position', 'label' => 'Positon', 'selector' => '.title_bg_text'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.title_bg_text'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.title_bg_text'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.title_bg_text'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.title_bg_text'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.title_bg_text'),
                                            array('property' => 'text-shadow', 'label' => 'Text Shadow', 'selector' => '.title_bg_text'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.title_bg_text'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.title_bg_text'),
                                        ),
                                        'Title' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.area_title'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.area_title'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.area_title'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.area_title'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.area_title'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.area_title'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.area_title'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.area_title'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.area_title'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_title'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_title'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_title'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_title'),
                                        ),
                                        'Title Before' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.area_title:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.area_title:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.area_title:before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.area_title:before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.area_title:before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.area_title:before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.area_title:before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.area_title:before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.area_title:before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.area_title:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.area_title:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.area_title:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.area_title:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.area_title:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.area_title:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.area_title:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.area_title:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.area_title:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.area_title:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.area_title:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_title:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.area_title:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_title:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_title:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_title:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.area_title:before'),
                                        ),
                                        'Title After' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.area_title:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.area_title:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.area_title:after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.area_title:after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.area_title:after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.area_title:after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.area_title:after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.area_title:after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.area_title:after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.area_title:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.area_title:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.area_title:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.area_title:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.area_title:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.area_title:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.area_title:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.area_title:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.area_title:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.area_title:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.area_title:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_title:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.area_title:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_title:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_title:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_title:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.area_title:after'),
                                        ),
                                        'Subtitle' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.area_subtitle'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.area_subtitle'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.area_subtitle'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.area_subtitle'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.area_subtitle'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.area_subtitle'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.area_subtitle'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.area_subtitle'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.area_subtitle'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.area_subtitle'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_subtitle'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_subtitle'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_subtitle'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_subtitle'),
                                        ),
                                        'Description' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.area_description'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.area_description'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.area_description'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.area_description'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.area_description'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.area_description'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.area_description'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.area_description'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.area_description'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.area_description'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_description'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_description'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_description'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_description'),
                                        ),
                                        'Boxes' => array(
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
           ));
       }
    }
}

if( ! function_exists('saasmaxcore_title_content') ){
    function saasmaxcore_title_content( $atts , $content = '' ){

        extract(shortcode_atts(array(
            'add_area_icon'     => '',
            'icon_type'         => '',
            'font_icon'         => '',
            'image_icon'        => '',
            'title_bg_text'        => '',
            'area_title'        => '',
            'heading_type'      => '',
            'area_subtitle'     => '',
            'subtitle_position' => '',
            'area_description'  => '',
            'custom_class'      => ''
        ), $atts ));
        
        $master_class = apply_filters( 'kc-el-class', $atts );

        if( !empty( $heading_type ) ){
            $heading = $heading_type;
        }else{
            $heading = 'p';
        }

        if ( $add_area_icon == 'yes' ) {

            if ( $icon_type == 'font_icon') {
                $area_icon = '<div class="area_icon"><i class="'.(isset($font_icon) ? $font_icon : '').'"></i></div>';
            }elseif ($icon_type == 'image_icon') {
                $image_icon_link = wp_get_attachment_image_url( $image_icon, 'full' );
                $area_icon = '<div class="area_icon"><img src="'.esc_url( $image_icon_link ).'" alt="'.get_the_title().'"></div>';
            }else{
                $area_icon = '';
            }
        }

        if( ! empty($title_bg_text) ){
            $title_bg_text = '<div class="title_bg_text">'.esc_html($title_bg_text).'</div>';
        }else{
            $title_bg_text = '';
        }

        if( ! empty($area_title) ){
            $area_title = '<'.(isset($heading) ? $heading : '' ).' class="area_title">'.esc_html($area_title).'</'.(isset($heading) ? $heading : '' ).'>';
        }else{
            $area_title = '';
        }
        
        if( !empty($area_subtitle) ){
            $area_subtitle = '<div class="area_subtitle">'.esc_html($area_subtitle).'</div>';
        }else{
            $area_subtitle = '';
        }
        
        if( !empty($area_description) ){
            $area_description = '<div class="area_description">'.wpautop(esc_html($area_description)).'</div>';
        }else{
            $area_description = '';
        }
        
        if ( 'before_title' == $subtitle_position ) {
            $data = '<div class="area_title_box area-title '.esc_attr( implode( ' ', $master_class ) ).' '.( !empty($custom_class) ? $custom_class : '' ).' ">'.
                ( isset($area_icon) ? $area_icon : '' ).
                (isset($title_bg_text) ? $title_bg_text : '' ).
                (isset($area_subtitle) ? $area_subtitle : '' ).
                (isset($area_title) ? $area_title : '' ).
                (isset($area_description) ? $area_description : '' ).
            '</div>';
        }elseif ( 'after_title' == $subtitle_position ) {
            $data = '<div class="area_title_box area-title '.esc_attr( implode( ' ', $master_class ) ).' '.( !empty($custom_class) ? $custom_class : '' ).' ">'.
                ( isset($area_icon) ? $area_icon : '' ).
                (isset($title_bg_text) ? $title_bg_text : '' ).
                (isset($area_title) ? $area_title : '' ).
                (isset($area_subtitle) ? $area_subtitle : '' ).
                (isset($area_description) ? $area_description : '' ).
            '</div>';
        }
        return $data;        
    }
}
add_shortcode('saasmaxcore_title','saasmaxcore_title_content');
?>