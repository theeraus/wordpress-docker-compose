<?php 

add_action('init','saasmaxcore_blog_addons');
if( !function_exists('saasmaxcore_blog_addons') ){
    function saasmaxcore_blog_addons(){
        if( function_exists('kc_add_map') ){
            kc_add_map(array(
                'saasmaxcore_blog_post' => array(
                    'name'        => esc_html__('Blog Filter, Masonry and Slider','saasmaxcore'),
                    'icon'        => 'et et-newspaper',
                    'description' => esc_html__( 'Use this addon for add blog.', 'saasmaxcore' ),
                    'category'    => 'THEME CORE',
                    'params'      => array(
                        'General' => array(
                            array(
                                'name'        => 'blog_style',
                                'label'       => esc_html__('Select Blog Style','saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__('You can select the blog style for showing blog','saasmaxcore'),
                                'options'     => array(
                                	'blog_default'             => esc_html__('Blog Default','saasmaxcore'),
                                	'blog_default_with_filter' => esc_html__('Blog With Filtering','saasmaxcore'),
                                	'blog_masonry'             => esc_html__('Blog Masonry With Filtering','saasmaxcore'),
                                	'blog_slider'              => esc_html__('Blog Slider','saasmaxcore'),
                                ),
                                'value' => 'blog_default',
                            ),
                            array(
                                'name'    => 'blog_columns',
                                'label'   => esc_html__('Select Blog Columns','saasmaxcore'),
                                'type'    => 'select',
                                'options' => array( 
                                    'col-md-6 col-sm-6 col-xs-12' => esc_html__('2 Columns','saasmaxcore'),
                                    'col-md-4 col-sm-6 col-xs-12' => esc_html__('3 Columns','saasmaxcore'),
                                    'col-md-3 col-sm-6 col-xs-12' => esc_html__('4 Columns','saasmaxcore'),
                                ),
                                'value'       => 'col-md-4 col-sm-6 col-xs-12',
                                'description' => esc_html('You can set how columns you want to show blog items.','saasmaxcore'),
                                'relation'    => array(
							        'parent'    => 'blog_style',
							        'hide_when' => 'blog_slider',
							    ),
                            ),
                            array(
                                'name'        => 'blog_gutter',
                                'label'       => esc_html__('Blog Columns Gutter','saasmaxcore'),
                                'type'        => 'toggle',
                                'value'       => 'yes',
                                'description' => esc_html('Do you want to set blog columns gutter ?','saasmaxcore'),
                                'relation'    => array(
							        'parent'    => 'blog_style',
							        'hide_when' => 'blog_slider',
							    ),
                            ),
                            array(
                                'name'        => 'total_slide_item',
                                'label'       => esc_html__('Slide Items','saasmaxcore'),
                                'type'        => 'text',
                                'value'       => '3',
                                'description' => esc_html('Set the slide value in medium device ( 1024px to 1366px )','saasmaxcore'),
                                'relation'    => array(
							        'parent'    => 'blog_style',
							        'show_when' => 'blog_slider',
							    ),
                            ),
                            array(
                                'name'        => 'total_slide_item_big_device',
                                'label'       => esc_html__('Slide Items In Large Device','saasmaxcore'),
                                'type'        => 'text',
                                'value'       => '3',
                                'description' => esc_html('Set the slide value in large device ( 1366px to 1920px )','saasmaxcore'),
                                'relation'    => array(
							        'parent'    => 'blog_style',
							        'show_when' => 'blog_slider',
							    ),
                            ),
                            array(
                                'name'        => 'slider_gutter_between',
                                'label'       => esc_html__('Gutter / Space Between Slide Item','saasmaxcore'),
                                'type'        => 'text',
                                'value'       => '0',
                                'description' => esc_html('Set the slide space between slide item.','saasmaxcore'),
                                'relation'    => array(
							        'parent'    => 'blog_style',
							        'show_when' => 'blog_slider',
							    ),
                            ),
                            array(
                                'name'        => 'slider_autoplay',
                                'label'       => esc_html__('AutoPlay Slide','saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html('Set the slide AutoPlay','saasmaxcore'),
                                'options'     => array(
                                	'true'  => 'Yes !',
                                	'false' => 'No !',
                                ),   
                                'relation' => array(
							        'parent'    => 'blog_style',
							        'show_when' => 'blog_slider',
							    ),
                                'value' => 'true',
                            ),
                            array(
                                'name'        => 'slider_navigation',
                                'label'       => esc_html__('Show Slide Navigation','saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html('Do you want to show navigation ?','saasmaxcore'),
                                'options'     => array(
                                	'true'  => 'Yes !',
                                	'false' => 'No !',
                                ),   
                                'relation' => array(
							        'parent'    => 'blog_style',
							        'show_when' => 'blog_slider',
							    ),
                                'value' => 'true',
                            ),
                            array(
                                'name'        => 'slider_dots',
                                'label'       => esc_html__('Show Slide Dots Navigation','saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html('Do you want to show dots navigation ?','saasmaxcore'),
                                'options'     => array(
                                	'true'  => 'Yes !',
                                	'false' => 'No !',
                                ),   
                                'relation' => array(
							        'parent'    => 'blog_style',
							        'show_when' => 'blog_slider',
							    ),
                                'value' => 'true',
                            ),
                            array(
                                'type'        => 'autocomplete',
                                'label'       => esc_html__( 'Select Category', 'saasmaxcore' ),
                                'name'        => 'post_taxonomy_data',
                                'description' => esc_html__( 'Choose supported content type such as post, custom post type, etc.', 'saasmaxcore' ),
                                'options'     => array(
                                    'multiple'  => true,
                                    'post_type' => 'blog',
                                    'taxonomy'  => 'category'
                                )                                
                            ),
                            array(
                                'name'    => 'total_items',
                                'label'   => esc_html__('Total Items To Show','saasmaxcore'),
                                'type'    => 'number_slider',
                                'options' => array( 
                                    'min'        => 1,
                                    'max'        => 18,
                                    'show_input' => true
                                ),
                                'value'       => 9,                                                             // remove this if you do not need a default content 
                                'description' => esc_html('How many blog items will show','saasmaxcore'),
                            ),
                            array(
                                'type'        => 'dropdown',
                                'label'       => esc_html__( 'Order by', 'saasmaxcore' ),
                                'name'        => 'order_by',
                                'admin_label' => true,
                                'options'     => array(
                                    'ID'       => esc_html__(' Post ID', 'saasmaxcore'),
                                    'author'   => esc_html__(' Author', 'saasmaxcore'),
                                    'title'    => esc_html__(' Title', 'saasmaxcore'),
                                    'name'     => esc_html__(' Post name (post slug)', 'saasmaxcore'),
                                    'type'     => esc_html__(' Post type (available since Version 4.0)', 'saasmaxcore'),
                                    'date'     => esc_html__(' Date', 'saasmaxcore'),
                                    'modified' => esc_html__(' Last modified date', 'saasmaxcore'),
                                    'rand'     => esc_html__(' Random order', 'saasmaxcore'),
                                )
                            ),
                            array(
                                'type'        => 'dropdown',
                                'label'       => esc_html__( 'Order Post', 'saasmaxcore' ),
                                'name'        => 'blog_order',
                                'admin_label' => true,
                                'options'     => array(
                                    'ASC'  => esc_html__(' ASC', 'saasmaxcore'),
                                    'DESC' => esc_html__(' DESC', 'saasmaxcore'),
                                )
                            ),
                            array(
                                'type'        => 'text',
                                'label'       => esc_html__( 'Number of words to show', 'saasmaxcore' ),
                                'name'        => 'total_words',
                                'admin_label' => true,
                                'value'       => '20'
                            ),
                            array(
                                'type'        => 'toggle',
                                'name'        => 'show_blog_meta',
                                'label'       => esc_html__( 'Show Blog Meta', 'saasmaxcore' ),
                                'admin_label' => true,
                                'value'       => 'no',
                            ),
                            array(
                                'type'        => 'toggle',
                                'name'        => 'show_readmore',
                                'label'       => esc_html__( 'Show Blog Read More', 'saasmaxcore' ),
                                'admin_label' => true,
                                'value'       => 'no',
                            ),
                            array(
                                'type'        => 'toggle',
                                'name'        => 'show_blog_menu',
                                'label'       => esc_html__( 'Show Blog Filter Menu', 'saasmaxcore' ),
                                'admin_label' => true,
                                'value'       => 'no',
                            ),
                            array(
                                'type'        => 'dropdown',
                                'name'        => 'blog_menu_position',
                                'label'       => esc_html__( 'Blog Menu Position', 'saasmaxcore' ),
                                'admin_label' => true,
                                'options'     => array(
                                    'blog_menu_left'   => esc_html__('Menu Left Position', 'saasmaxcore'),
                                    'blog_menu_right'  => esc_html__('Menu Right Position', 'saasmaxcore'),
                                    'blog_menu_center' => esc_html__('Menu Center Position', 'saasmaxcore'),
                                ),
                                'value'    => 'blog_menu_center',
                                'relation' => array(
							        'parent'    => 'show_blog_menu',
							        'show_when' => 'yes',
							    ),
                            ),
                            array(
                                'name'        => 'custom_class',
                                'label'       => esc_html__('Custom Class','saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__('Add your extra custom class.','saasmaxcore')
                            ),
                        ),
                        'Style' => array(
                             array(
                                'name'    => 'saasmaxcore_blog_post_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        "screens" => "any,1024,999,767,479",
                                        'MENU'    => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.blog-menu li'),
                                            array('property' => 'color', 'label' => 'Hover Color','selector' => '.blog-menu li:hover, .blog-menu li.active'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.blog-menu li'),
                                            array('property' => 'background-color', 'label' => 'Hover Background Color', 'selector' => '.blog-menu li:hover,.blog-menu li.active'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.blog-menu li'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.blog-menu li'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.blog-menu li'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.blog-menu li'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.blog-menu li'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.blog-menu'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.blog-menu li'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.blog-menu li'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.blog-menu li'),
                                            array('property' => 'box-shadow', 'label' => 'Hover Box Shadow', 'selector' => '.blog-menu li:hover, .blog-menu li.active'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.blog-menu li'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.blog-menu li'),
                                            array('property' => 'margin', 'label' => 'Menu Container Margin', 'selector' => '.blog-menu'),            
                                        ),
                                        'DETAILS' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.blog-details'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.blog-details'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.blog-details'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.blog-details'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.blog-details'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.blog-details'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.blog-details'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.blog-details'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.blog-details'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.blog-details'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.blog-details'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.blog-details'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.blog-details')              
                                        ),
                                        'META' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.post_meta a'),
                                            array('property' => 'color', 'label' => 'Hover Color','selector' => '.post_meta a:hover'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.post_meta a'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.post_meta a'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.post_meta'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.post_meta a'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.post_meta a'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.post_meta a'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.post_meta a'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.post_meta'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.post_meta'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.post_meta'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.post_meta')              
                                        ),
                                        'CONTENT' => array(
                                            array('property' => 'display', 'label' => 'Display', 'selector' => '.post__content'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.post__content'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.post__content')              
                                        ),
                                        'TITLE' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.blog-details h3 a'),
                                            array('property' => 'color', 'label' => 'Hover Color','selector' => '.blog-details h3 a:hover'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.blog-details h3'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.blog-details h3'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.blog-details h3'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.blog-details h3'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.blog-details h3'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.blog-details h3'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.blog-details h3'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.blog-details h3'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.blog-details h3'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.blog-details h3'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.blog-details h3'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.blog-details h3'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.blog-details h3'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.blog-details h3'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.blog-details h3'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.blog-details h3'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.blog-details h3'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.blog-details h3'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.blog-details h3'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.blog-details h3'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.blog-details h3'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.blog-details h3'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.blog-details h3'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.blog-details h3'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.blog-details h3'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.blog-details h3'),             
                                        ),
                                        'TITLE BEFORE' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.blog-details h3:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.blog-details h3:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.blog-details h3:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.blog-details h3:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.blog-details h3:before'),
                                        ),
                                        'TITLE AFTER' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.blog-details h3:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.blog-details h3:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.blog-details h3:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.blog-details h3:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.blog-details h3:after'),
                                        ),
                                        'BUTTON' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.blog-view-link'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.blog-view-link'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.blog-view-link'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.blog-view-link'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.blog-view-link'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.blog-view-link'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.blog-view-link'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.blog-view-link'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.blog-view-link'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.blog-view-link'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.blog-view-link'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.blog-view-link'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.blog-view-link'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.blog-view-link'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.blog-view-link'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.blog-view-link'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.blog-view-link'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.blog-view-link'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.blog-view-link'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.blog-view-link'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.blog-view-link'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.blog-view-link'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.blog-view-link'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.blog-view-link'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.blog-view-link'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.blog-view-link'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.blog-view-link'),
                                        ),
                                        'BUTTON HOVER' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.blog-view-link:hover'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.blog-view-link:hover'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.blog-view-link:hover'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.blog-view-link:hover'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.blog-view-link:hover'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.blog-view-link:hover'),
                                        ),
                                        'NAV'  => array(
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-nav > div'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-nav > div'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.owl-nav > div'),
                                            array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-nav > div'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-nav > div'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-nav > div'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-nav > div'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-nav > div'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-nav > div'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-nav > div'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-nav > div'),
                                        ),
                                        'NAV HOVER'  => array(
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-nav > div:hover'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-nav > div:hover'),
                                        ),
                                        'DOTS'  => array(
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-dots > div'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-dots > div'),
                                            array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-dots > div'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-dots > div'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-dots > div'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-dots > div'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-dots > div'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-dots > div'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-dots > div'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-dots > div'),
                                        ),
                                        'DOTS HOVER'  => array(
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                            array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
                                        ),
                                        'BOX' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.blog-item'),
                                            array('property' => 'background', 'label' => 'Background','selector' => '.blog-item'),
                                            array('property' => 'background-color', 'label' => 'Hover Background Color', 'selector' => ':hover'),
                                            array('property' => 'font-family', 'label' => 'Font Family','selector' => '.blog-item'),
                                            array('property' => 'font-size', 'label' => 'Font Size','selector' => '.blog-item'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight','selector' => '.blog-item'),
                                            array('property' => 'line-height', 'label' => 'Line Height','selector' => '.blog-item'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform','selector' => '.blog-item'),
                                            array('property' => 'text-align', 'label' => 'Text Align','selector' => '.blog-item'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing','selector' => '.blog-item'),
                                            array('property' => 'width', 'label' => 'Widht','selector' => '.blog-item'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.blog-item'),
                                            array('property' => 'border', 'label' => 'Border','selector' => '.blog-item'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow','selector' => '.blog-item'),
                                            array('property' => 'box-shadow', 'label' => 'Hover Box Shadow', 'selector' => ':hover','selector' => '.blog-item'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius','selector' => '.blog-item'),
                                            array('property' => 'padding', 'label' => 'Padding','selector' => '.blog-item'),
                                            array('property' => 'margin', 'label' => 'Margin','selector' => '.blog-item')
                                        ),
                                    )
                                )
                            )
                        )
                    )
                )
            ));
        }
    }
}


/**
 * Returns the parsed shortcode.
 *
 * @param array   {
 *     Attributes of the shortcode.
 *
 *     @type string $id ID of...
 * }
 * @param string  Shortcode content.
 *
 * @return string HTML content to display the shortcode.
 */

if ( !function_exists('saasmaxcore_blog_shortcode') ) {
	function saasmaxcore_blog_shortcode( $atts = array(), $content = '' ) {
		extract(shortcode_atts( array(
			'blog_style'                      => '',       // Slider, Filter Isotope, Filter Isotope With Masonry, Default
			'blog_columns'                    => '',
			'blog_gutter'                     => '',
			'total_slide_item'                => 3,        // 1024px
			'total_slide_item_big_device'     => 3,        // 1920px
			'slider_gutter_between'           => 30,
			'slider_autoplay'                 => '',
			'slider_navigation'               => '',
			'slider_dots'                     => '',
			'slider_dots_navigation_position' => '',
			'post_taxonomy_data'              => '',
			'total_items'                     => 9,
			'blog_order'                      => 'DESC',
			'order_by'                        => 'date',
			'show_blog_menu'                  => 'yes',    // left , Right, Center
			'blog_menu_position'              => '',       // left , Right, Center
			'total_words'                     => 20,
			'show_blog_meta'                  => 'no',
			'show_readmore'                   => 'no',
			'custom_class'                    => '',
		), $atts));
		global $post;

		//blog Random Number.
		$blog_rand = rand(785590,968584);

		// King Composer Style Master Class
		$master_class = apply_filters( 'kc-el-class', $atts );

		// blog Style
		switch ( $blog_style ) {
			case 'blog_default_with_filter':
					$blog_style = 'blog_default_with_filter';
				break;
			case 'blog_masonry':
					$blog_style = 'blog_masonry';
				break;
			case 'blog_slider':
					$blog_style = 'blog_slider';
				break;
			
			case 'blog_default':
					$blog_style = 'blog_default';
				break;
		}


		// blog Columns
		switch ($blog_columns) {
			case 'col-md-6 col-sm-6 col-xs-12':
					$blog_columns = 'col-md-6 col-sm-6 col-xs-12';
				break;
			
			case 'col-md-4 col-sm-6 col-xs-12':
					$blog_columns = 'col-md-4 col-sm-6 col-xs-12';
				break;
			
			case 'col-md-3 col-sm-6 col-xs-12':
					$blog_columns = 'col-md-3 col-sm-6 col-xs-12';
				break;
			
			default:
					$blog_columns = 'col-md-4 col-sm-6 col-xs-12';
				break;
		}

		// Columns No Margin No Padding.
		if ( $blog_gutter == 'yes' ) {
			$columns_gutter	= '';
		}else{
			$columns_gutter	= 'columns-no-margin-no-padding';
		}

		// Columns Gutter With Colums Item
		$colum_gutter_and_colums = array($blog_columns,$columns_gutter);
		$gutter_and_items = implode(' ', $colum_gutter_and_colums);

		// Value For Query blog By Texonomy Query. 
		$post_type = 'post';
		$post_texonomys = explode(',', $post_taxonomy_data);

		$tax_name = array();
		$tax_slug = array();

		if (isset( $post_texonomys )) {			
			foreach ($post_texonomys as $single_texonomy ) {
				$single_texonomy_data = explode(':', $single_texonomy);

				if ( isset( $single_texonomy_data[0] ) ) {
					$tax_slug[] = $single_texonomy_data[0];
				}
				if ( isset( $single_texonomy_data[1] ) ) {
					$tax_name[] = $single_texonomy_data[1];
				}
			}
		}

		// GETTING FILTER MENU ITEMS
		if ( $tax_name ) {
			$filter_menu = array_combine($tax_name,$tax_slug);
		}

		// blog Menu Position
		if ( !empty( $blog_menu_position ) ) {
			$menu_position = $blog_menu_position;
		}else{
			$menu_position = '';
		}

		// Post Query Args Post Query By Texonomy.
		$args = array(
			'post_type'      => $post_type,
			'order'          => $blog_order,
			'orderby'        => $order_by,
			'posts_per_page' => $total_items,
			'tax_query'      => array(
				'relation' => 'OR',
				array(
					'taxonomy' => 'category',
					'field'    => 'slug',
					'terms'    => $tax_slug,
				),
			),
		);
		$query = new WP_Query( $args );

ob_start();
?>

<?php if ( $blog_style !== 'blog_default' ) : ?>
<script>
(function ($) {

    jQuery(document).ready( function () {
        "use strict";

        <?php if( $blog_style == 'blog_slider' ) : ?>

            /*---------------------------
                blog GALLERY SLIDER
            -----------------------------*/
            var blogCarousel = $('#blog-slider-<?php echo esc_attr( $blog_rand ); ?>');
            blogCarousel.owlCarousel({
                merge          : true,
                smartSpeed     : 1000,
                loop           : true,
                nav            : <?php echo $slider_navigation; ?>,
                dots           : <?php echo $slider_dots; ?>,
                navText        : ['<i class="sl sl-arrow-left"></i>', '<i class="sl sl-arrow-right"></i>'],
                autoplay       : <?php echo $slider_autoplay; ?>,
                autoplayTimeout: 2000,
                margin         : <?php echo $slider_gutter_between; ?>,
                responsiveClass: true,
                responsive     : {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: <?php echo $total_slide_item; ?>
                    },
                    1920: {
                        items: <?php echo $total_slide_item_big_device; ?>
                    }
                }
            });

            <?php if($slider_navigation == false || $slider_dots == false ) : ?>
                $('.owl-controls').hide('');
            <?php endif; ?>

		<?php endif; ?>

		<?php if( $blog_style == 'blog_default_with_filter' ||  $blog_style == 'blog_masonry' ) : ?>

            /* -------------------------------------------------------
             blog FILTER SET ACTIVE CLASS FOR STYLE
            ----------------------------------------------------------*/
            $('#blog-menu-<?php echo esc_attr( $blog_rand ); ?> li').on('click', function (event) {
                $(this).siblings('.active').removeClass('active');
                $(this).addClass('active');
                event.preventDefault();
            });

            <?php if( $blog_style == 'blog_default_with_filter' ) : ?>
            
                /*----------------------------
                    blog MASONRY ACTIVE
                -----------------------------*/
                var $blogMasonry = $('#blog-masonry-<?php echo esc_attr( $blog_rand ); ?>');
                if (typeof imagesLoaded === 'function') {
                    imagesLoaded($blogMasonry, function () {
                        setTimeout(function () {
                            $blogMasonry.isotope({
                                itemSelector    : '.blog-item',
                                resizesContainer: false,
                                layoutMode      : 'fitRows',
                                filter          : '*',
                                horizontalOrder : true
                            });
                        }, 500);
                    });
                };

            <?php elseif( $blog_style == 'blog_masonry' ) : ?>

                /*----------------------------
                    blog MASONRY ACTIVE
                -----------------------------*/
                var $blogMasonry = $('#blog-masonry-<?php echo esc_attr( $blog_rand ); ?>');
                if (typeof imagesLoaded === 'function') {
                    imagesLoaded($blogMasonry, function () {
                        setTimeout(function () {
                            $blogMasonry.isotope({
                                itemSelector    : '.blog-item',
                                resizesContainer: false,
                                layoutMode      : 'masonry',
                                filter          : '*',
                                horizontalOrder : true
                            });
                        }, 500);
                    });
                };

            <?php endif; ?>

            /* ------------------------------
             blog FILTERING
             -------------------------------- */
            $('#blog-menu-<?php echo esc_attr( $blog_rand ); ?> li').on('click', function () {
                //$(this).addClass('active');
                var filterValue = $(this).attr('data-filter');

                $("#blog-masonry-<?php echo esc_attr( $blog_rand ); ?>").isotope({
                    filter          : filterValue,
                    animationOptions: {
                        duration: 750,
                        easing  : 'linear',
                        queue   : false,
                    }
                });
                return false;
            });

        <?php endif; ?>

	});
}(jQuery));
</script>
<?php endif; ?>

<?php if( $query->have_posts() ) : ?>
<div class="blog-area <?php echo esc_attr( implode( ' ', $master_class ));  echo ' '.esc_attr( !empty($custom_class) ? $custom_class : '' ); ?>">

	<?php if ( ( $blog_style !== 'blog_default' ) &&   $show_blog_menu == 'yes' && ( $blog_style == 'blog_default_with_filter' || $blog_style == 'blog_masonry' ) ) : ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
				<div class="blog-menu wow fadeIn <?php echo esc_attr( $menu_position ); ?>" id="blog-menu-<?php echo esc_attr( $blog_rand ); ?>">
					<ul>
						<li class="filter active" data-filter="*">All</li>
						<?php foreach ($filter_menu as $tax_name => $tax_slug ) : ?>
						<li class="filter" data-filter=".<?php echo esc_attr( $tax_slug ); ?>"><?php echo esc_html( $tax_name ) ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<?php endif; ?>

	
	<?php if( $blog_style == 'blog_default_with_filter' ||  $blog_style == 'blog_masonry' ) : ?>

    <!-- POST TYPE FOR MASONRY FILTERING & DEFAULT FILTERING -->

	<div class="row blog-masonry <?php echo esc_attr( $columns_gutter ); ?>" id="blog-masonry-<?php echo esc_attr( $blog_rand ); ?>">
	<?php while ( $query->have_posts() ) : $query->the_post(); ?>

		<div class="blog-item <?php echo esc_attr( (isset($gutter_and_items) ? $gutter_and_items : '') ); ?> <?php echo blog_single_category(' ', 'slug'); ?>">
			<div class="single-blog-content">
                <?php if( has_post_thumbnail() ) : ?>
                <div class="blog-img">
                    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                </div>
                <?php endif; ?>
                <div class="blog-details">  
                    <?php 
                    // Get Single Blog Link.
                    if ( 'yes' == $show_readmore ) {                        
                        $blog_button = '
                        <a href="'.esc_url( get_the_permalink(get_the_ID()) ).'" class="blog-view-link">'.esc_html__( 'Read More', 'saasmaxcore' ).' <i class="ti ti-angle-right"></i></a>';
                    }?>
                    
                    <?php if( 'yes' == $show_blog_meta) : ?>
                        <?php $date_format = get_the_date('Y/m/d'); ?>
                    <ul class="post_meta">
                        <li><i class="ti-user"></i> By <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) ?>"><?php echo get_the_author(); ?></a></li>
                        <li><i class="ti-time"></i> <a href="<?php echo home_url( $date_format ); ?>"><?php echo get_the_date('M j, Y'); ?></a></li>
                    </ul>
                    <?php endif; ?>

                    <?php if( get_the_title() == '' ) : ?>
                    <h3><?php _e( 'Empty Title', 'saasmaxcore' ); ?></h3>
                    <?php else : ?>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <?php endif; ?>
                    <?php 
                    if ($total_words) {
                        $total_words = $total_words;
                    }else{
                        $total_words = 20;
                     } ?>
                    <div class="post__content">                        
                    <?php
                    $content =  wp_trim_words( get_the_content(), $total_words ); 
                        echo wpautop( $content );
                    ?>
                    <?php if ( 'yes' == $show_readmore ) { echo $blog_button;  } ?>                                 
                    </div>
                    <?php if ( 'yes' == $show_readmore ) { echo $blog_button;  } ?>                                 
                </div>
			</div>
		</div>
		
	<?php endwhile; wp_reset_query(); ?>
	</div>
    <!-- POST TYPE FOR MASONRY FILTERING & DEFAULT FILTERING -->
	<?php endif; // For Masonry & Default Filtering. ?> 


	<?php if( $blog_style == 'blog_default' ) : ?>
    <!-- POST TYPE DEFAULT -->
	<div class="row <?php echo esc_attr( $columns_gutter ); ?>">
	<?php while ( $query->have_posts() ) : $query->the_post(); ?>

		<div class="blog-item <?php echo esc_attr( (isset($gutter_and_items) ? $gutter_and_items : '') ); ?> <?php echo blog_single_category(' ', 'slug'); ?>">
			<div class="single-blog-content">
                <?php if( has_post_thumbnail() ) : ?>
                <div class="blog-img">
                    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                </div>
                <?php endif; ?>
                <div class="blog-details">  
                    <?php 
                    // Get Single Blog Link.
                    if ( 'yes' == $show_readmore ) {                        
                        $blog_button = '
                        <a href="'.esc_url( get_the_permalink(get_the_ID()) ).'" class="blog-view-link">'.esc_html__( 'Read More', 'saasmaxcore' ).' <i class="ti ti-angle-right"></i></a>';
                    }?>
                    
                    <?php if( 'yes' == $show_blog_meta) : ?>
                        <?php $date_format = get_the_date('Y/m/d'); ?>
                    <ul class="post_meta">
                        <li><i class="ti-user"></i> By <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) ?>"><?php echo get_the_author(); ?></a></li>
                        <li><i class="ti-time"></i> <a href="<?php echo home_url( $date_format ); ?>"><?php echo get_the_date('M j, Y'); ?></a></li>
                    </ul>
                    <?php endif; ?>

                    <?php if( get_the_title() == '' ) : ?>
                    <h3><?php _e( 'Empty Title', 'saasmaxcore' ); ?></h3>
                    <?php else : ?>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <?php endif; ?>
                    <?php 
                    if ($total_words) {
                        $total_words = $total_words;
                    }else{
                        $total_words = 20;
                    } ?>
                    <div class="post__content">                        
                    <?php
                    $content =  wp_trim_words( get_the_content(), $total_words ); 
                        echo wpautop( $content );
                    ?>
                    <?php if ( 'yes' == $show_readmore ) { echo $blog_button;  } ?>                                 
                    </div>
                    <?php if ( 'yes' == $show_readmore ) { echo $blog_button;  } ?>                                 
                </div>
			</div>
		</div>
		
	<?php endwhile; wp_reset_query(); ?>
	</div>
    <!-- POST TYPE DEFAULT -->
	<?php endif; ?> 


	<?php if( $blog_style == 'blog_slider' ) : ?>
    <!-- POST TYPE SLIDER -->
	<div class="blog-slider <?php echo esc_attr( $columns_gutter ); ?>" id="blog-slider-<?php echo esc_attr( $blog_rand ); ?>">
	<?php while ( $query->have_posts() ) : $query->the_post(); ?>

		<div class="blog-item">
			<div class="single-blog-content">
                <?php if( has_post_thumbnail() ) : ?>
				<div class="blog-img">
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
				</div>
                <?php endif; ?>
				<div class="blog-details">	
					<?php 
					// Get Single Blog Link.
					if ( 'yes' == $show_readmore ) {						
						$blog_button = '
                        <a href="'.esc_url( get_the_permalink(get_the_ID()) ).'" class="blog-view-link">'.esc_html__( 'Read More', 'saasmaxcore' ).' <i class="ti ti-angle-right"></i></a>';
					}?>
                    
                    <?php if( 'yes' == $show_blog_meta) : ?>
                        <?php $date_format = get_the_date('Y/m/d'); ?>
                    <ul class="post_meta">
                        <li><i class="ti-user"></i> By <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) ?>"><?php echo get_the_author(); ?></a></li>
                        <li><i class="ti-time"></i> <a href="<?php echo home_url( $date_format ); ?>"><?php echo get_the_date('M j, Y'); ?></a></li>
                    </ul>
                    <?php endif; ?>

					<?php if( get_the_title() == '' ) : ?>
                    <h3><?php _e( 'Empty Title', 'saasmaxcore' ); ?></h3>
                    <?php else : ?>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <?php endif; ?>
                    <?php 
                    if ($total_words) {
                        $total_words = $total_words;
                    }else{
                        $total_words = 20;
                    } ?>
                    <div class="post__content">                        
                    <?php
                    $content =  wp_trim_words( get_the_content(), $total_words ); 
                        echo wpautop( $content );
                    ?>
                    <?php if ( 'yes' == $show_readmore ) { echo $blog_button;  } ?>                                 
                    </div>
				</div>
			</div>
		</div>
		
	<?php endwhile; wp_reset_query(); ?>
	</div>
    <!-- POST TYPE SLIDER -->
	<?php endif; ?> 
	

</div>
<?php else: ?>
    <div class="no-post-messagee center">
        <h3><?php _e( 'Not found any blog post please select any post category to show blog post.', 'saasmaxcore' ); ?></h3>
    </div>
<?php endif; ?>
<?php
	return ob_get_clean();
	}
}

add_shortcode( 'saasmaxcore_blog_post', 'saasmaxcore_blog_shortcode' );


function blog_single_category($separator, $type = 'name'){

	// For get all value form tearms.
	$signle_cat_value = get_the_terms( get_the_ID(), 'category' );

	//Check if not empty varibale
	if( !empty($signle_cat_value) ){
		$item_cats     = wp_get_post_terms( get_the_ID(), 'category' );
		$item_all_cats = array();
		foreach ($item_cats  as $item_cat ) {
			$item_all_cats[] = $item_cat->$type;
		}

		return implode( $separator, $item_all_cats );
	}
}

?>