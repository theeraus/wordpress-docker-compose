<?php

add_action('init', 'saasmaxcore_layers_addon', 99);
if (!function_exists('saasmaxcore_layers_addon')) {
    function saasmaxcore_layers_addon()
    {
        if (function_exists('kc_add_map')) {
            kc_add_map(array(
                'saasmaxcore_layers' => array(
                    'name'        => esc_html__('Animate BG Layers', 'saasmaxcore'),
                    'icon'        => 'sl-layers',
                    'description' => esc_html__('Use this addon for animateing any background layer.', 'saasmaxcore'),
                    'category'    => 'THEME CORE',
                    'params'      => array(
                        'General' => array(
                            array(
                                'name'        => 'all_layers',
                                'label'       => esc_html__('Single Layers', 'saasmaxcore'),
                                'type'        => 'group',
                                'description' => esc_html__('Add single layer for animate.', 'saasmaxcore'),
                                'options'     => array(
									'add_text' => 'Add New Layer',
								),
                                'params' => array(
                                    array(
                                        'name'  => 'layer_no',
                                        'label' => esc_html__('Layer Number', 'saasmaxcore'),
                                        'type'  => 'text',
                                        'value' => '1',
                                    ),
                                    array(
                                        'name'    => 'layer_opacity',
                                        'label'   => esc_html__('Layer Opacity', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array(
                                            'min'        => 0,
                                            'max'        => 9,
                                            'show_input' => true
                                        ),
                                        'value' => 5,
                                    ),
                                    array(
                                        'name'    => 'border_radius',
                                        'label'   => esc_html__('Border Radius', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array(
                                            'min'        => 0,
                                            'max'        => 100,
                                            'unit' => '%',
                                            'show_input' => true
                                        ),
                                        'value' => 0,
                                    ),
                                    array(
                                        'name'    => 'layer_type',
                                        'label'   => esc_html__('Layer Type', 'saasmaxcore'),
                                        'type'    => 'select',
                                        'options' => array(
                                            'font_icon'  => 'Layer Font Icon',
                                            'image_icon' => 'Layer Image',
                                            'color' => 'Layer Color',
                                        ),
                                        'value' => 'image_icon',
                                    ),
                                    array(
                                        'name'     => 'font_icon_layer',
                                        'label'    => esc_html__('Select Icon', 'saasmaxcore'),
                                        'type'     => 'icon_picker',
                                        'relation' => array(
                                            'parent'    => 'layer_type',
                                            'show_when' => 'font_icon',
                                        ),
                                    ),
                                    array(
                                        'name'     => 'image_layer',
                                        'label'    => esc_html__('Upload Layer', 'saasmaxcore'),
                                        'type'     => 'attach_image',
                                        'relation' => array(
                                            'parent'    => 'layer_type',
                                            'show_when' => 'image_icon',
                                        ),
                                        'value' => '',
                                    ),
                                    array(
                                        'name'     => 'color_layer',
                                        'label'    => esc_html__('Set Color Layer', 'saasmaxcore'),
                                        'type'     => 'color_picker',
                                        'relation' => array(
                                            'parent'    => 'layer_type',
                                            'show_when' => 'color',
                                        ),
                                        'value' => '',
                                    ),
                                    array(
                                        'name'    => 'layer_position_from_left',
                                        'label'   => esc_html__('Layer Position From Left', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array(
                                            'min'        => -100,
                                            'max'        => 100,
                                            'unit'       => '%',
                                            'show_input' => true
                                        ),
                                        'value' => '0',
                                    ),
                                    array(
                                        'name'    => 'layer_position_from_top',
                                        'label'   => esc_html__('Layer Position From Top', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array( 
                                            'min'        => -100,
                                            'max'        => 100,
                                            'unit'       => '%',
                                            'show_input' => true
                                        ),
                                        'value' => '0',
                                    ),
                                    array(
                                        'name'    => 'scroll_x',
                                        'label'   => esc_html__('Layer Position In Scrolling X', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array( 
                                            'min'        => -1000,
                                            'max'        => 1000,
                                            'show_input' => true
                                        ),
                                        'value'       => '0',
                                        'description' => esc_html__('Layer Position on scrolling in Horizontal.', 'saasmaxcore')
                                    ),
                                    array(
                                        'name'    => 'scroll_y',
                                        'label'   => esc_html__('Layer Position In Scrolling Y', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array( 
                                            'min'        => -1000,
                                            'max'        => 1000,
                                            'show_input' => true
                                        ),
                                        'value'       => '0',
                                        'description' => esc_html__('Layer Position on scrolling in vartically', 'saasmaxcore')
                                    ),
                                    array(
                                        'name'    => 'scroll_smoothness',
                                        'label'   => esc_html__('Layer Animation Smoothness', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array( 
                                            'min'        => 10,
                                            'max'        => 300,
                                            'show_input' => true
                                        ),
                                        'value'       => '30',
                                        'description' => esc_html__('Layer Smoothness on scrolling.', 'saasmaxcore')
                                    ),
                                    array(
                                        'name'    => 'layer_rotate',
                                        'label'   => esc_html__('Layer Rotating', 'saasmaxcore'),
                                        'type'    => 'select',
                                        'options' => array(
                                            'no_rotate' => 'No Rotate',
                                            'rotateX'   => 'Rotate X',
                                            'rotateY'   => 'Rotate Y',
                                            'rotateZ'   => 'Rotate Z',
                                        ),
                                        'value'       => 'no_rotate',
                                        'description' => esc_html__('Layer rotating on scrolling Effect', 'saasmaxcore'),
                                    ),
                                    array(
                                        'name'    => 'layer_rotate_degree',
                                        'label'   => esc_html__('Layer Rotate Degree', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array( 
                                            'min'        => -10000,
                                            'max'        => 10000,
                                            'show_input' => true
                                        ),
                                        'value'       => '0',
                                        'description' => esc_html__('Layer Rotate Degree On Scrolling', 'saasmaxcore')
                                    ),
                                    array(
                                        'name'    => 'layer_scale',
                                        'label'   => esc_html__('Layer Scale', 'saasmaxcore'),
                                        'type'    => 'select',
                                        'options' => array(
                                            'no_scale' => 'No Scale',
                                            'scaleX'   => 'Scale X',
                                            'scaleY'   => 'Scale Y',
                                            'scale'    => 'Scale Z',
                                        ),
                                        'value'       => 'no_scale',
                                        'description' => esc_html__('Layer Scale on scrolling Effect', 'saasmaxcore'),
                                    ),
                                    array(
                                        'name'    => 'layer_scale_ratio',
                                        'label'   => esc_html__('Layer Scale Ratio', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array( 
                                            'min'        => -1,
                                            'max'        => 10,
                                            'show_input' => true
                                        ),
                                        'value'       => '1',
                                        'description' => esc_html__('Layer Scale Ratio On Scrolling', 'saasmaxcore')
                                    ),
                                ),
                            ),
                            array(
                                'name'        => 'custom_class',
                                'label'       => esc_html__('Custom Class', 'saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
                            ),
                        ),
                        'Style' => array(
                            array(
                                'name'    => 'saasmaxcore_layers_addon_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        "screens" => "any,1024,999,767,479",
                                        'Icon Layer'    => array(
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.single-layer i'),
                                            array('property' => 'display', 'label' => 'Display', 'selector' => '.single-layer i'),
                                            array('property' => 'width', 'label' => 'WIdth', 'selector' => '.single-layer i'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.single-layer i'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-layer i'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.single-layer i'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.single-layer i'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.single-layer i'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.single-layer i'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single-layer i'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-layer i'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-layer i'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-layer i'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-layer i'),
                                        ),
                                        'Image Layer' => array(
                                            array('property' => 'display', 'label' => 'Display', 'selector' => '.single-layer'),
                                            array('property' => 'width', 'label' => 'WIdth', 'selector' => '.single-layer'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.single-layer'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-layer'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single-layer'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-layer'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-layer'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-layer'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-layer'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single-layer'),
                                        ),
                                        'Color Layer'    => array(
                                            array('property' => 'display', 'label' => 'Display', 'selector' => '.single-layer .animate_color_layer'),
                                            array('property' => 'width', 'label' => 'WIdth', 'selector' => '.single-layer .animate_color_layer'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.single-layer .animate_color_layer'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-layer .animate_color_layer'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single-layer .animate_color_layer'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-layer .animate_color_layer'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-layer .animate_color_layer'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-layer .animate_color_layer'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-layer .animate_color_layer'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single-layer .animate_color_layer'),
                                        ),
                                        'Boxes' => array(
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'display', 'label' => 'Display'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'z-index', 'label' => 'Z-Index'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                            array('property' => 'position', 'Label' => 'Position'),
                                            array('property' => 'overflow', 'Label' => 'Overflow'),
                                        ),
                                        'Custom' => array(
                                            array('property' => 'custom', 'label' => 'Custom Css'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
            ));
        }
    }
}

if (!function_exists('saasmaxcore_layers_content')) {
    function saasmaxcore_layers_content($atts, $content = ''){

        extract($atts);
        $master_class = apply_filters('kc-el-class', $atts);
        wp_enqueue_script( 'ParallaxLayerScroll');
        $data = 
        '<div class="area_layers hidden-sm hidden-xs ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">';

            foreach ($all_layers as $single ) {
                extract($single_layers = array(
                    'layer_opacity'            => $single->layer_opacity,
                    'border_radius'            => $single->border_radius,
                    'layer_position_from_left' => $single->layer_position_from_left,
                    'layer_position_from_top'  => $single->layer_position_from_top,
                    'layer_type'               => $single->layer_type,
                    'font_icon_layer'          => $single->font_icon_layer,
                    'image_layer'              => $single->image_layer,
                    'color_layer'              => $single->color_layer,
                    'scroll_x'                 => $single->scroll_x,
                    'scroll_y'                 => $single->scroll_y,
                    'scroll_smoothness'        => $single->scroll_smoothness,
                    'layer_rotate'             => $single->layer_rotate,
                    'layer_rotate_degree'      => $single->layer_rotate_degree,
                    'layer_scale'              => $single->layer_scale,
                    'layer_scale_ratio'        => $single->layer_scale_ratio,
                ));
                $layer_style = 'left:'.$layer_position_from_left.';top:'.$layer_position_from_top.';opacity:.'.$layer_opacity.';border-radius:'.$border_radius.';';

                if ( $layer_type == 'image_icon' ) {
                    $layer = '<img src="'.wp_get_attachment_image_url($image_layer, 'full').'" alt="'.get_the_title( $image_layer ).'">';
                }elseif( $layer_type == 'font_icon' ){
                    $layer = '<i class="'.$font_icon_layer.'"></i>';
                }elseif( $layer_type == 'color' ){
                    $layer = '<div class="animate_color_layer" style="background:'.$color_layer.'"></div>';
                }

                if ( $layer_rotate != 'no_rotate' ) {
                    $rotate = ',"'.$layer_rotate.'":'.$layer_rotate_degree;
                }else{
                    $rotate = '';
                }
                if ( $layer_scale != 'no_scale' ) {
                    $scale = ',"'.$layer_scale.'":'.$layer_scale_ratio;
                }else{
                    $scale = '';
                }

                $parallax_data = '{"x":'.$scroll_x.',"y":'.$scroll_y.',"smoothness":'.$scroll_smoothness.''.$rotate.''.$scale.'}';


                $data.='
                <div class="single-layer" style="'.$layer_style.'" data-parallax=\''.$parallax_data.'\'>'.$layer.'</div>';
            }

        $data.= 
        '</div>';
        return $data;

    }
}
add_shortcode('saasmaxcore_layers', 'saasmaxcore_layers_content');
