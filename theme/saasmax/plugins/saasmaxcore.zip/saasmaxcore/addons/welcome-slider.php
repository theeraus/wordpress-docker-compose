<?php

add_action('init', 'saasmaxcore_welcome_slider_addon', 99);
if (!function_exists('saasmaxcore_welcome_slider_addon')) {
	function saasmaxcore_welcome_slider_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_welcome_slider' => array(
					'name'        => esc_html__('Welcome Slider', 'saasmaxcore'),
					'icon'        => 'bi-slider-doc',
					'description' => esc_html__('Use this addon for welcome slider.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
							array(
								'name'    => 'welcome_slides',
								'label'   => esc_html__('Welcome Slides', 'saasmaxcore'),
								'type'    => 'group',
								'options' => array(
									'add_text' => 'Add New Slide',
								),
								'params' => array(
									array(
										'name'  => 'slide_number',
										'label' => esc_html__('Slide No.', 'saasmaxcore'),
										'type'  => 'text',
									),
									array(
										'name'    => 'slide_column',
										'label'   => esc_html__('Slide Content Width', 'saasmaxcore'),
										'type'    => 'select',
										'options' => array(
											'col-md-4'  => '4 Column',
											'col-md-5'  => '5 Column',
											'col-md-6'  => '6 Column',
											'col-md-7'  => '7 Column',
											'col-md-8'  => '8 Column',
											'col-md-9'  => '9 Column',
											'col-md-10' => '10 Column',
											'col-md-11' => '11 Column',
											'col-md-12' => '12 Column',
										),
										'value'       => 'col-md-10',
										'description' => esc_html__('Please make sure that you are used total 12 column with offset otherwise the content will be brocken.', 'saasmaxcore'),
									),
									array(
										'name'    => 'slide_offset_column',
										'label'   => esc_html__('Slide Content Offset Width', 'saasmaxcore'),
										'type'    => 'select',
										'options' => array(
											'no-offset'       => 'No Offset',
											'col-md-offset-1' => '1 Column Offset',
											'col-md-offset-2' => '2 Column Offset',
											'col-md-offset-3' => '3 Column Offset',
											'col-md-offset-4' => '4 Column Offset',
											'col-md-offset-5' => '5 Column Offset',
											'col-md-offset-6' => '6 Column Offset',
											'col-md-offset-7' => '7 Column Offset',
											'col-md-offset-8' => '8 Column Offset',
										),
										'value'       => 'col-md-offset-1',
										'description' => esc_html__('Please make sure that you are used total 12 column with offset otherwise the content will be brocken.', 'saasmaxcore'),
									),
									array(
										'name'    => 'slide_text_align',
										'label'   => esc_html__('Slide Text Align', 'saasmaxcore'),
										'type'    => 'select',
										'options' => array(
											'left'   => 'Align Left',
											'right'  => 'Align Right',
											'center' => 'Align Center',
										),
										'value'       => 'left',
										'description' => esc_html__('Set the slide text align by default slide text is left align.', 'saasmaxcore'),
									),
									array(
										'name'    => 'slide_layer_animation',
										'label'   => esc_html__('Slide Layer Animation', 'saasmaxcore'),
										'type'    => 'select',
										'options' => array(
											'slide_fade_in'    => 'Fade In',
											'fade_from_bottom' => 'Fade In Up',
											'fade_from_left'   => 'Fade In Left',
											'fade_from_right'  => 'Fade In Right',
											'slide_from_left'  => 'Slide In Left',
											'slide_from_right' => 'Slide In Right',
											'text_blur_zoomout' => 'Text Blur ZoomOut',
										),
										'value'       => 'fade_from_bottom',
										'description' => esc_html__('Set the slide text align by default slide text is left align.', 'saasmaxcore'),
									),
									array(
										'name'  => 'slide_bg',
										'label' => esc_html__('Slide Background', 'saasmaxcore'),
										'type'  => 'attach_image',
									),
									array(
										'name'  => 'slide_overlay',
										'label' => esc_html__('Enable Slide Overlay', 'saasmaxcore'),
										'type'  => 'color_picker',
										'value' => 'rgba(27,14,95,.65)',
									),
									array(
										'name'  => 'slide_subtitle',
										'label' => esc_html__('Subtitle', 'saasmaxcore'),
										'type'  => 'text',
									),
									array(
										'name'  => 'slide_title',
										'label' => esc_html__('Title', 'saasmaxcore'),
										'type'  => 'textarea',
									),
									array(
										'name'  => 'slide_description',
										'label' => esc_html__('Short Descripton', 'saasmaxcore'),
										'type'  => 'textarea',
									),
									array(
										'name'        => 'slide_button_one',
										'label'       => esc_html__('Slide Button 1', 'saasmaxcore'),
										'type'        => 'link',
										'description' => 'This button appear on you slide if you don\'t want to show button it will not appear.',
									),
									array(
										'name'        => 'slide_button_two',
										'label'       => esc_html__('Slide Button 2', 'saasmaxcore'),
										'type'        => 'link',
										'description' => 'This button appear on you slide if you don\'t want to show button it will not appear.',
									),
								),
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Options' => array(
							array(
								'name'    => 'slide_animation',
								'label'   => esc_html__('Slide Animation', 'saasmaxcore'),
								'type'    => 'select',
								'options' => array(
									'slide_fade_in_out' => 'Slide Fade',
									'slide'             => 'Slide Left / Right',
								),
								'value'       => 'slide',
								'description' => esc_html__('Set the slide animation type default animation slide.', 'saasmaxcore'),
							),
							array(
								'name'    => 'autoplay',
								'label'   => esc_html__('Slider AutoPlay', 'saasmaxcore'),
								'type'    => 'select',
								'options' => array(
									'true'  => 'Yes',
									'false' => 'No',
								),
								'value'       => true,
								'description' => esc_html__('Select if you want to autoplay ON or OFF.', 'saasmaxcore'),
							),
							array(
								'name'        => 'autoplay_timeout',
								'label'       => esc_html__('AutoPlay Timeout', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Set Integer value in milisecond like (1000,2000,5000)', 'saasmaxcore'),
								'value'       => '3000',
							),
							array(
								'name'    => 'slider_navigation',
								'label'   => esc_html__('Show Slider Navigation', 'saasmaxcore'),
								'type'    => 'select',
								'options' => array(
									'true'  => 'Yes',
									'false' => 'No',
								),
								'value'       => true,
								'description' => esc_html__('Select if you want to show slider navigaion.', 'saasmaxcore'),
							),
							array(
								'name'    => 'slider_loop',
								'label'   => esc_html__('Slider Loop', 'saasmaxcore'),
								'type'    => 'select',
								'options' => array(
									'true'  => 'Yes',
									'false' => 'No',
								),
								'value'       => true,
								'description' => esc_html__('Select if you want to loop ON or OFF.', 'saasmaxcore'),
							),
						),
						'Style' => array(
							array(
								'name'    => 'saasmaxcore_welcome_slider_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										"screens"      => "any,1024,999,767,479",
										'Text Waraper' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.welcome-text'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.welcome-text'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome-text'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome-text'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome-text'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome-text'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome-text'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome-text'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome-text'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome-text'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome-text'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome-text'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome-text'),
										),
										'Title' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.welcome_title'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.welcome_title'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome_title'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome_title'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome_title'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome_title'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome_title'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome_title'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome_title'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome_title'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome_title'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.welcome_title'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome_title'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome_title'),
										),
										'Subtitle' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.welcome_subtitle'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.welcome_subtitle'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome_subtitle'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome_subtitle'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome_subtitle'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome_subtitle'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome_subtitle'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome_subtitle'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome_subtitle'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome_subtitle'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome_subtitle'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.welcome_subtitle'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome_subtitle'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome_subtitle'),
										),
										'Subtitle Before' => array(
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.welcome_subtitle:before'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.welcome_subtitle:before'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.welcome_subtitle:before'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome_subtitle:before'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.welcome_subtitle:before'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome_subtitle:before'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome_subtitle:before'),
										),
										'Description' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.welcome_description'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.welcome_description'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome_description'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome_description'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome_description'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome_description'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome_description'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome_description'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome_description'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome_description'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome_description'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.welcome_description'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome_description'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome_description'),
										),
										'Button Waraper' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.home-button'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.home-button'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.home-button'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.home-button'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.home-button'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.home-button'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.home-button'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.home-button'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.home-button'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.home-button'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.home-button'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.home-button'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.home-button'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.home-button'),
										),
                                        'Buttons' => array(
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.home-button a'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.home-button a'),
                                            array('property' => 'width', 'label' => 'Width', 'selector' => '.home-button a'),
                                            array('property' => 'height', 'label' => 'height', 'selector' => '.home-button a'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.home-button a'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.home-button a'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.home-button a'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.home-button a'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.home-button a'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.home-button a'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.home-button a'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.home-button a'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.home-button a'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.home-button a'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.home-button a'),
                                        ),
										'Buttons Hover' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.home-button a:hover'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.home-button a:hover'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.home-button a:hover'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.home-button a:hover'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.home-button a:hover'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.home-button a:hover'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.home-button a:hover'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.home-button a:hover'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.home-button a:hover'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.home-button a:hover'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.home-button a:hover'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.home-button a:hover'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.home-button a:hover'),
										),
										'Boxes' => array(
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'margin', 'label' => 'Margin'),
										),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_welcome_slider_addon_content')) {
	function saasmaxcore_welcome_slider_addon_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'welcome_slides'    => '',
			'slide_animation'   => '',
			'autoplay'          => '',
			'autoplay_timeout'  => '',
			'slider_navigation' => '',
			'slider_loop'       => '',
			'custom_class'      => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		$slide_randdom_id = rand(968,875);
		if ($welcome_slides) {
			$welcome_slides = $welcome_slides;
		}else{
			$welcome_slides = array();
		}

		$colum = array();

		

		$data = '';
		if( count($welcome_slides) > 1 ):
		$data .='
		<script>
			(function($){
				jQuery(document).ready(function(){
				    /*---------------------------
					    HOME SLIDER
					-----------------------------*/
				    var homeSlider = $("#welcome-slider-area-'.$slide_randdom_id.'");
				    homeSlider.owlCarousel({
				        merge          : true,
				        smartSpeed     : 1000,
				        loop           : '.$slider_loop.',
				        nav            : '.$slider_navigation.',
				        navText        : [\'<i class="ti ti-angle-left"></i>\', \'<i class="ti ti-angle-right"></i>\'],
				        autoplay       : '.$autoplay.',
				        autoplayTimeout: '.$autoplay_timeout.',
				        margin         : 0,';
						if ( $slide_animation ==  'slide_fade_in_out') {
						$data .='
						animateIn : "fadeIn",
						animateOut: "fadeOut",';
						}
						$data .='
				        responsiveClass: true,
				        responsive     : {
				            0: {
				                items: 1
				            },
				            600: {
				                items: 1
				            },
				            1000: {
				                items: 1
				            },
				            1200: {
				                items: 1
				            }
				        }
				    });
				});
			})(jQuery);
		</script>';
		endif;

		$data .='
		<div id="welcome-slider-area-'.$slide_randdom_id.'" class="welcome-slider-area white ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">';

		foreach ( $welcome_slides as $single_slides ) {

			extract($single_slide_args = array(
				'slide_bg'          => wp_get_attachment_image_url( $single_slides->slide_bg, 'full' ),
				'slide_overlay'     => $single_slides->slide_overlay,
				'slide_subtitle'    => $single_slides->slide_subtitle,
				'slide_title'       => $single_slides->slide_title,
				'slide_description' => $single_slides->slide_description,
				'slide_button_one'  => $single_slides->slide_button_one,
				'slide_button_two'  => $single_slides->slide_button_two,
			));

			$colum_animation_and_width = array(
				'slide_column'          => $single_slides->slide_column,
				'slide_offset_column'   => $single_slides->slide_offset_column,
				'slide_text_align'      => $single_slides->slide_text_align,
				'slide_layer_animation' => $single_slides->slide_layer_animation,
			);
			$colums_properties = implode(' ', $colum_animation_and_width);

			if ( !empty( $slide_bg ) ) {
				$slide_bg = 'background-image:url('.esc_url( $slide_bg ).');';
			}else{
				$slide_bg = '';
			}

			if ( !empty( $slide_overlay ) ) {
				$slide_overlay = 'background:'.$slide_overlay.';';
			}else{
				$slide_overlay = '';
			}
			
			if ( !empty( $slide_subtitle ) ) {
				$slide_subtitle = '<h4 class="welcome_subtitle">'.esc_html( $slide_subtitle ).'</h4>';
			}else{
				$slide_subtitle = '';
			}
			
			if ( !empty( $slide_title ) ) {
				$slide_title = '<h1 class="welcome_title">'.esc_html( $slide_title ).'</h1>';
			}else{
				$slide_title = '';
			}

			if ( !empty( $slide_description ) ) {
				$slide_description = '<div class="welcome_description">' . wpautop(esc_html($slide_description)) . '</div>';
			}else{
				$slide_description = '';
			}

			if ( !empty( $slide_button_one ) ) {
				$slide_button_one = $slide_button_one;
			}else{
				$slide_button_one = '';
			}

			if ( !empty( $slide_button_two ) ) {
				$slide_button_two = $slide_button_two;
			}else{
				$slide_button_two = '';
			}

			$data .='
		    <div class="welcome-single-slide" style="'.$slide_bg.'">
		        <div class="slide-bg-overlay" style="'.$slide_overlay.'"></div>
		        <div class="welcome-area">
		            <div class="container">
		                <div class="row flex-v-center">
		                    <div class="'.esc_attr($colums_properties).'">
		                        <div class="welcome-text">
		                            '.( isset($slide_subtitle) ? $slide_subtitle : '' ).'
		                            '.( isset($slide_title) ? $slide_title : '' ).'
									'.( isset($slide_description) ? $slide_description : '' ).'';
									
		                            if ( !empty( $slide_button_one ) || !empty( $slide_button_two ) ) {

		                            $data .='
		                            <div class="home-button">';
		                                if ( !empty( $slide_button_one ) ) {

		                                	$btn_one = explode('|', $slide_button_one);
		                                	$data .='<a href="'.esc_url( $btn_one[0] ).'" '.(isset($btn_one[2]) ? 'target="'.$btn_one[2].'"' : '').'>'.esc_html( $btn_one[1] ).'</a>';
		                                }
		                                if ( !empty( $slide_button_two ) ) {

		                                	$btn_two = explode('|', $slide_button_two);
		                                	$data .='<a href="'.esc_url( $btn_two[0] ).'" '.(isset($btn_two[2]) ? 'target="'.$btn_two[2].'"' : '').'>'.esc_html( $btn_two[1] ).'</a>';
		                                }
		                            $data .='
		                            </div>';

		                            }
		                            $data .='
		                        </div>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>';
		}

		$data.='
		</div>';

		return $data;
	}
}
add_shortcode('saasmaxcore_welcome_slider', 'saasmaxcore_welcome_slider_addon_content');
?>