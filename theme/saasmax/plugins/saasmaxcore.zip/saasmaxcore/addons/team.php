<?php

add_action('init', 'saasmaxcore_team_addon', 99);
if (!function_exists('saasmaxcore_team_addon')) {
	function saasmaxcore_team_addon() {
		if (function_exists('kc_add_map')) {
		    kc_add_map(
		        array(
		            'saasmaxcore_team' => array(
		                'name'        => 'Team Member',
		                'description' => esc_html__('Team Member', 'chariy-toolkit'),
		                'icon'        => 'bi-group',
		                'category'    => 'THEME CORE',
		                'params'      => array(
		                	'Genaral' => array(
			                    array(
			                        'name'        => 'team_style',
			                        'label'       => 'Select Team Style',
			                        'type'        => 'radio_image',
									'description' => esc_html__('Select the team style which you want to show.', 'chariy-toolkit'),
									'options' => array(
										'single-team-one'	=> plugins_url( '../assets/img/team/team_1.png', __FILE__ ),
										'single-team-two'	=> plugins_url( '../assets/img/team/team_2.png', __FILE__ ),
										'single-team-three'	=> plugins_url( '../assets/img/team/team_3.png', __FILE__ ),
										'single-team-five'	=> plugins_url( '../assets/img/team/team_5.png', __FILE__ ),
										'single-team-six'	=> plugins_url( '../assets/img/team/team_6.png', __FILE__ ),
										'single-team-seven'	=> plugins_url( '../assets/img/team/team_7.png', __FILE__ ),
										'single-team-eight'	=> plugins_url( '../assets/img/team/team_8.png', __FILE__ ),
										'single-team-nine'	=> plugins_url( '../assets/img/team/team_9.png', __FILE__ ),
									),
									'value' => 'single-team-five',
			                    ),
			                    array(
			                        'name'        => 'member_thumb',
			                        'label'       => 'Member Thumbnail',
			                        'type'        => 'attach_image',
			                        'description' => esc_html__('Set the member thumbnail image.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'member_name',
			                        'label'       => 'Member Name',
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the member name.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'member_designation',
			                        'label'       => 'Member Designation',
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the member designation.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'show_button',
			                        'label'       => 'Show Member Button',
			                        'type'        => 'toggle',
			                        'value'       => 'no',
			                        'description' => esc_html__('If you want set member page link you can checked yes.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'member_button',
			                        'label'       => 'Member Button',
			                        'type'        => 'link',
			                        'description' => esc_html__('Set link for member page.', 'chariy-toolkit'),
			                        'relation'    => array(
			                        	'parent'    => 'show_button',
			                        	'show_when' => 'yes',
			                        ),
			                        'value' => 'http://example.com|Read More',
			                    ),
			                    array(
			                        'name'        => 'show_social_links',
			                        'label'       => 'Show Member Social Profile',
			                        'type'        => 'toggle',
			                        'value'       => 'no',
			                        'description' => esc_html__('If you want show member social profile icon and link you can checked yes.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'custom_class',
			                        'label'       => 'Custom Class',
			                        'type'        => 'text',
			                        'description' => esc_html__('Add your extra custom class.', 'chariy-toolkit')
			                    ),
		                	),
		                	'Socials' => array(
			                    array(
			                        'name'        => 'facebook',
			                        'label'       => 'Facebook Link',
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the member facebook profile link.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'twitter',
			                        'label'       => 'Twitter Link',
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the member twitter profile link.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'linkedin',
			                        'label'       => 'Linkedin Link',
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the member linkedin profile link.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'github',
			                        'label'       => 'Github Link',
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the member github profile link.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'pinterest',
			                        'label'       => 'Pinterest Link',
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the member pinterest profile link.', 'chariy-toolkit')
			                    ),
			                    array(
			                        'name'        => 'instagram',
			                        'label'       => 'Instagram Link',
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the member instagram profile link.', 'chariy-toolkit')
			                    ),
		                	),
		                	'Style'	=>	array(
								array(
			                		'name'    => 'saasmaxcore_team_addon_style',
			                		'type'    => 'css',
			                		'options' => array(
										array(
											'screens'    => "any,1024,999,767,479",
											'Typography' => array(
												array('property' => 'color', 'label' => 'Color'),
												array('property' => 'background'),
												array('property' => 'font-size', 'label' => 'Font Size'),
												array('property' => 'font-weight', 'label' => 'Font Weight'),
												array('property' => 'font-style', 'label' => 'Font Style'),
												array('property' => 'font-family', 'label' => 'Font Family'),
												array('property' => 'text-align', 'label' => 'Text Align'),
												array('property' => 'text-shadow', 'label' => 'Text Shadow'),
												array('property' => 'text-transform', 'label' => 'Text Transform'),
												array('property' => 'text-decoration', 'label' => 'Text Decoration'),
												array('property' => 'line-height', 'label' => 'Line Height'),
												array('property' => 'letter-spacing', 'label' => 'Letter Spacing'),
												array('property' => 'overflow', 'label' => 'Overflow'),
												array('property' => 'word-break', 'label' => 'Word Break'),					
											),
											'Thumb Warp' => array(
												array('property' => 'background', 'label' => 'Background', 'selector' => '.member-thumb'),
												array('property' => 'color', 'label' => 'Color', 'selector' => '.member-thumb'),
												array('property' => 'display', 'label' => 'Display', 'selector' => '.member-thumb'),
												array('property' => 'width', 'label' => 'Width', 'selector' => '.member-thumb'),
												array('property' => 'height', 'label' => 'Height', 'selector' => '.member-thumb'),
												array('property' => 'transform', 'label' => 'Transform', 'selector' => '.member-thumb'),
												array('property' => 'border', 'label' => 'border', 'selector' => '.member-thumb'),
												array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.member-thumb'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member-thumb'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member-thumb'),
											),
											'Thumb' => array(
												array('property' => 'background', 'label' => 'Background', 'selector' => '.member-thumb img'),
												array('property' => 'color', 'label' => 'Color', 'selector' => '.member-thumb img'),
												array('property' => 'display', 'label' => 'Display', 'selector' => '.member-thumb img'),
												array('property' => 'width', 'label' => 'Width', 'selector' => '.member-thumb img'),
												array('property' => 'height', 'label' => 'Height', 'selector' => '.member-thumb img'),
												array('property' => 'transform', 'label' => 'Transform', 'selector' => '.member-thumb img'),
												array('property' => 'border', 'label' => 'border', 'selector' => '.member-thumb img'),
												array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.member-thumb img'),
												array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.member-thumb img'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member-thumb img'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member-thumb img'),
											),
											'Details Box' => array(
												array('property' => 'background', 'label' => 'Background', 'selector' => '.member-details'),
												array('property' => 'color', 'label' => 'Color', 'selector' => '.member-details'),
												array('property' => 'display', 'label' => 'Display', 'selector' => '.member-details'),
												array('property' => 'width', 'label' => 'Width', 'selector' => '.member-details'),
												array('property' => 'height', 'label' => 'Height', 'selector' => '.member-details'),
												array('property' => 'transform', 'label' => 'Transform', 'selector' => '.member-details'),
												array('property' => 'border', 'label' => 'border', 'selector' => '.member-details'),
												array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.member-details'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member-details'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member-details'),
											),
											'Title' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.member_name'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.member_name'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.member_name'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.member_name'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.member_name'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.member_name'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.member_name'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.member_name'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.member_name'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.member_name'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.member_name'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member_name'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member_name'),
											),
											'Designation' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.member_designation'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.member_designation'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.member_designation'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.member_designation'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.member_designation'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.member_designation'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.member_designation'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.member_designation'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.member_designation'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.member_designation'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.member_designation'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member_designation'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member_designation'),
											),
											'Socials' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.member-social a'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.member-social a'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.member-social a'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.member-social a'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.member-social a'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.member-social a'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.member-social a'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.member-social a'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.member-social a'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.member-social a'),
	                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.member-social a'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.member-social a'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member-social a'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member-social a'),
											),
											'Socials Hover' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.member-social a:hover'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member-social a:hover'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member-social a:hover'),
											),
											'Button' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.member_link'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.member_link'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.member_link'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.member_link'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.member_link'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.member_link'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.member_link'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.member_link'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.member_link'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.member_link'),
	                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.member_link'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.member_link'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member_link'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member_link'),
											),
											'Button Hover' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.member_link:hover'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.member_link:hover'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.member_link:hover'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.member_link:hover'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.member_link:hover'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.member_link:hover'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.member_link:hover'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.member_link:hover'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.member_link:hover'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.member_link:hover'),
	                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.member_link:hover'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.member_link:hover'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member_link:hover'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member_link:hover'),
											),
											'Box' => array(
												array('property' => 'border', 'label' => 'Border'),
												array('property' => 'border-radius', 'label' => 'Border Radius'),
												array('property' => 'background', 'label' => 'Background'),
												array('property' => 'margin', 'label' => 'Margin'),
												array('property' => 'padding', 'label' => 'Padding'),
												array('property' => 'border', 'label' => 'Border'),
												array('property' => 'width', 'label' => 'Width'),
												array('property' => 'height', 'label' => 'Height'),
												array('property' => 'float', 'label' => 'Float'),
												array('property' => 'display', 'label' => 'Display'),
												array('property' => 'box-shadow', 'label' => 'Box Shadow'),
												array('property' => 'overflow', 'Overflow' => 'Opacity'),
												array('property' => 'opacity', 'label' => 'Opacity'),
											),
										),
										array()
									)
								),
		                	),
		                ),
		            ),  // End of elemnt kc_icon 	 
		        )
		    ); // End add map

		}
	}
}

if (!function_exists('saasmaxcore_team_addon_content')) {
	function saasmaxcore_team_addon_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'team_style'         => '',
			'member_thumb'       => '',
			'member_name'        => '',
			'member_designation' => '',
			'show_button'        => 'no',
			'member_button'      => '',
			'show_social_links'  => '',
			'facebook'           => '',
			'twitter'            => '',
			'linkedin'           => '',
			'github'             => '',
			'pinterest'          => '',
			'instagram'          => '',
			'custom_class'       => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		$r_id = rand(5655,5874);
		
		if ( !empty( $member_thumb ) ) {
			$member_thumb = '<div class="member-thumb"><img src="'.esc_url( wp_get_attachment_image_url( $member_thumb, 'full') ).'" alt="'.get_the_title( $member_thumb ).'"></div>';
		}else{
			$member_thumb = '';
		}

		if ( !empty( $member_button ) ) {
			$link = explode('|', $member_button);
		}

		if ( $show_button == 'yes' && !empty( $member_button ) ) {
			$member_link = '<a class="member_link" href="'.esc_url( $link[0] ).'" '.( isset($link[2]) ? 'target="'.$link[2].'"' : '' ).'>'.esc_html( $link[1] ).'</a>';
		}else{
			$member_link = '';
		}

		if( !empty( $member_name ) ){
			$member_name = '<h4 class="member_name">'.esc_html( $member_name ).'</h4>';
		}else{
			$member_name = '';
		}

		if ( !empty( $member_designation ) ) {
			$member_designation = '<p class="member_designation">'.esc_html( $member_designation ).'</p>';
		}else{
			$member_designation = '';
		}

		if ( !empty( $member_name || $member_designation ) ) {
			$member_name_desig = '
			<div class="name-and-designation">
			'.( isset( $member_name ) ? $member_name : '' ).'
			'.( isset( $member_designation ) ? $member_designation : '' ).'
			</div>';
		}

		if ( $facebook  ) {
			$facebook = '<li><a href="'.esc_html( $facebook ).'"><i class="ti ti-facebook"></i></a></li>';
		}else{
			$facebook = '';
		}

		if ( $twitter  ) {
			$twitter = '<li><a href="'.esc_html( $twitter ).'"><i class="ti ti-twitter"></i></a></li>';
		}else{
			$twitter = '';
		}

		if ( $linkedin  ) {
			$linkedin = '<li><a href="'.esc_html( $linkedin ).'"><i class="ti ti-linkedin"></i></a></li>';
		}else{
			$linkedin = '';
		}

		if ( $github  ) {
			$github = '<li><a href="'.esc_html( $github ).'"><i class="ti ti-github"></i></a></li>';
		}else{
			$github = '';
		}

		if ( $pinterest  ) {
			$pinterest = '<li><a href="'.esc_html( $pinterest ).'"><i class="ti ti-pinterest"></i></a></li>';
		}else{
			$pinterest = '';
		}

		if ( $instagram  ) {
			$instagram = '<li><a href="'.esc_html( $instagram ).'"><i class="ti ti-instagram"></i></a></li>';
		}else{
			$instagram = '';
		}

		if ( $show_social_links == 'yes' && !empty( $facebook || $twitter ||  $linkedin || $github || $pinterest || $instagram ) ) {
			$social_links = '<div class="member-social-bookmark"><ul>'.$facebook.$twitter.$linkedin.$github.$pinterest.$instagram.'</ul></div>';
		}else{
			$social_links = '';
		}

		$data = '
		<div class="'.$team_style.' '.esc_attr( implode(' ', $master_class) ).' '.(isset( $custom_class ) ? $custom_class : '').'">
			'.( isset( $member_thumb ) ? $member_thumb : '' ).'
			<div class="member-details">				
				'.( isset( $member_name_desig ) ? $member_name_desig : '' ).'
				'.( isset( $social_links ) ? $social_links : '' ).'
				'.( isset( $member_link  ) ? $member_link  : '' ).'
			</div>
		</div>';

		return $data;
	}
}
add_shortcode('saasmaxcore_team', 'saasmaxcore_team_addon_content');
?>