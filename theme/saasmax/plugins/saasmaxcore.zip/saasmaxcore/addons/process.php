<?php

add_action('init', 'saasmaxcore_process_addon' , 99 );
if(!function_exists('saasmaxcore_process_addon')){
    function saasmaxcore_process_addon(){
       if( function_exists('kc_add_map') ){
           kc_add_map(array(
                'saasmaxcore_process' => array(
                    'name'        => esc_html__('Process','saasmaxcore'),
                    'icon'        => 'bi-list',
                    'description' => esc_html__( 'Use this addon for process list.', 'saasmaxcore' ),
                    'category'    => 'THEME CORE',
                    'params'      => array(
                        'General' => array(
                            array(
                                'name'       => 'process_list',
                                'label'      => esc_html__('Process List','saasmaxcore'),
                                'type'       => 'group',
                                'options'    => array('add_text' => esc_html__('Add New Process', 'saasmaxcore')),
                                'descriptin' => esc_html__( 'click add new and add one by one single process details.', 'saasmaxcore' ),
                                'params'     => array(
                                    array(
                                        'name'  => 'add_process_icon',
                                        'label' => esc_html__('Enable Process Icon','saasmaxcore'),
                                        'type'  => 'toggle',
                                        'value' => 'no',
                                    ),
                                    array(
                                        'name'    => 'icon_type',
                                        'label'   => esc_html__('Icon Type','saasmaxcore'),
                                        'type'    => 'select',
                                        'options' => array(
                                            'font_icon'  => 'Font Icon',
                                            'image_icon' => 'Image Icon',
                                        ),
                                        'value'    => 'font_icon',
                                        'relation' => array(
                                            'parent'    => 'add_process_icon',
                                            'show_when' => 'yes',
                                        )
                                    ),
                                    array(
                                        'name'     => 'font_icon',
                                        'label'    => esc_html__('Select Icon','saasmaxcore'),
                                        'type'     => 'icon_picker',
                                        'relation' => array(
                                            'parent'    => 'icon_type',
                                            'show_when' => 'font_icon',
                                        )
                                    ),
                                    array(
                                        'name'     => 'image_icon',
                                        'label'    => esc_html__('Upload Icon','saasmaxcore'),
                                        'type'     => 'attach_image',
                                        'relation' => array(
                                            'parent'    => 'icon_type',
                                            'show_when' => 'image_icon',
                                        ),
                                        'value' => '',
                                    ),
                                    array(
                                        'name'        => 'title',
                                        'label'       => esc_html__('Title','saasmaxcore'),
                                        'type'        => 'text',
                                        'description' => esc_html__('Set the title.','saasmaxcore'),
                                    ),
                                    array(
                                        'name'    => 'heading_type',
                                        'label'   => esc_html__('Heading Type','saasmaxcore'),
                                        'type'    => 'select',
                                        'options' => array(
                                            'h1'  => 'H1',
                                            'h2'  => 'H2',
                                            'h3'  => 'H3',
                                            'h4'  => 'H4',
                                            'h5'  => 'H5',
                                            'h6'  => 'H6',
                                            'div' => 'DIV',
                                            'p'   => 'P',
                                        ),
                                        'value'       => 'h3',
                                        'description' => esc_html__('Default Heading: H3','saasmaxcore'),
                                    ),
                                    array(
                                        'name'  => 'subtitle',
                                        'label' => esc_html__('Sub Title','saasmaxcore'),
                                        'type'  => 'text',
                                    ),
                                    array(
                                        'name'  => 'description',
                                        'label' => esc_html__('Short Descripton','saasmaxcore'),
                                        'type'  => 'textarea',
                                    ),
                                ),
                            ),
                            array(
                                'name'        => 'custom_class',
                                'label'       => esc_html__('Custom Class','saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__('Add your extra custom class.','saasmaxcore'),
                            ),
                        ),
						'Options' => array(
							array(
								'name'        => 'columns',
								'label'       => esc_html__('Process Columns', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set process columns how many columns you want.', 'saasmaxcore'),
								'options'     => array(
									'col-md-4 col-sm-6 no-padding sm-padding20' => esc_html('Three Columns','saasmaxcore'),
									'col-md-3 col-sm-6 no-padding sm-padding20' => esc_html('Four Columns','saasmaxcore'),
								),
								'value' => 'col-md-3 col-sm-6 no-padding sm-padding20',
							),
						),
                        'Style' => array(
                            array(
                                'name'    => 'saasmaxcore_process_addon_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        "screens" => "any,1024,999,767,479",
                                        'Icon'    => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.area_icon i'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.area_icon i'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.area_icon i'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.area_icon i'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.area_icon i'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.area_icon i'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.area_icon i'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.area_icon i'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.area_icon i'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.area_icon i'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_icon i'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.area_icon i'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_icon i'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_icon i'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_icon i'),
                                        ),
                                        'Image Icon'    => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.process_image_icon'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.process_image_icon'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.process_image_icon'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.process_image_icon'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.process_image_icon'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.process_image_icon'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.process_image_icon'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.process_image_icon'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.process_image_icon'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.process_image_icon'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.process_image_icon'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.process_image_icon'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.process_image_icon'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.process_image_icon'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.process_image_icon'),
                                        ),
                                        'Title' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.area_title'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.area_title'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.area_title'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.area_title'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.area_title'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.area_title'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.area_title'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.area_title'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.area_title'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_title'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_title'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_title'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_title'),
                                        ),
                                        'Boxes' => array(
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                        ),
                                        'Boxes Hover' => array(
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
           ));
       }
    }
}

if( ! function_exists('saasmaxcore_process_content') ){
    function saasmaxcore_process_content( $atts , $content = '' ){
        extract( $atts );
        $master_class = apply_filters( 'kc-el-class', $atts );

        $content_array = array();
        foreach ( $process_list as $single_process ) {

            extract($content = array(
                'enable_icon'  => $single_process->add_process_icon,
                'icon_type'    => $single_process->icon_type,
                'font_icon'    => $single_process->font_icon,
                'image_icon'   => $single_process->image_icon,
                'title'        => $single_process->title,
                'heading_type' => $single_process->heading_type,
                'subtitle'     => $single_process->subtitle,
                'description'  => $single_process->description,
            ));

            if ( $enable_icon == 'yes' ) {
                if ( $icon_type == 'font_icon') {
                    $process_icon = '<div class="process-icon process_icon"><i class="'.(isset($font_icon) ? $font_icon : '').'"></i></div>';
                }elseif ($icon_type == 'image_icon') {
                    $image_icon_link = wp_get_attachment_image_url( $image_icon, 'thumbnail' );
                    $process_icon = '<div class="process_image_icon"><img src="'.esc_url( $image_icon_link ).'" alt="'.get_the_title($image_icon).'"></div>';
                }else{
                    $process_icon = '';
                }
            }

            if( !empty( $heading_type ) ){
                $heading = $heading_type;
            }else{
                $heading = 'p';
            }

            if( ! empty($title) ){
                $title = '<'.(isset($heading) ? $heading : '' ).' class="process_title">'.esc_html($title).'</'.(isset($heading) ? $heading : '' ).'>';
            }else{
                $title = '';
            }
            
            if( !empty($subtitle) ){
                $subtitle = '<div class="process_subtitle">'.esc_html($subtitle).'</div>';
            }else{
                $subtitle = '';
            }
            
            if( !empty($description) ){
                $description = '<div class="process_description">'.wpautop(esc_html($description)).'</div>';
            }else{
                $description = '';
            }
            $content_array[]='<div class="'.esc_attr( $columns ).'">
                                <div class="single-process mb30">
                                    '.(isset($process_icon) ? $process_icon : '' ).'
                                    <div class="process-details">
                                    '.(isset($title) ? $title : '' ).
                                    (isset($subtitle) ? $subtitle : '' ).
                                    (isset($description) ? $description : '' ).'
                                    </div>
                                </div>
                            </div>';
        }

        $data = '
        <div class="process-area '.esc_attr( implode( ' ', $master_class ) ).' '.( !empty($custom_class) ? $custom_class : '' ).' ">
            <div class="row no-margin">
                '.implode(' ',$content_array).'
            </div>
        </div>';
        return $data;
    }
}
add_shortcode('saasmaxcore_process','saasmaxcore_process_content');
?>