<?php

add_action('init', 'text_and_icon_box_addon' , 99 );
if(!function_exists('text_and_icon_box_addon')){
    function text_and_icon_box_addon(){
       if( function_exists('kc_add_map') ){
           kc_add_map(array(
                'saasmaxcore_text_and_icon_box' => array(
                    'name'        => esc_html__('Box','saasmaxcore'),
                    'icon'        => 'et et-browser',
                    'description' => esc_html__( 'Use this addon for any box style.', 'saasmaxcore' ),
                    'category'    => 'THEME CORE',
                    'params'      => array(
                        'General' => array(
                            array(
                                'name'    => 'box_style',
                                'label'   => esc_html__('Chose Box Style','saasmaxcore'),
                                'type'    => 'radio_image',
                                'options' => array(
                                    'box-style-1'       => plugins_url( '../assets/img/box-style/1.png', __FILE__ ),
                                    'box-style-2'       => plugins_url( '../assets/img/box-style/2.png', __FILE__ ),
                                    'box-style-3'       => plugins_url( '../assets/img/box-style/3.png', __FILE__ ),
                                    'box-style-4'       => plugins_url( '../assets/img/box-style/4.png', __FILE__ ),
                                    'box-style-5'       => plugins_url( '../assets/img/box-style/5.png', __FILE__ ),
                                    'box-style-6'       => plugins_url( '../assets/img/box-style/6.png', __FILE__ ),
                                    'box-style-7'       => plugins_url( '../assets/img/box-style/7.png', __FILE__ ),
                                    'box-style-8'       => plugins_url( '../assets/img/box-style/8.png', __FILE__ ),
                                    'box-style-9'       => plugins_url( '../assets/img/box-style/9.png', __FILE__ ),
                                    'box-style-10'      => plugins_url( '../assets/img/box-style/10.png', __FILE__ ),
                                    'box-style-11'      => plugins_url( '../assets/img/box-style/11.png', __FILE__ ),
                                    'box-style-12'      => plugins_url( '../assets/img/box-style/12.png', __FILE__ ),
                                    'box-style-13'      => plugins_url( '../assets/img/box-style/13.png', __FILE__ ),
                                    'box-style-14'      => plugins_url( '../assets/img/box-style/14.png', __FILE__ ),
                                    'box-style-15'      => plugins_url( '../assets/img/box-style/15.png', __FILE__ ),
                                    'box-style-16'      => plugins_url( '../assets/img/box-style/16.png', __FILE__ ),
                                    'box-style-17'      => plugins_url( '../assets/img/box-style/17.png', __FILE__ ),
                                    'box-style-18'      => plugins_url( '../assets/img/box-style/18.png', __FILE__ ),
                                    'box-style-19'      => plugins_url( '../assets/img/box-style/19.png', __FILE__ ),
                                    'box-style-20'      => plugins_url( '../assets/img/box-style/20.png', __FILE__ ),
                                    'box-style-21'      => plugins_url( '../assets/img/box-style/21.png', __FILE__ ),
                                    'box-style-22'      => plugins_url( '../assets/img/box-style/22.png', __FILE__ ),
                                    'box-style-23'      => plugins_url( '../assets/img/box-style/23.png', __FILE__ ),
                                    'box-style-24'      => plugins_url( '../assets/img/box-style/24.png', __FILE__ ),
                                    'box-style-25'      => plugins_url( '../assets/img/box-style/25.png', __FILE__ ),
                                    'box-style-26'      => plugins_url( '../assets/img/box-style/26.png', __FILE__ ),
                                    'box-style-27'      => plugins_url( '../assets/img/box-style/27.png', __FILE__ ),
                                    'box-style-28'      => plugins_url( '../assets/img/box-style/28.png', __FILE__ ),
                                    'box-style-29'      => plugins_url( '../assets/img/box-style/29.png', __FILE__ ),
                                    'box-style-30'      => plugins_url( '../assets/img/box-style/30.png', __FILE__ ),
                                    'box-style-31'      => plugins_url( '../assets/img/box-style/34.png', __FILE__ ),
                                    'box-style-32'      => plugins_url( '../assets/img/box-style/35.png', __FILE__ ),
                                    'box-style-33'      => plugins_url( '../assets/img/box-style/36.png', __FILE__ ),
                                    'box-style-34'      => plugins_url( '../assets/img/box-style/37.png', __FILE__ ),
                                    'box-style-35'      => plugins_url( '../assets/img/box-style/38.png', __FILE__ ),
                                    'box-style-36'      => plugins_url( '../assets/img/box-style/39.png', __FILE__ ),
                                    'box-style-37'      => plugins_url( '../assets/img/box-style/full-image-top.png', __FILE__ ),
                                    'box-style-38'      => plugins_url( '../assets/img/box-style/left-half-image.png', __FILE__ ),
                                    'box-style-39'      => plugins_url( '../assets/img/box-style/right-half-image.png', __FILE__ ),
                                    'box-style-40'      => plugins_url( '../assets/img/box-style/40.png', __FILE__ ),
                                    'box-style-41'      => plugins_url( '../assets/img/box-style/animate-box.png', __FILE__ ),
                                    'box-style-42'      => plugins_url( '../assets/img/box-style/animate-box-2.png', __FILE__ ),
                                    'box-style-43'      => plugins_url( '../assets/img/box-style/43.png', __FILE__ ),
                                    'box-default-style' => plugins_url( '../assets/img/box-style/box_custom_style.png', __FILE__ ),
                                ),
                                'value' => 'box-default-style',
                            ),
                            array(
                                'name'        => 'add_hover',
                                'label'       => esc_html__('Add Hover Effect','saasmaxcore'),
                                'type'        => 'toggle',
                                'description' => esc_html__('Add a box hover style','saasmaxcore'),
                                'value'       => 'no',
                            ),
                            array(
                                'name'    => 'box_hover_style',
                                'label'   => esc_html__('Chose Box Hover Style','saasmaxcore'),
                                'type'    => 'select',
                                'options' => array(
                                    'box-hover-1'       => esc_html__('Bottom Border With Shadow','saasmaxcore'),
                                    'box-hover-2'       => esc_html__('Top Border With Shadow','saasmaxcore'),
                                    'box-hover-3'       => esc_html__('Left Border With Shadow','saasmaxcore'),
                                    'box-hover-4'       => esc_html__('Right Border With Shadow','saasmaxcore'),
                                    'box-hover-5'       => esc_html__('Border Square With Shadow','saasmaxcore'),
                                    'box-hover-6'       => esc_html__('Border Width Animation','saasmaxcore'),
                                    'box-hover-7'       => esc_html__('Border Width Animation 2','saasmaxcore'),
                                    'box-hover-8'       => esc_html__('Background Move Bottom To Top','saasmaxcore'),
                                    'box-hover-9'       => esc_html__('Background Circle Effect Center','saasmaxcore'),
                                    'box-hover-10'      => esc_html__('Background Circle Form Left-Top','saasmaxcore'),
                                    'box-hover-11'      => esc_html__('Background Circle Form Left-Bottom','saasmaxcore'),
                                    'box-hover-12'      => esc_html__('Background Circle Form Right-Top','saasmaxcore'),
                                    'box-hover-13'      => esc_html__('Background Circle Form Right-Bottom','saasmaxcore'),
                                    'box-hover-14'      => esc_html__('Background Circle Form Top','saasmaxcore'),
                                    'box-hover-15'      => esc_html__('Background Circle Form Bottom','saasmaxcore'),
                                    'box-hover-16'      => esc_html__('Background Circle Form Left','saasmaxcore'),
                                    'box-hover-17'      => esc_html__('Background Circle Form Right','saasmaxcore'),
                                    'box-hover-18'      => esc_html__('Left Corner Tringle With Box Shadow','saasmaxcore'),
                                    'box-hover-19'      => esc_html__('Right Corner Tringle With Box Shadow','saasmaxcore'),
                                    'box-hover-20'      => esc_html__('Solid Background Color Change','saasmaxcore'),
                                    'box-default-hover' => esc_html__('Default Or Custom Style','saasmaxcore'),
                                ),
                                'value'    => 'box-default-hover',
                                'relation' => array(
                                    'parent'    => 'add_hover',
                                    'show_when' => 'yes'
                                )
                            ),
                            array(
                                'name'  => 'add_image',
                                'label' => esc_html__('Add Box Big Image','saasmaxcore'),
                                'type'  => 'toggle',
                                'value' => 'no',
                            ),
                            array(
                                'name'     => 'box_image',
                                'label'    => esc_html__('Upload Box Image','saasmaxcore'),
                                'type'     => 'attach_image',
                                'relation' => array(
                                    'parent'    => 'add_image',
                                    'show_when' => 'yes'
                                ),
                                'value' => '',
                            ),
                            array(
                                'name'  => 'add_icon',
                                'label' => esc_html__('Show Box Icon','saasmaxcore'),
                                'type'  => 'toggle',
                                'value' => 'no',
                            ),
                            array(
                                'name'    => 'icon_type',
                                'label'   => esc_html__('Icon Type','saasmaxcore'),
                                'type'    => 'select',
                                'options' => array(
                                    'font_icon'  => esc_html__('Font Icon','saasmaxcore'),
                                    'image_icon' => esc_html__('Image Icon','saasmaxcore'),
                                ),
                                'value'    => 'font_icon',
                                'relation' => array(
                                    'parent'    => 'add_icon',
                                    'show_when' => 'yes'
                                )
                            ),
                            array(
                                'name'     => 'font_icon',
                                'label'    => esc_html__('Select Icon','saasmaxcore'),
                                'type'     => 'icon_picker',
                                'relation' => array(
                                    'parent'    => 'icon_type',
                                    'show_when' => 'font_icon'
                                )
                            ),
                            array(
                                'name'     => 'image_icon',
                                'label'    => esc_html__('Upload Icon','saasmaxcore'),
                                'type'     => 'attach_image',
                                'relation' => array(
                                    'parent'    => 'icon_type',
                                    'show_when' => 'image_icon'
                                ),
                                'value' => '',
                            ),
                            array(
                                'name'  => 'title',
                                'label' => esc_html__('Title','saasmaxcore'),
                                'type'  => 'text'
                            ),
                            array(
                                'name'    => 'heading_type',
                                'label'   => esc_html__('Heading Type','saasmaxcore'),
                                'type'    => 'select',
                                'options' => array(
                                    'h1'  => 'H1',
                                    'h2'  => 'H2',
                                    'h3'  => 'H3',
                                    'h4'  => 'H4',
                                    'h5'  => 'H5',
                                    'h6'  => 'H6',
                                    'div' => 'DIV',
                                    'p'   => 'P',
                                ),
                                'value'       => 'h3',
                                'description' => esc_html__('Default Heading: H3','saasmaxcore'),
                            ),
                            array(
                                'name'        => 'link_title',
                                'label'       => esc_html__('Link Title ?','saasmaxcore'),
                                'description' => esc_html__('If you want to linked in title you can set yes.','saasmaxcore'),
                                'type'        => 'toggle',
                                'value'       => 'no',
                            ),
                            array(
                                'name'        => 'title_link',
                                'label'       => esc_html__('Add title link','saasmaxcore'),
                                'type'        => 'link',
                                'description' => esc_html__('Add the box title link for go any another page.','saasmaxcore'),
                                'relation'    => array(
                                    'parent'    => 'link_title',
                                    'show_when' => 'yes'
                                ),
                                'value' => 'http://yourlink.com|Button Title|_self',
                            ),
                            array(
                                'name'  => 'subtitle',
                                'label' => esc_html__('Sub Title','saasmaxcore'),
                                'type'  => 'text'
                            ),
                            array(
                                'name'  => 'subtitle_position',
                                'label' => esc_html__('Subtitle Position','saasmaxcore'),
                                'type'  => 'select',
                                'options' => array(
                                    'before_title' => esc_html__( 'Before Title', 'saasmaxcore' ),
                                    'after_title' => esc_html__( 'After Title', 'saasmaxcore' ),
                                ),
                                'value' => 'before_title',
                            ),
                            array(
                                'name'  => 'description',
                                'label' => esc_html__('Descripton','saasmaxcore'),
                                'type'  => 'textarea'
                            ),
                            array(
                                'name'        => 'add_button',
                                'label'       => esc_html__('Show Box Button','saasmaxcore'),
                                'type'        => 'toggle',
                                'description' => esc_html__('By default not showing the button.','saasmaxcore'),
                                'value'       => 'no',
                            ),
                            array(
                                'name'        => 'button',
                                'label'       => esc_html__('Add Box Button','saasmaxcore'),
                                'type'        => 'link',
                                'description' => esc_html__('Add the box button link for go any another page.','saasmaxcore'),
                                'relation'    => array(
                                    'parent'    => 'add_button',
                                    'show_when' => 'yes'
                                ),
                                'value' => 'http://yourlink.com|Button Title',
                            ),                            
                            array(
                                'name'        => 'add_button_icon',
                                'label'       => esc_html__('Show Button Icon','saasmaxcore'),
                                'type'        => 'toggle',
                                'description' => esc_html__('By default not showing the button icon.','saasmaxcore'),
                                'relation'    => array(
                                    'parent'    => 'add_button',
                                    'show_when' => 'yes'
                                ),
                                'value' => 'no',
                            ),
                            array(
                                'name'        => 'button_icon',
                                'label'       => esc_html__('Box Button Icon','saasmaxcore'),
                                'type'        => 'icon_picker',
                                'description' => esc_html__('Add the box button icon.','saasmaxcore'),
                                'relation'    => array(
                                    'parent'    => 'add_button_icon',
                                    'show_when' => 'yes'
                                ),
                                'value' => 'sl sl-star',
                            ),
                            array(
                                'name'        => 'custom_class',
                                'label'       => esc_html__('Custom Class','saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__('Add your extra custom class.','saasmaxcore'),
                            ),
                        ),
                        'Style' => array(
                            array(
                                'name'    => 'text_and_icon_box_addon_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        "screens"   => "any,1024,999,767,479",
                                        'Big Image' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.box-image'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.box-image'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.box-image'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.box-image'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.box-image'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.box-image'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.box-image'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.box-image'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.box-image'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.box-image'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.box-image'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.box-image'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.box-image'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.box-image'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.box-image'),
                                        ),
                                        'Icon' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.box-icon,.box-img-icon'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.box-icon,.box-img-icon'),
                                        ),
                                        'Icon Img' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.box-img-icon img'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.box-img-icon img'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.box-img-icon img'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.box-img-icon img'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.box-img-icon img'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.box-img-icon img'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.box-img-icon img'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.box-img-icon img'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.box-img-icon img'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.box-img-icon img'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.box-img-icon img'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.box-img-icon img'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.box-img-icon img'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.box-img-icon img'),
                                        ),
                                        'Title' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.box-title'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.box-title'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.box-title'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.box-title'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.box-title'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.box-title'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.box-title'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.box-title'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.box-title'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.box-title'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.box-title'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.box-title'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.box-title'),
                                        ),
                                        'Subtitle' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.box-subtitle'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.box-subtitle'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.box-subtitle'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.box-subtitle'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.box-subtitle'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.box-subtitle'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.box-subtitle'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.box-subtitle'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.box-subtitle'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.box-subtitle'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.box-subtitle'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.box-subtitle'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.box-subtitle'),
                                        ),
                                        'Button' => array(
                                            array('property' => 'color','label' => 'Color','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'background-color','label' => 'Background Color','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'display','label' => 'Display','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'font-family','label' => 'Font Family','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'font-size','label' => 'Font Size','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'font-weight','label' => 'Font Weight','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'line-height','label' => 'Line Height','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'text-transform','label' => 'Text Transform','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'text-align','label' => 'Text Align','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'letter-spacing','label' => 'Letter Spacing','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'border','label' => 'Border','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'border-color','label' => 'Border Color','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'border-radius','label' => 'Border Radious','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'box-shadow','label' => 'Box Shadow','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'margin','label' => 'Margin','selector' => '.box-button,.box-icon-button'),
                                            array('property' => 'padding','label' => 'Padding','selector' => '.box-button,.box-icon-button'),
                                        ),
                                        'Button Hover' => array(
                                            array('property' => 'background-color','label' => 'Background Color','selector' => '.box-button:hover,.box-icon-button:hover'),
                                            array('property' => 'color','label' => 'Color','selector' => '.box-button:hover,.box-icon-button:hover'),
                                            array('property' => 'border','label' => 'Border','selector' => '.box-button:hover,.box-icon-button:hover'),
                                            array('property' => 'border-color','label' => 'Border Color','selector' => '.box-button:hover,.box-icon-button:hover'),
                                            array('property' => 'border-radius','label' => 'Border Radious','selector' => '.box-button:hover,.box-icon-button:hover'),
                                            array('property' => 'box-shadow','label' => 'Box Shadow','selector' => '.box-button:hover,.box-icon-button:hover'),
                                            array('property' => 'font-weight','label' => 'Font Weight','selector' => '.box-button:hover,.box-icon-button:hover'),
                                            array('property' => 'letter-spacing','label' => 'Letter Spacing','selector' => '.box-button:hover,.box-icon-button:hover'),
                                            array('property' => 'margin','label' => 'Margin','selector' => '.box-button:hover,.box-icon-button:hover'),
                                            array('property' => 'padding','label' => 'Padding','selector' => '.box-button:hover,.box-icon-button:hover'),
                                        ),
                                        'Detail Box' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.details-box'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.details-box'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.details-box'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.details-box'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.details-box'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.details-box'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.details-box'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.details-box'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.details-box'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.details-box'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.details-box'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.details-box'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.details-box'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.details-box'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.details-box'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.details-box'),
                                        ),
                                        'Boxes' => array(
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'background', 'label' => 'Background'),
                                            array('property' => 'color', 'label' => 'Color'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'overflow', 'label' => 'Overflow' ),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                        ),
                                        'Before' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':before'),
                                        ),
                                        'After' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':after'),
                                        ),
                                        'Box Hover' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':hover'),
                                            array('property' => 'color', 'label' => 'Color', 'selector' => ':hover'),
                                            array('property' => 'color', 'label' => 'Icon Color', 'selector' => ':hover .box-icon'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':hover .box-icon'),
                                            array('property' => 'filter', 'label' => 'Icon Filter', 'selector' => ':hover .box-icon,:hover .box-img-icon'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':hover .box-icon,:hover .box-img-icon'),
                                            array('property' => 'custom', 'label' => 'Icon Custom Css' , 'selector' => ':hover .box-icon,:hover .box-img-icon'),
                                            array('property' => 'color', 'label' => 'Title Color', 'selector' => ':hover .box-title'),

                                            array('property' => 'color', 'label' => 'Button Color', 'selector' => ':hover a.box-button'),
                                            array('property' => 'background-color', 'label' => 'Button Background Color', 'selector' => ':hover a.box-button'),
                                            array('property' => 'color', 'label' => 'Icon Button Color', 'selector' => ':hover a.box-icon-button'),
                                            array('property' => 'background-color', 'label' => 'Icon Button Background Color', 'selector' => ':hover a.box-icon-button'),

                                            array('property' => 'box-shadow', 'label' => 'Box Shadow' , 'selector' => ':hover'),
                                            array('property' => 'transform', 'label' => 'Transform' , 'selector' => ':hover'),

                                            array('property' => 'opacity', 'label' => 'Before Opacity' , 'selector' => ':hover:before'),
                                            array('property' => 'background', 'label' => 'Before Background' , 'selector' => ':hover:before'),
                                            array('property' => 'transform', 'label' => 'Transform' , 'selector' => ':hover:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius' , 'selector' => ':hover:before'),
                                            array('property' => 'custom', 'label' => 'Before Custom Css' , 'selector' => ':hover:before'),
                                            array('property' => 'opacity', 'label' => 'After Opacity' , 'selector' => ':hover:after'),
                                            array('property' => 'background', 'label' => 'After Background' , 'selector' => ':hover:after'),
                                            array('property' => 'transform', 'label' => 'Transform' , 'selector' => ':hover:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius' , 'selector' => ':hover:after'),
                                            array('property' => 'custom', 'label' => 'After Custom Css' , 'selector' => ':hover:after'),
                                        ),
                                    )
                                ),
                            )
                        ),
                        'Animate' => array(
                            array(
                                'name'  => 'animate',
                                'label' => esc_html__('Animate','saasmaxcore'),
                                'type'  => 'animate',
                            ),
                        ),
                    )
                )            
           ));
       } 
    }
}


if( ! function_exists('text_and_icon_box_addon_content') ){
    function text_and_icon_box_addon_content( $atts , $content = '' ){
        extract(shortcode_atts(array(
            'box_style'       => '',
            'add_hover'       => '',
            'box_hover_style' => '',

            'add_image' => '',
            'box_image' => '',

            'add_icon'      => '',
            'icon_type'     => '',
            'font_icon'     => '',
            'image_icon'    => '',
            'icon_position' => 'left',

            'title'        => '',
            'heading_type' => '',
            'link_title' => '',
            'title_link' => '',

            'subtitle'     => '',
            'subtitle_position'     => '',
            'description'  => '',

            'add_button'      => '',
            'button'          => '',
            'add_button_icon' => '',
            'button_icon'     => '',

            'custom_class' => ''
        ), $atts ));
        
        // KC MASTER CLASSES
        $master_class = apply_filters( 'kc-el-class', $atts );

        // GET BOX STYLE CLASS
        switch ($box_style) {
            case 'box-style-1':
                $box_style = 'box-style-1 center';
                break;
            
            case 'box-style-2':
                $box_style = 'box-style-2';
                break;
            
            case 'box-style-3':
                $box_style = 'box-style-3 right';
                break;
            
            case 'box-style-4':
                $box_style = 'box-style-4 center';
                break;
            
            case 'box-style-5':
                $box_style = 'box-style-5';
                break;
            
            case 'box-style-6':
                $box_style = 'box-style-6 right';
                break;
            
            case 'box-style-7':
                $box_style = 'box-style-7 center';
                break;
            
            case 'box-style-8':
                $box_style = 'box-style-8';
                break;
            
            case 'box-style-9':
                $box_style = 'box-style-9 right';
                break;
            
            case 'box-style-10':
                $box_style = 'box-style-10 center';
                break;
            
            case 'box-style-11':
                $box_style = 'box-style-11';
                break;
            
            case 'box-style-12':
                $box_style = 'box-style-12 right';
                break;

            case 'box-style-13':
                $box_style = 'box-style-13 center';
                break;
            
            case 'box-style-14':
                $box_style = 'box-style-14';
                break;
            
            case 'box-style-15':
                $box_style = 'box-style-15 right';
                break;

            case 'box-style-16':
                $box_style = 'box-style-16 center';
                break;
            
            case 'box-style-17':
                $box_style = 'box-style-17';
                break;
            
            case 'box-style-18':
                $box_style = 'box-style-18 right';
                break;

            case 'box-style-19':
                $box_style = 'box-style-19 center';
                break;
            
            case 'box-style-20':
                $box_style = 'box-style-20';
                break;
            
            case 'box-style-21':
                $box_style = 'box-style-21 right';
                break;

            case 'box-style-22':
                $box_style = 'box-style-22 center';
                break;
            
            case 'box-style-23':
                $box_style = 'box-style-23';
                break;
            
            case 'box-style-24':
                $box_style = 'box-style-24 right';
                break;
            
            case 'box-style-25':
                $box_style = 'box-style-25 icon-pos-left';
                break;
            
            case 'box-style-26':
                $box_style = 'box-style-26 right icon-pos-right';
                break;
            
            case 'box-style-27':
                $box_style = 'box-style-27 icon-pos-left';
                break;
            
            case 'box-style-28':
                $box_style = 'box-style-28 right icon-pos-right';
                break;

            case 'box-style-29':
                $box_style = 'box-style-29 icon-pos-left';
                break;
            
            case 'box-style-30':
                $box_style = 'box-style-30 right icon-pos-right';
                break;

            case 'box-style-31':
                $box_style = 'box-style-31 icon-pos-left';
                break;
            
            case 'box-style-32':
                $box_style = 'box-style-32 right icon-pos-right';
                break;

            case 'box-style-33':
                $box_style = 'box-style-33 icon-pos-left';
                break;
            
            case 'box-style-34':
                $box_style = 'box-style-34 right icon-pos-right';
                break;

            case 'box-style-35':
                $box_style = 'box-style-35 icon-pos-left';
                break;
            
            case 'box-style-36':
                $box_style = 'box-style-36 right icon-pos-right';
                break;

            case 'box-style-37':
                $box_style = 'box-style-37 center';
                break;
            
            case 'box-style-38':
                $box_style = 'box-style-38 image-pos-left';
                break;
            
            case 'box-style-39':
                $box_style = 'box-style-39 right image-pos-right';
                break;
            
            case 'box-style-40':
                $box_style = 'box-style-40 center';
                break;

            case 'box-style-41':
                $box_style = 'box-style-41 center animate-icon';
                break;

            case 'box-style-42':
                $box_style = 'box-style-42 animate-bg';
                break;

            case 'box-style-43':
                $box_style = 'box-style-43';
                break;
            
            case 'box-default-style':
                $box_style = 'box-default-style';
                break;
            
            default:
                $box_style = 'box-default-style';
                break;
        }

        //GET HOVER STYLE
        switch ($box_hover_style) {
            case 'box-hover-1':
                $box_hover = 'box-hover-1';
                break;

            case 'box-hover-2':
                $box_hover = 'box-hover-2';
                break;

            case 'box-hover-3':
                $box_hover = 'box-hover-3';
                break;

            case 'box-hover-4':
                $box_hover = 'box-hover-4';
                break;

            case 'box-hover-5':
                $box_hover = 'box-hover-5';
                break;

            case 'box-hover-6':
                $box_hover = 'box-hover-6';
                break;

            case 'box-hover-7':
                $box_hover = 'box-hover-7';
                break;

            case 'box-hover-8':
                $box_hover = 'box-hover-8';
                break;

            case 'box-hover-9':
                $box_hover = 'box-hover-9';
                break;

            case 'box-hover-10':
                $box_hover = 'box-hover-10';
                break;

            case 'box-hover-11':
                $box_hover = 'box-hover-11';
                break;

            case 'box-hover-12':
                $box_hover = 'box-hover-12';
                break;

            case 'box-hover-13':
                $box_hover = 'box-hover-13';
                break;

            case 'box-hover-14':
                $box_hover = 'box-hover-14';
                break;

            case 'box-hover-15':
                $box_hover = 'box-hover-15';
                break;

            case 'box-hover-16':
                $box_hover = 'box-hover-16';
                break;

            case 'box-hover-17':
                $box_hover = 'box-hover-17';
                break;

            case 'box-hover-18':
                $box_hover = 'box-hover-18';
                break;

            case 'box-hover-19':
                $box_hover = 'box-hover-19';
                break;

            case 'box-hover-20':
                $box_hover = 'box-hover-20';
                break;

            default:
                $box_hover = 'box-default-hover';
                break;
        }

        // HEADING
        if( !empty( $heading_type ) ){
            $heading = $heading_type;
        }else{
            $heading = 'p';
        }    

        // BOX IMAGE
        if ($add_image == 'yes') {
            if ( !empty( $box_image ) ) {
                $box_image_link = wp_get_attachment_image_url( $box_image, 'full' );            
                $box_image = '<div class="box-image"><img src="'.esc_url( $box_image_link ).'" alt="'.get_the_title().'"></div>';
            }else{
                $box_image = '';
            }            
        }

        // ICON
        if ( $add_icon == 'yes' ) {

            if ( $icon_type == 'font_icon') {
                $icon = '<div class="box-icon"><i class="'.(isset($font_icon) ? $font_icon : '').'"></i></div>';
            }elseif ($icon_type == 'image_icon') {
                $image_icon_link = wp_get_attachment_image_url( $image_icon, 'full' );
                $icon = '<div class="box-img-icon"><img src="'.esc_url( $image_icon_link ).'" alt="'.get_the_title().'"></div>';
            }else{
                $icon = '';
            }
        }

        // Title Link
        if ( 'yes' == $link_title ) {
            $link = explode( '|', $title_link );

            if ( $link[0] ) {
                $url = $link[0];
            }else{
                $url = '#';
            }
            if ( $link[2] ) {
                $link_target = 'target="'.esc_attr( $link[2] ).'"';
            }else{
                $link_target = '';
            }
        }

        // TITLE
        if( ! empty($title) ){
            if ('yes' == $link_title) {
                $title = '<'.(isset($heading) ? $heading : '' ).' class="box-title"><a href="'.esc_url($url).'" '.esc_attr( $link_target ).'>'.esc_html($title).'</a></'.(isset($heading) ? $heading : '' ).'>';
            }else{
                $title = '<'.(isset($heading) ? $heading : '' ).' class="box-title">'.esc_html($title).'</'.(isset($heading) ? $heading : '' ).'>';
            }
        }else{
            $title = '';
        }
        
        // SUBTITLE
        if( !empty($subtitle) ){
            $subtitle = '<div class="box-subtitle">'.esc_html($subtitle).'</div>';
        }else{
            $subtitle = '';
        }

        if ( 'before_title' == $subtitle_position ) {
            $title_content = $subtitle . $title;
        }elseif ( 'after_title' == $subtitle_position ) {
            $title_content = $title . $subtitle;
        }
        
        // DESCRIPTION
        if( !empty($description) ){
            $description = '<div class="box-description">'.wpautop(esc_html($description)).'</div>';
        }else{
            $description = '';
        }
        
        // LINK
        $button_array = explode( '|', $button );
        if ( !empty( $button_array[0] ) ) {
           $link = $button_array[0];
        }else{
            $link = '';
        }

        if ( !empty( $button_array[1] ) ) {
           $button_name = $button_array[1];
        }else{
            $button_name = '';
        }

        if ( !empty( $button_array[2] ) ) {
           $button_target= 'target="'.esc_attr( $button_array[2] ).'"';
        }else{
            $button_target = '';
        }

        if ( $add_button_icon == 'yes' ) {
            $button_icon = '<i class="'.esc_attr( $button_icon ).'"></i>';
        }else{
            $button_icon = '';
        }

        if ( $add_button == 'yes' ) {
            if ( $add_button_icon == 'yes' ) {                
                $button = '<a href="'.esc_url( $link ).'" '.$button_target.' class="box-icon-button">'.$button_icon.'</a>';
            }else{
                $button = '<a href="'.esc_url( $link ).'" '.$button_target.' class="box-button">'.esc_html( $button_name ).'</a>';
            }
        }else{
            $button = '';
        }
        
        // MAIN SHORTCODE RETURN DATA
        $data = '
        <div class="text-icon-box '.esc_attr( implode( ' ', $master_class ) ).' '.( !empty($custom_class) ? $custom_class : '' ).' '.esc_attr( $box_style ).' '.esc_attr( $box_hover ).'">'.
            ( isset($box_image) ? $box_image : '' ).
            '<div class="details-box">'.
                ( isset($icon) ? $icon : '' ).
                (isset($title_content) ? $title_content : '' ).
                (isset($description) ? $description : '' ).
                (isset($button) ? $button : '' ).
            '</div>
        </div>';
        return $data;
        
    }
}
add_shortcode('saasmaxcore_text_and_icon_box','text_and_icon_box_addon_content');
?>