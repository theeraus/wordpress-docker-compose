<?php

add_action('init', 'saasmaxcore_countdown_timer_circle_addon', 99);
if (!function_exists('saasmaxcore_countdown_timer_circle_addon')) {
	function saasmaxcore_countdown_timer_circle_addon() {
		if (function_exists('kc_add_map')) {
		    kc_add_map(
		        array(	 
		            'saasmaxcore_countdown_timer' => array(
		                'name'        => esc_html__( 'Circle Count Down','chariy-toolkit'),
		                'description' => esc_html__('Use this addon of count down time.', 'chariy-toolkit'),
		                'icon'        => 'bi-refresh-time',
		                'category'    => 'THEME CORE',
		                'params'      => array(
		                	'Genaral' => array(
			                    array(
			                        'name'    => 'days',
			                        'label'   => esc_html__('Set Date',	'chariy-toolkit'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 1,
										'max'        => 31,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the any date less then 31 any date of month.', 'chariy-toolkit'),
			                        'value'       => '15',
			                    ),
			                    array(
			                        'name'    => 'month',
			                        'label'   => esc_html__('Set Month',	'chariy-toolkit'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 1,
										'max'        => 12,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the month any month of the year max value 12 and min value 1.', 'chariy-toolkit'),
			                        'value'       => '1',
			                    ),
			                    array(
			                        'name'    => 'year',
			                        'label'   => esc_html__('Set The Year','chariy-toolkit'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 2018,
										'max'        => 2050,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the year like 2018,2019.', 'chariy-toolkit'),
			                        'value'       => '2018',
			                    ),
			                    array(
			                        'name'    => 'hours',
			                        'label'   => esc_html__('Set Hours',	'chariy-toolkit'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 00,
										'max'        => 24,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the hour max value 24 hours.', 'chariy-toolkit'),
			                        'value'       => '00',
			                    ),
			                    array(
			                        'name'    => 'minutes',
			                        'label'   => esc_html__('Set Minutes',	'chariy-toolkit'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 00,
										'max'        => 60,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the minutes max value 59 and minmum value is 0.', 'chariy-toolkit'),
			                        'value'       => '00',
			                    ),
			                    array(
			                        'name'    => 'seconds',
			                        'label'   => esc_html__('Set Seconds','chariy-toolkit'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 00,
										'max'        => 60,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the seconds max value 59 and minmum value is 0.', 'chariy-toolkit'),
			                        'value'       => '00',
			                    ),
			                    array(
			                        'name'        => 'custom_class',
			                        'label'       => esc_html__('Custom Class','chariy-toolkit'),
			                        'type'        => 'text',
			                        'description' => esc_html__('Add your extra custom class.', 'chariy-toolkit'),
			                    ),
		                	),
		                	'Colors' => array(
			                    array(
			                        'name'        => 'circle_bg_color',
			                        'label'       => esc_html__('Circle Background','chariy-toolkit'),
			                        'type'        => 'color_picker',
			                        'description' => esc_html__('Set the circle background color.', 'chariy-toolkit'),
			                        'value'       => '#f3f3f3',
			                    ),
			                    array(
			                        'name'        => 'days_circle_color',
			                        'label'       => esc_html__('Days Circle Bar Color','chariy-toolkit'),
			                        'type'        => 'color_picker',
			                        'description' => esc_html__('Set the days circle bar color.', 'chariy-toolkit'),
			                        'value'       => '#ef296c',
			                    ),
			                    array(
			                        'name'        => 'hours_circle_color',
			                        'label'       => esc_html__('Hours Circle Bar Color','chariy-toolkit'),
			                        'type'        => 'color_picker',
			                        'description' => esc_html__('Set the hours circle bar color.', 'chariy-toolkit'),
			                        'value'       => '#18bfc3',
			                    ),
			                    array(
			                        'name'        => 'minutes_circle_color',
			                        'label'       => esc_html__('Mnutes Circle Bar Color','chariy-toolkit'),
			                        'type'        => 'color_picker',
			                        'description' => esc_html__('Set the minutes circle bar color.', 'chariy-toolkit'),
			                        'value'       => '#ffd200',
			                    ),
			                    array(
			                        'name'        => 'seconds_circle_color',
			                        'label'       => esc_html__('Seconds Circle Bar Color','chariy-toolkit'),
			                        'type'        => 'color_picker',
			                        'description' => esc_html__('Set the seconds circle bar color.', 'chariy-toolkit'),
			                        'value'       => '#182eff',
			                    ),
			                    array(
			                        'name'        => 'circle_bg_width',
			                        'label'       => esc_html__('Circle Background Width','chariy-toolkit'),
			                        'type'        => 'number_slider',
			                        'description' => esc_html__('Set the circle background width.', 'chariy-toolkit'),
			                        'options'     => array(
										'min'        => 0.5,
										'max'        => 10,
										'show_input' => true
									),
			                        'value' => '8.5',
			                    ),
			                    array(
			                        'name'        => 'circle_counter_width',
			                        'label'       => esc_html__('Circle Counter Width','chariy-toolkit'),
			                        'type'        => 'number_slider',
			                        'description' => esc_html__('Set the circle counter width.', 'chariy-toolkit'),
			                        'options'     => array(
										'min'        => 1,
										'max'        => 9,
										'show_input' => true
									),
			                        'value' => '1',
			                    ),
			                    array(
			                        'name'        => 'start_angle',
			                        'label'       => esc_html__('Start Angle','chariy-toolkit'),
			                        'type'        => 'number_slider',
			                        'description' => esc_html__('Set the circle start angle.', 'chariy-toolkit'),
			                        'options'     => array(
										'min'        => 0,
										'max'        => 360,
										'show_input' => true
									),
			                        'value' => '0',
			                    ),
		                	),
		                	'Style'	=>	array(
								array(
			                		'name'    => 'saasmaxcore_countdown_timer_circle_addon_style',
			                		'type'    => 'css',
			                		'options' => array(
										array(
											'screens'    => "any,1024,999,767,479",
											'Typography' => array(
												array('property' => 'color', 'label' => 'Color'),
												array('property' => 'background'),
												array('property' => 'font-size', 'label' => 'Font Size'),
												array('property' => 'font-weight', 'label' => 'Font Weight'),
												array('property' => 'font-style', 'label' => 'Font Style'),
												array('property' => 'font-family', 'label' => 'Font Family'),
												array('property' => 'text-align', 'label' => 'Text Align'),
												array('property' => 'text-shadow', 'label' => 'Text Shadow'),
												array('property' => 'text-transform', 'label' => 'Text Transform'),
												array('property' => 'text-decoration', 'label' => 'Text Decoration'),
												array('property' => 'line-height', 'label' => 'Line Height'),
												array('property' => 'letter-spacing', 'label' => 'Letter Spacing'),
												array('property' => 'overflow', 'label' => 'Overflow'),
												array('property' => 'word-break', 'label' => 'Word Break'),					
											),
											'Coount Text' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.time_circles > div span'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.time_circles > div span'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.time_circles > div span'),
											),
											'Count Hidding' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.time_circles > div h4'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.time_circles > div h4'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.time_circles > div h4'),
											),
											'Box' => array(
												array('property' => 'margin', 'label' => 'Margin'),
												array('property' => 'padding', 'label' => 'Padding'),
												array('property' => 'border', 'label' => 'Border'),
												array('property' => 'width', 'label' => 'Width'),
												array('property' => 'height', 'label' => 'Height'),
												array('property' => 'border-radius', 'label' => 'Border Radius'),
												array('property' => 'float', 'label' => 'Float'),
												array('property' => 'display', 'label' => 'Display'),
												array('property' => 'box-shadow', 'label' => 'Box Shadow'),
												array('property' => 'opacity', 'label' => 'Opacity'),
											),
										),
										array()
									)
								),
		                	),
		                ),
		            ),  // End of elemnt kc_icon 	 
		        )
		    ); // End add map

		}
	}
}

if (!function_exists('saasmaxcore_countdown_timer_circle_addon_content')) {
	function saasmaxcore_countdown_timer_circle_addon_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'days'                 => '',
			'month'                => '',
			'year'                 => '',
			'hours'                => '',
			'minutes'              => '',
			'seconds'              => '',
			'circle_bg_color'      => '',
			'days_circle_color'    => '',
			'hours_circle_color'   => '',
			'minutes_circle_color' => '',
			'seconds_circle_color' => '',
			'circle_bg_width'      => '',
			'circle_counter_width' => '',
			'start_angle'          => '',
			'custom_class'         => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		$r_id = rand(5655,5874);
		
		if ( !empty( $days ) ) {
			$days = $days;
		}else{
			$days = '1';
		}

		if ( !empty( $month ) ) {
			$month = $month;
		}else{
			$month = '1';
		}

		if ( !empty( $year ) ) {
			$year = $year;
		}else{
			$year = '2020';
		}
		$dyas_warapper = $year . ' '.$month.' '.$days;

		if ( !empty( $hours ) ) {
			$hours = $hours;
		}else{
			$hours = '24';
		}

		if ( !empty( $minutes ) ) {
			$minutes = $minutes;
		}else{
			$minutes = '30';
		}

		if ( !empty( $seconds ) ) {
			$seconds = $seconds;
		}else{
			$seconds = '00';
		}
		$hours_warapper = $hours . ':'.$minutes.':'.$seconds;


		if ( !empty( $circle_bg_color ) ) {
			$circle_bg_color = $circle_bg_color;
		}else{
			$circle_bg_color = '#f3f3f3';
		}

		if ( !empty( $days_circle_color ) ) {
			$days_circle_color = $days_circle_color;
		}else{
			$days_circle_color = '#ef296c';
		}

		if ( !empty( $hours_circle_color ) ) {
			$hours_circle_color = $hours_circle_color;
		}else{
			$hours_circle_color = '#18bfc3';
		}

		if ( !empty( $minutes_circle_color ) ) {
			$minutes_circle_color = $minutes_circle_color;
		}else{
			$minutes_circle_color = '#ffd200';
		}

		if ( !empty( $seconds_circle_color ) ) {
			$seconds_circle_color = $seconds_circle_color;
		}else{
			$seconds_circle_color = '#182eff';
		}
        
        if( !empty( $circle_bg_width ) ){
            $bg_width = $circle_bg_width;
        }else{
            $bg_width = 8;
        }
        
        if( !empty( $circle_counter_width ) ){
            $counter_width = $circle_counter_width;
        }else{
            $counter_width = 1;
        }
        
        if( !empty( $start_angle ) ){
            $start_angle = $start_angle;
        }else{
            $start_angle = 0;
        }

		wp_enqueue_style( 'timeCircles');
		wp_enqueue_script( 'timeCircles');

		$data = '
		<script>
			(function($){
			    $(document).on("ready",function(){

					var countdown = $("#count-down-'.$r_id.'");
					createTimeCicles();

					$(window).on("resize", windowSize);
					function windowSize(){
						countdown.TimeCircles().destroy();
						createTimeCicles();
						countdown.on("webkitAnimationEnd mozAnimationEnd oAnimationEnd animationEnd", function() {
							countdown.removeClass("animated fadeIn");
						});
					}

					function createTimeCicles() {
						countdown.addClass("animated fadeIn");
						countdown.TimeCircles({
							circle_bg_color: "'.$circle_bg_color.'",
							use_background : true,
							fg_width       : 0.0'.$counter_width.',
							bg_width       : '.$bg_width.',
                            start_angle: '.$start_angle.',
							time           : {
								Days   : {color: "'.$days_circle_color.'"},
								Hours  : {color: "'.$hours_circle_color.'"},
								Minutes: {color: "'.$minutes_circle_color.'"},
								Seconds: {color: "'.$seconds_circle_color.'"},
							}
						});
						countdown.on("webkitAnimationEnd mozAnimationEnd oAnimationEnd animationEnd", function() {
							countdown.removeClass("animated fadeIn");
						});
					}

			    });
			})(jQuery)
		</script>
		<div class="count-down-timer-one '.esc_attr( implode(' ', $master_class) ).' '.(isset( $custom_class ) ? $custom_class : '').'">
			<div id="count-down-'.$r_id.'" data-date="'.esc_attr( $dyas_warapper ).' '.esc_attr( $hours_warapper ).'"></div>
			'.( isset( $member_thumb ) ? $member_thumb : '' ).'
		</div>';

		return $data;
	}
}
add_shortcode('saasmaxcore_countdown_timer', 'saasmaxcore_countdown_timer_circle_addon_content');
?>