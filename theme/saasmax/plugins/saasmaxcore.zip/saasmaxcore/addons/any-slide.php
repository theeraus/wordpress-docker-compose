<?php

add_action('init', 'any_slider_addon', 99);
if (!function_exists('any_slider_addon')) {
	function any_slider_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'any_slider' => array(
					'name'        => esc_html__('Slide Anything', 'saasmaxcore'),
					'icon'        => 'bi-slider',
					'description' => esc_html__('Use this addon for slide anything.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'nested'		=> true,
					'params'      => array(
						'General' => array(
							array(
								'name'        => 'slider_name',
								'label'       => esc_html__('Name Of Slider', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Set the name of slider.', 'saasmaxcore'),
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Options' => array(
							array(
								'name'        => 'item_on_large',
								'label'       => esc_html__('Item On Large Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on large device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 20,
									'show_input' => true
								),
								'value' => '5',
							),
							array(
								'name'        => 'item_on_medium',
								'label'       => esc_html__('Item On Medium Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on medium device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 20,
									'show_input' => true
								),
								'value' => '5',
							),
							array(
								'name'        => 'item_on_tablet',
								'label'       => esc_html__('Item On Tablet Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on tablet device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 20,
									'show_input' => true
								),
								'value' => '3',
							),
							array(
								'name'        => 'item_on_mobile',
								'label'       => esc_html__('Item On Mobile Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on mobile device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 10,
									'show_input' => true
								),
								'value' => '1',
							),
							array(
								'name'        => 'margin',
								'label'       => esc_html__('Slide Margin', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide margin', 'saasmaxcore'),
								'options'     => array(
									'min'        => 0,
									'max'        => 100,
									'show_input' => true
								),
								'value' => '20',
							),
							array(
								'name'        => 'autoplay',
								'label'       => esc_html__('Slide Autoplay', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set slide autoplay yes or no.', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'false',
							),
							array(
								'name'        => 'autoplaytimeout',
								'label'       => esc_html__('Autoplay Timeout', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide autoplay timeout', 'saasmaxcore'),
								'options'     => array(
									'min'        => 500,
									'max'        => 10000,
									'show_input' => true
								),
								'value' => '2000',
							),
							array(
								'name'        => 'slide_speed',
								'label'       => esc_html__('Slide Speed', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide speed', 'saasmaxcore'),
								'options'     => array(
									'min'        => 500,
									'max'        => 5000,
									'show_input' => true
								),
								'value' => '1000',
							),
							array(
								'name'        => 'loop',
								'label'       => esc_html__('Slide Loop', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider loop yes or no', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'true',
							),
							array(
								'name'        => 'nav',
								'label'       => esc_html__('Slide Navigaion', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider navigation', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'true',
							),
							array(
								'name'        => 'nav_position',
								'label'       => esc_html__('Navigaion Position', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider navigation position', 'saasmaxcore'),
								'options'     => array(
									'inside_nav' => esc_html('Inside','saasmaxcore'),
									'outside_nav'  => esc_html('Outside','saasmaxcore'),
								),
								'value' => 'inside_nav',
							),
							array(
								'name'        => 'nav_next_icon',
								'label'       => esc_html__('Navigaion Next Icon', 'saasmaxcore'),
								'type'        => 'icon_picker',
								'description' => esc_html__('Please set the slider navigation next icon.', 'saasmaxcore'),
								'relation'    => array(
									'show_when' => 'true',
									'parent'    => 'nav',
								),
								'value' => 'sl sl-arrow-right',
							),
							array(
								'name'        => 'nav_prev_icon',
								'label'       => esc_html__('Navigaion Prev Icon', 'saasmaxcore'),
								'type'        => 'icon_picker',
								'description' => esc_html__('Please set the slider navigation prev icon.', 'saasmaxcore'),
								'relation'    => array(
									'show_when' => 'true',
									'parent'    => 'nav',
								),
								'value' => 'sl sl-arrow-left',
							),
							array(
								'name'        => 'dots',
								'label'       => esc_html__('Slide Dots', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider dots', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'false',
							),
							array(
								'name'        => 'center',
								'label'       => esc_html__('Slide Center', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider center', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'false',
							),
							array(
								'name'        => 'fade_slide',
								'label'       => esc_html__('Slide Fade Effect', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('If you want to fadein slide you can set yes', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'false',
							),
						),
						'Style' => array(
							array(
								'name'    => 'any_slider_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										"screens" => "any,1024,999,767,479",
										'SLIDER OUTER'  => array(
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-stage-outer'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-stage-outer'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-stage-outer'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-stage-outer'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-stage-outer'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-stage-outer'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-stage-outer'),
										),
										'SLIDER INNER'  => array(
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-stage'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-stage'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-stage'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-stage'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-stage'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-stage'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-stage'),
										),
										'ITEM'  => array(
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-item'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-item'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-item'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-item'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-item'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-item > div'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-item'),
										),
										'ITEM 2N'  => array(
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-item:nth-child(2n)'),
										),
										'ITEM IMG'  => array(
											array('property' => 'max-width', 'label' => 'Max Width', 'selector' => '.owl-item img'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-item img'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-item img'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-item img'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-item img'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-item img'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-item img'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-item img'),
										),
										'NAV'  => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-nav > div'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-nav > div'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.owl-nav > div'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-nav > div'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-nav > div'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-nav > div'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-nav > div'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-nav > div'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-nav > div'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-nav > div'),
											array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-nav > div'),
										),
										'NAV HOVER'  => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-nav > div:hover'),
										),
										'DOTS WRAP'  => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-dots'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-dots'),
											array('property' => 'text-align', 'label' => 'Align', 'selector' => '.owl-dots'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-dots'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-dots'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-dots'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-dots'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-dots'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-dots'),
											array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-dots'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-dots'),
										),
										'DOTS'  => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-dots > div'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-dots > div'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-dots > div'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-dots > div'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-dots > div'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-dots > div'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-dots > div'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-dots > div'),
											array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-dots > div'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-dots > div'),
										),
										'DOTS HOVER'  => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
											array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-dots > div:hover,.owl-dots > div.active'),
										),
										'BOXES' => array(
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'background', 'label' => 'Background'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'margin', 'label' => 'Margin'),
										),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('any_slider_content')) {
	function any_slider_content($atts, $content = '') {

		extract($atts);
		$r_id          = rand(365,455);
		$master_class  = apply_filters('kc-el-class', $atts);
		$slide_content = do_shortcode( $content );

		$script = '
			;(function($){
				$(window).on("load",function(){
				    var anyCarousel = $(\'#any-slider-'.$r_id.'\');
				    anyCarousel.owlCarousel({
				        merge          : true,
				        smartSpeed     : '.$slide_speed.',
				        loop           : '.$loop.',
				        nav            : '.$nav.',
				        dots           : '.$dots.',
				        center         : '.$center.',
				        navText        : [\'<i class="'.$nav_prev_icon.'"></i>\', \'<i class="'.$nav_next_icon.'"></i>\'],
				        autoplay       : '.$autoplay.',
				        autoplayTimeout: '.$autoplaytimeout.',
				        margin         : '.$margin.',
				        responsiveClass: true,';
				        if ('true' == $fade_slide) {
				        	$script .='
							animateIn:"fadeIn",
							animateOut:"fadeOut",
				        	';
				        }
				        $script.='
				        responsive     : {
				            0: {
				                items: '.$item_on_mobile.'
				            },
				            600: {
				                items: '.$item_on_tablet.'
				            },
				            1000: {
				                items: '.$item_on_medium.'
				            },
				            1200: {
				                items: '.$item_on_medium.'
				            },
				            1900: {
				                items: '.$item_on_large.'
				            }
				        }
				    });
				});
			})(jQuery);
		';
		wp_add_inline_script( 'saasmaxcore', $script );

		$data = '
		<div class="any-slider-area '.esc_attr( ( !empty( $nav_position ) ? $nav_position : '' ) ).'">
			<div id="any-slider-'.$r_id.'" class="any-slider ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
				'.(isset( $slide_content ) ? $slide_content : '').'
			</div>
		</div>';
		return $data;
	}
}
add_shortcode('any_slider', 'any_slider_content');
?>