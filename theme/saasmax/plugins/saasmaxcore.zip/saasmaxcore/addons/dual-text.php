<?php

add_action('init', 'saasmaxcore_dual_text_addon', 99);
if (!function_exists('saasmaxcore_dual_text_addon')) {
	function saasmaxcore_dual_text_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
			'saasmaxcore_dual_text' => array(
				'name'			=> esc_html__( 'Dual Text', 'saasmaxcore' ),
				'category'		=> 'THEME CORE',
				'icon'			=> 'bi-server',
				'description'	=> esc_html__( 'The dual text side by side', 'saasmaxcore' ),
				'params' => array(
					'general' => array(
						array(
							'type'			=> 'textarea',
							'label'			=> esc_html__( 'Left Side Text', 'saasmaxcore' ),
							'name'			=> 'left_text',
							'description'	=> esc_html__( 'The text on the left side', 'saasmaxcore'),
							'value'			=> 'Lorem Ipsum',
						),
						array(
							'type'			=> 'textarea',
							'label'			=> esc_html__( 'Middle Text', 'saasmaxcore' ),
							'name'			=> 'middle_text',
							'description'	=> esc_html__( 'The text on middle', 'saasmaxcore'),
							'value'			=> 'middle text',
						),
						array(
							'type'			=> 'textarea',
							'label'			=> esc_html__( 'Right Side Text', 'saasmaxcore' ),
							'name'			=> 'right_text',
							'description'	=> esc_html__( 'The text on the right side', 'saasmaxcore'),
							'value'			=> 'is simply dummy text.',
						),
                        array(
                            'name'    => 'warper_type',
                            'label'   => esc_html__('Warpper Type','saasmaxcore'),
                            'type'    => 'select',
                            'options' => array(
                                'h1'  => 'H1',
                                'h2'  => 'H2',
                                'h3'  => 'H3',
                                'h4'  => 'H4',
                                'h5'  => 'H5',
                                'h6'  => 'H6',
                                'div' => 'DIV',
                                'p'   => 'P',
                            ),
                            'value'       => 'h3',
                            'description' => esc_html__('Default Wraper: H3','saasmaxcore'),
                        ),
						array(
							'type'			=> 'text',
							'label'			=> esc_html__( 'Extra Class', 'saasmaxcore' ),
							'name'			=> 'extra_class',
							'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							'value'			=> ''
						)
					),
					'styling' => array(
						array(
							'name'	=> 'saasmaxcore_dual_text_style',
							'type'	=> 'css',
							'options' => array(
								array(
									"screens" => "any,1024,999,767,479",
									'Warper' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.dual-text'),
										array('property' => 'background', 'label' => 'Background', 'selector' => '.dual-text'),
										array('property' => 'display', 'label' => 'Display', 'selector' => '.dual-text'),
										array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.dual-text'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.dual-text'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.dual-text'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.dual-text'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.dual-text'),
										array('property' => 'font-style', 'label' => 'Font Style', 'selector' => '.dual-text'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.dual-text'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.dual-text'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.dual-text'),
									),
									'Left Side' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.dual-first'),
										array('property' => 'background', 'label' => 'Background', 'selector' => '.dual-first'),
										array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.dual-first'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.dual-first'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.dual-first'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.dual-first'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.dual-first'),
										array('property' => 'font-style', 'label' => 'Font Style', 'selector' => '.dual-first'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.dual-first'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.dual-first'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.dual-first'),
									),
									'Middle' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.dual-middle'),
										array('property' => 'background', 'label' => 'Background', 'selector' => '.dual-middle'),
										array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.dual-middle'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.dual-middle'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.dual-middle'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.dual-middle'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.dual-middle'),
										array('property' => 'font-style', 'label' => 'Font Style', 'selector' => '.dual-middle'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.dual-middle'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.dual-middle'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.dual-middle'),
									),
									'Right Side' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.dual-last'),
										array('property' => 'background', 'label' => 'Background', 'selector' => '.dual-last'),
										array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.dual-last'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.dual-last'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.dual-last'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.dual-last'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.dual-last'),
										array('property' => 'font-style', 'label' => 'Font Style', 'selector' => '.dual-last'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.dual-last'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.dual-last'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.dual-last'),
									),
									'Box' => array(
										array('property' => 'background', 'label' => 'Background'),
										array('property' => 'text-align', 'label' => 'Text Align'),
										array('property' => 'border', 'label' => 'Border'),
										array('property' => 'border-radius', 'label' => 'Border Radius'),
										array('property' => 'margin', 'label' => 'Margin'),
										array('property' => 'padding', 'label' => 'Padding'),
									)
								)
							)
						)
					),
					'animate' => array(
						array(
							'name'    => 'animate',
							'type'    => 'animate'
						)
					)
				)
			)

			));
		}
	}
}

if (!function_exists('saasmaxcore_dual_text_content')) {
	function saasmaxcore_dual_text_content($atts, $content = '') {
		extract($atts);

		$el_classes = apply_filters( 'kc-el-class', $atts );
		$el_classes[] = 'dual-text-warp';
		if( !empty( $extra_class ) ){
			$el_classes[] = $extra_class;
		}

		if ( !empty( $left_text ) ) {
			$left_text = '<span class="dual-first">'.esc_html( $left_text ).'</span>';
		}else{
			$left_text = '';
		}
		if ( !empty( $middle_text ) ) {
			$middle_text = '<span class="dual-middle">'.esc_html( $middle_text ).'</span>';
		}else{
			$middle_text = '';
		}
		if ( !empty( $right_text ) ) {
			$right_text = '<span class="dual-last">'.esc_html( $right_text ).'</span>';
		}else{
			$right_text = '';
		}

        if( !empty( $warper_type ) ){
            $warper_type = $warper_type;
        }else{
            $warper_type = 'p';
        }

		if ( !empty( $left_text )  || !empty( $right_text ) ) {
			$dual_text = '<'.$warper_type.' class="dual-text">'. $left_text . ' '. $middle_text .' ' . $right_text . '</'.$warper_type.'>';
		}

		$output = '
		<div class="' . esc_attr(implode(' ', $el_classes )) . '">
			'.(isset( $dual_text ) ? $dual_text : '').'
		</div>';
		return $output;
	}
}
add_shortcode('saasmaxcore_dual_text', 'saasmaxcore_dual_text_content');
?>