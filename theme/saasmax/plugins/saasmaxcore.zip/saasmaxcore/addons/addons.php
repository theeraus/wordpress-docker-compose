<?php 
/*------------------------------------------
	COMPOSER CUSTOM ICON IMPLEMENTS
--------------------------------------------*/

add_action('init', 'saasmaxcore_composer_custom_icon');
function saasmaxcore_composer_custom_icon() {

	if( function_exists( 'kc_add_icon' ) ) {
 
		kc_add_icon( plugins_url( '../assets/css/flaticon.css', __FILE__ ) );
		kc_add_icon( plugins_url('../assets/css/icofont.css', __FILE__ ) );
		kc_add_icon( plugins_url('../assets/css/bicon.css', __FILE__ ) );
	}
}

/*------------------------------------------
	KING COMPOSER ADDONS
--------------------------------------------*/


/*---------------------------
	WELCOME ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/welcome.php')) {
	require_once (dirname(__FILE__).'/welcome.php');
}

/*---------------------------
	SLIDER ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/welcome-slider.php')) {
	require_once (dirname(__FILE__).'/welcome-slider.php');
}

if (file_exists(dirname(__FILE__).'/welcome-slider-form.php')) {
	require_once (dirname(__FILE__).'/welcome-slider-form.php');
}

/*---------------------------
	LAYER SCROLL
-----------------------------*/
if (file_exists(dirname(__FILE__).'/layer-scroll.php')) {
	require_once (dirname(__FILE__).'/layer-scroll.php');
}

/*---------------------------
	LAYER ANIMATE
-----------------------------*/
if (file_exists(dirname(__FILE__).'/layer-animate.php')) {
	require_once (dirname(__FILE__).'/layer-animate.php');
}

/*---------------------------
	UNIVERSAL ADDON
-----------------------------*/
if (file_exists(dirname(__FILE__).'/any-widget.php')) {
	require_once (dirname(__FILE__).'/any-widget.php');
}

if (file_exists(dirname(__FILE__).'/any-slide.php')) {
	require_once (dirname(__FILE__).'/any-slide.php');
}

if (file_exists(dirname(__FILE__).'/slide-navigation.php')) {
	require_once (dirname(__FILE__).'/slide-navigation.php');
}

/*---------------------------
	AREA BACKGROUND
----------------------------*/
if (file_exists(dirname(__FILE__).'/area-bg.php')) {
	require_once (dirname(__FILE__).'/area-bg.php');
}

/*---------------------------
	TITLE ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/title.php')) {
	require_once (dirname(__FILE__).'/title.php');
}

/*---------------------------
	AREA HIDDING
----------------------------*/

if (file_exists(dirname(__FILE__).'/hidding.php')) {
	require_once (dirname(__FILE__).'/hidding.php');
}

/*---------------------------
	LIST ADDON
----------------------------*/
if (file_exists(dirname(__FILE__).'/list.php')) {
	require_once (dirname(__FILE__).'/list.php');
}

/*---------------------------
	ICON WITH TEXT ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/box.php')) {
	require_once (dirname(__FILE__).'/box.php');
}

/*---------------------------
	BUTTON ADDON
-----------------------------*/
if (file_exists(dirname(__FILE__).'/button.php')) {
	require_once (dirname(__FILE__).'/button.php');
}
if (file_exists(dirname(__FILE__).'/dual-button.php')) {
	require_once (dirname(__FILE__).'/dual-button.php');
}
if (file_exists(dirname(__FILE__).'/video-button.php')) {
	require_once (dirname(__FILE__).'/video-button.php');
}
if (file_exists(dirname(__FILE__).'/subscriber.php')) {
	require_once (dirname(__FILE__).'/subscriber.php');
}
/*---------------------------
	DUAL TEXT
----------------------------*/
if (file_exists(dirname(__FILE__).'/dual-text.php')) {
	require_once (dirname(__FILE__).'/dual-text.php');
}

/*---------------------------
	IMAGE COMPARISON
----------------------------*/
if (file_exists(dirname(__FILE__).'/image-comparison.php')) {
	require_once (dirname(__FILE__).'/image-comparison.php');
}

/*---------------------------
	IMAGE GALLERY ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/image-gallery.php')) {
	require_once (dirname(__FILE__).'/image-gallery.php');
}

if (file_exists(dirname(__FILE__).'/instafeed.php')) {
	require_once (dirname(__FILE__).'/instafeed.php');
}

if (file_exists(dirname(__FILE__).'/image-carousel.php')) {
	require_once (dirname(__FILE__).'/image-carousel.php');
}

/*---------------------------
	TESTMONIAL ADDON
----------------------------*/
if (file_exists(dirname(__FILE__).'/testmonial.php')) {
	require_once (dirname(__FILE__).'/testmonial.php');
}
if (file_exists(dirname(__FILE__).'/testmonial-single.php')) {
	require_once (dirname(__FILE__).'/testmonial-single.php');
}

/*---------------------------
	BLOG POST ADDON
-----------------------------*/
if (file_exists(dirname(__FILE__).'/blog-post.php')) {
	require_once (dirname(__FILE__).'/blog-post.php');
}
/*if (file_exists(dirname(__FILE__).'/blog-slide.php')) {
	require_once (dirname(__FILE__).'/blog-slide.php');
}*/

/*---------------------------
	TAB SLIDER ADDON
-----------------------------*/
if (file_exists(dirname(__FILE__).'/tab-slider.php')) {
	require_once (dirname(__FILE__).'/tab-slider.php');
}

/*---------------------------
	PRICE TABLE
----------------------------*/
if (file_exists(dirname(__FILE__).'/price.php')) {
	require_once(dirname(__FILE__).'/price.php');
}

/*---------------------------
	PROCESS ADDON
-----------------------------*/
if ( file_exists(dirname(__FILE__).'/process.php') ) {
	require_once(dirname(__FILE__).'/process.php');
}

/*---------------------------
	CAUSES ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/causes.php')) {
	require_once (dirname(__FILE__).'/causes.php');
}
if (file_exists(dirname(__FILE__).'/causes-two.php')) {
	require_once (dirname(__FILE__).'/causes-two.php');
}

/*---------------------------
	TEAM ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/team.php')) {
	require_once (dirname(__FILE__).'/team.php');
}

/*---------------------------
	COUNTDOWN ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/countdown-circle.php')) {
	require_once (dirname(__FILE__).'/countdown-circle.php');
}

/*---------------------------
	COUNTER UP ADDON
----------------------------*/
if (file_exists(dirname(__FILE__).'/counterup.php')) {
	require_once (dirname(__FILE__).'/counterup.php');
}

/*---------------------------
	EVENT ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/event.php')) {
	require_once (dirname(__FILE__).'/event.php');
}

/*---------------------------
	QR CODE ADDONS
-----------------------------*/
if (file_exists(dirname(__FILE__).'/qrcode.php')) {
	require_once (dirname(__FILE__).'/qrcode.php');
}

