<?php

add_action('init', 'saasmaxcore_animate_layers_addon', 99);
if (!function_exists('saasmaxcore_animate_layers_addon')) {
    function saasmaxcore_animate_layers_addon()
    {
        if (function_exists('kc_add_map')) {
            kc_add_map(array(
                'saasmaxcore_animate_layers' => array(
                    'name'        => esc_html__('Animate Layers', 'saasmaxcore'),
                    'icon'        => 'sl-layers',
                    'description' => esc_html__('Use this addon for animateing any layer.', 'saasmaxcore'),
                    'category'    => 'THEME CORE',
                    'params'      => array(
                        'General' => array(
                            array(
                                'name'        => 'all_layers',
                                'label'       => esc_html__('Single Layers', 'saasmaxcore'),
                                'type'        => 'group',
                                'description' => esc_html__('Add single layer for animate.', 'saasmaxcore'),
                                'options'     => array(
									'add_text' => 'Add New Layer',
								),
                                'params' => array(
                                    array(
                                        'name'  => 'layer_no',
                                        'label' => esc_html__('Layer Number', 'saasmaxcore'),
                                        'type'  => 'text',
                                        'value' => '1',
                                    ),
                                    array(
                                        'name'    => 'layer_opacity',
                                        'label'   => esc_html__('Layer Opacity', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array(
                                            'min'        => 0,
                                            'max'        => 9,
                                            'show_input' => true
                                        ),
                                        'value' => 9,
                                    ),
                                    array(
                                        'name'    => 'border_radius',
                                        'label'   => esc_html__('Border Radius', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array(
                                            'min'        => 0,
                                            'max'        => 100,
                                            'unit' => '%',
                                            'show_input' => true
                                        ),
                                        'value' => 0,
                                    ),
                                    array(
                                        'name'    => 'layer_type',
                                        'label'   => esc_html__('Layer Type', 'saasmaxcore'),
                                        'type'    => 'select',
                                        'options' => array(
                                            'font_icon'  => 'Layer Font Icon',
                                            'image_icon' => 'Layer Image',
                                            'color' => 'Layer Color',
                                        ),
                                        'value' => 'image_icon',
                                    ),
                                    array(
                                        'name'     => 'icon_layer',
                                        'label'    => esc_html__('Select Icon', 'saasmaxcore'),
                                        'type'     => 'icon_picker',
                                        'relation' => array(
                                            'parent'    => 'layer_type',
                                            'show_when' => 'font_icon',
                                        ),
                                    ),
                                    array(
                                        'name'     => 'image_layer',
                                        'label'    => esc_html__('Upload Layer', 'saasmaxcore'),
                                        'type'     => 'attach_image',
                                        'relation' => array(
                                            'parent'    => 'layer_type',
                                            'show_when' => 'image_icon',
                                        ),
                                        'value' => '',
                                    ),
                                    array(
                                        'name'     => 'color_layer',
                                        'label'    => esc_html__('Set Color Layer', 'saasmaxcore'),
                                        'type'     => 'color_picker',
                                        'relation' => array(
                                            'parent'    => 'layer_type',
                                            'show_when' => 'color',
                                        ),
                                        'value' => '',
                                    ),
                                    array(
                                        'name'     => 'layer_postion',
                                        'label'    => esc_html__('Set Layer Position From', 'saasmaxcore'),
                                        'description'    => esc_html__('Please set the valu which you want, you need to set specific data like when you select ( From Left Top ) you need to set value layer postion from left and right.', 'saasmaxcore'),
                                        'type'     => 'select',
                                        'options' => array(
                                        	'from_left_top' => esc_html__( 'From Left Top', 'saasmaxcore' ),
                                        	'from_left_bottom' => esc_html__( 'From Left Bottom', 'saasmaxcore' ),
                                        	'from_right_top' => esc_html__( 'From Right Top', 'saasmaxcore' ),
                                        	'from_right_bottom' => esc_html__( 'From Right Bottom', 'saasmaxcore' ),
                                        ),
                                        'value' => 'from_left_top',
                                    ),
                                    array(
                                        'name'    => 'layer_left',
                                        'label'   => esc_html__('Layer Position From Left', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array(
                                            'min'        => -100,
                                            'max'        => 100,
                                            'unit'       => '%',
                                            'show_input' => true
                                        ),
                                        'value' => '0',
                                    ),
                                    array(
                                        'name'    => 'layer_right',
                                        'label'   => esc_html__('Layer Position From Right', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array(
                                            'min'        => -100,
                                            'max'        => 100,
                                            'unit'       => '%',
                                            'show_input' => true
                                        ),
                                        'value' => '0',
                                    ),
                                    array(
                                        'name'    => 'layer_top',
                                        'label'   => esc_html__('Layer Position From Top', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array( 
                                            'min'        => -100,
                                            'max'        => 100,
                                            'unit'       => '%',
                                            'show_input' => true
                                        ),
                                        'value' => '0',
                                    ),
                                    array(
                                        'name'    => 'layer_bottom',
                                        'label'   => esc_html__('Layer Position From Bottom', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array( 
                                            'min'        => -100,
                                            'max'        => 100,
                                            'unit'       => '%',
                                            'show_input' => true
                                        ),
                                        'value' => '0',
                                    ),
                                    array(
                                        'name'    => 'layer_rotate',
                                        'label'   => esc_html__('Layer Rotating Degree', 'saasmaxcore'),
                                        'type'    => 'number_slider',
                                        'options' => array( 
                                            'min'        => -360,
                                            'max'        => 360,
                                            'unit'       => 'deg',
                                            'show_input' => true
                                        ),
                                        'value' => '0',
                                        'description' => esc_html__('Layer rotating degree', 'saasmaxcore'),
                                    ),
                                    array(
                                        'name'    => 'layer_animate',
                                        'label'   => esc_html__('Select single layer animate', 'saasmaxcore'),
                                        'type'    => 'animate',
                                    ),
                                    /*array(
                                        'name'    => 'custom_css',
                                        'label'   => esc_html__('Select single layer animate', 'saasmaxcore'),
                                        'type'    => 'css',
                                    ),*/
                                ),
                            ),
                            array(
                                'name'        => 'custom_class',
                                'label'       => esc_html__('Custom Class', 'saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
                            ),
                        ),
                        'Style' => array(
                            array(
                                'name'    => 'saasmaxcore_animate_layers_addon_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        "screens" => "any,1024,999,767,479",
                                        'Icon Layer'    => array(
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'display', 'label' => 'Display', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'width', 'label' => 'WIdth', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-animate-layer i'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-animate-layer i'),
                                        ),
                                        'Image Layer' => array(
                                            array('property' => 'display', 'label' => 'Display', 'selector' => '.single-animate-layer'),
                                            array('property' => 'width', 'label' => 'WIdth', 'selector' => '.single-animate-layer'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.single-animate-layer'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-animate-layer'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single-animate-layer'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-animate-layer'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-animate-layer'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-animate-layer'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-animate-layer'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.single-animate-layer'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.single-animate-layer'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.single-animate-layer'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.single-animate-layer'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.single-animate-layer'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.single-animate-layer'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single-animate-layer'),
                                        ),
                                        'Color Layer'    => array(
                                            array('property' => 'display', 'label' => 'Display', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'width', 'label' => 'WIdth', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-animate-layer .animate_color_layer'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single-animate-layer .animate_color_layer'),
                                        ),
                                        'Boxes' => array(
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'display', 'label' => 'Display'),
                                            array('property' => 'width', 'label' => 'Width'),
                                            array('property' => 'height', 'label' => 'Height'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'z-index', 'label' => 'Z-Index'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                            array('property' => 'position', 'Label' => 'Position'),
                                            array('property' => 'overflow', 'Label' => 'Overflow'),
                                        ),
                                        'Custom' => array(
                                            array('property' => 'custom', 'label' => 'Custom Css'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
            ));
        }
    }
}

if (!function_exists('saasmaxcore_animate_layers_content')) {
    function saasmaxcore_animate_layers_content($atts, $content = ''){

        extract($atts);
        $master_class = apply_filters('kc-el-class', $atts);
        
        $output = 
        '<div class="area_animate_layers ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">';

            foreach ($all_layers as $single ) {
                extract($single_layers = array(
                    'layer_opacity'   => $single->layer_opacity,
                    'border_radius'   => $single->border_radius,
                    'layer_postion'   => $single->layer_postion,
                    'position_left'   => $single->layer_left,
                    'position_right'  => $single->layer_right,
                    'position_top'    => $single->layer_top,
                    'position_bottom' => $single->layer_bottom,
                    'layer_type'      => $single->layer_type,
                    'icon_layer'      => $single->icon_layer,
                    'image_layer'     => $single->image_layer,
                    'color_layer'     => $single->color_layer,
                    'layer_rotate'    => $single->layer_rotate,
                    'layer_animate'   => $single->layer_animate,
                    /*'custom_css'      => $single->custom_css,*/
                ));
                $css_class = apply_filters('kc-el-class', $single_layers );
                $el_item_class = array('single-animate-layer');
                if (isset($layer_animate) && !empty($layer_animate)){
                    $ani = explode('|', $layer_animate);
                    if (isset($ani[0]) && !empty($ani[0]))
                        $el_item_class[] = 'kc-animated kc-animate-eff-'.esc_attr($ani[0]);  
                    if (isset($ani[1]) && !empty($ani[1]))
                        $el_item_class[] = 'kc-animate-delay-'.esc_attr($ani[1]);    
                    if (isset($ani[2]) && !empty($ani[2]))
                        $el_item_class[] = 'kc-animate-speed-'.esc_attr($ani[2]);
                }

                if ( 'from_left_top' == $layer_postion ) {
                	$layer_style = 'left:'.$position_left.';top:'.$position_top.';opacity:.'.$layer_opacity.';border-radius:'.$border_radius.';';
                }elseif ('from_left_bottom' == $layer_postion ) {
                	$layer_style = 'left:'.$position_left.';bottom:'.$position_bottom.';opacity:.'.$layer_opacity.';border-radius:'.$border_radius.';';
                }elseif ('from_right_top' == $layer_postion ) {
                	$layer_style = 'top:'.$position_top.';right:'.$position_right.';opacity:.'.$layer_opacity.';border-radius:'.$border_radius.';';
                }elseif ('from_right_bottom' == $layer_postion ) {
                	$layer_style = 'right:'.$position_right.';bottom:'.$position_bottom.';opacity:.'.$layer_opacity.';border-radius:'.$border_radius.';';
                }


                if ( $layer_type == 'image_icon' ) {
                    $layer = '<img src="'.wp_get_attachment_image_url($image_layer, 'full').'" alt="'.get_the_title( $image_layer ).'">';
                }elseif( $layer_type == 'font_icon' ){
                    $layer = '<i class="'.$icon_layer.'"></i>';
                }elseif( $layer_type == 'color' ){
                    $layer = '<div class="animate_color_layer" style="background:'.$color_layer.'"></div>';
                }

                $output.='
                <div class="'.esc_attr( implode(' ', $el_item_class) ).'" style="'.$layer_style.'">'.$layer.'</div>';
            }

        $output.= 
        '</div>';
        return $output;

    }
}
add_shortcode('saasmaxcore_animate_layers', 'saasmaxcore_animate_layers_content');
