<?php

add_action('init', 'saasmaxcore_image_gallery_addon', 99);
if (!function_exists('saasmaxcore_image_gallery_addon')) {
	function saasmaxcore_image_gallery_addon() {
		if (function_exists('kc_add_map')) {
		    kc_add_map(
		        array(	 
		            'saasmaxcore_image_gallery' => array(
		                'name'        => esc_html__('Images Gallery' , 'saasmaxcore'),
		                'description' => esc_html__('Use this addon for showing images gallery.' , 'saasmaxcore'),
		                'icon'        => 'et-pictures',
		                'category'    => 'THEME CORE',
		                'params'      => array(
		                	'Genaral' => array(
			                    array(
			                        'name'    => 'gallery_style',
			                        'label'   => esc_html__( 'Select Gallery Style', 'saasmaxcore' ),
			                        'type'    => 'select',
			                        'options' => array(
										'gallery_default'           => esc_html__('Gallery Default','saasmaxcore'),
										'gallery_default_filtering' => esc_html__('Gallery Default Filtering','saasmaxcore'),
										'gallery_masonry'           => esc_html__('Gallery Masonry','saasmaxcore'),
										'gallery_masonry_filtering' => esc_html__('Gallery Masonry Filtering','saasmaxcore'),
										'gallery_slider'            => esc_html__('Gallery Slider','saasmaxcore'),
									),
			                        'description' => esc_html__('Set the gallery style which you want to show.', 'saasmaxcore'),
			                        'value'       => 'gallery_default',
			                    ),
			                    array(
			                        'name'        => 'gallery_images',
			                        'label'       => esc_html__( 'Select Gallery Images', 'saasmaxcore' ),
			                        'description' => esc_html__('Select the gallery images multiple.', 'saasmaxcore'),
			                        'options'     => array('add_text' => esc_html__('Add new image', 'saasmaxcore')),
			                        'type'        => 'group',
			                        'params'      => array(
										array(
											'type'        => 'attach_image',
											'label'       => 'Gallery Image',
											'name'        => 'gallery_image',
											'description' => esc_html__('Select the image for show in galllery','saasmaxcore'),
										),
										array(
											'type'        => 'text',
											'label'       => 'Image Title',
											'name'        => 'image_title',
											'description' => esc_html__('Set the image caption title','saasmaxcore'),
										),
										array(
											'type'        => 'textarea',
											'label'       => 'Image Description',
											'name'        => 'image_description',
											'description' => esc_html__('Set the image caption description','saasmaxcore'),
										),
										array(
											'type'        => 'text',
											'label'       => 'Image Category',
											'name'        => 'image_category',
											'description' => esc_html__('Set the image category ( Please write a single string ).','saasmaxcore'),
										),
									),
			                    ),
			                    array(
			                        'name'    => 'autoplay',
			                        'label'   => esc_html__( 'Slider AutoPlay', 'saasmaxcore' ),
			                        'type'    => 'select',
			                        'options' => array(
										'true'  => 'Yes',
										'false' => 'No',
									),
			                        'description' => esc_html__('Set the gallery slider autoplay Yes Or No.', 'saasmaxcore'),
			                        'value'       => 'true',
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'show_when' => 'gallery_slider',
			                        ),
			                    ),
			                    array(
			                        'name'    => 'autoplay_timeout',
			                        'label'   => esc_html__( 'Slider AutoPlay Timeout', 'saasmaxcore' ),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 1000,
										'max'        => 5000,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the gallery slider autoplay timeout in milisecond.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'show_when' => 'gallery_slider',
			                        ),
			                        'value' => '1000',
			                    ),
			                    array(
			                        'name'    => 'margin',
			                        'label'   => esc_html__( 'Margin Between Slide', 'saasmaxcore' ),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 0,
										'max'        => 30,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the gallery slide margin between slide to slide.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'show_when' => 'gallery_slider',
			                        ),
			                        'value' => '10',
			                    ),
			                    array(
			                        'name'    => 'slider_loop',
			                        'label'   => esc_html__( 'Slider Loop', 'saasmaxcore' ),
			                        'type'    => 'select',
			                        'options' => array(
										'true'  => 'Yes',
										'false' => 'No',
									),
			                        'description' => esc_html__('Set the gallery slider Loop Yes Or No.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'show_when' => 'gallery_slider',
			                        ),
			                        'value' => 'true',
			                    ),
			                    array(
			                        'name'    => 'slider_navigation',
			                        'label'   => esc_html__( 'Slider Navigaion', 'saasmaxcore' ),
			                        'type'    => 'select',
			                        'options' => array(
										'true'  => 'Yes',
										'false' => 'No',
									),
			                        'description' => esc_html__('Set the gallery slider navigaion Yes Or No.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'show_when' => 'gallery_slider',
			                        ),
			                        'value' => 'true',
			                    ),
			                    array(
			                        'name'    => 'slide_on_tab',
			                        'label'   => esc_html__( 'Slide On Tab', 'saasmaxcore' ),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 1,
										'max'        => 4,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the gallery slide total item in tab device..', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'show_when' => 'gallery_slider',
			                        ),
			                        'value' => '2',
			                    ),
			                    array(
			                        'name'    => 'slide_on_desktop',
			                        'label'   => esc_html__( 'Slide On Medium Desktop', 'saasmaxcore' ),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 1,
										'max'        => 5,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the gallery slide total item in desktop device..', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'show_when' => 'gallery_slider',
			                        ),
			                        'value' => '3',
			                    ),
			                    array(
			                        'name'    => 'slide_on_desktop_large',
			                        'label'   => esc_html__( 'Slide On Large Desktop', 'saasmaxcore' ),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 1,
										'max'        => 6,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the gallery slide total item in desktop large device..', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'show_when' => 'gallery_slider',
			                        ),
			                        'value' => '4',
			                    ),
			                    array(
			                        'name'    => 'menu_position',
			                        'label'   => esc_html__( 'Filter Menu Position', 'saasmaxcore' ),
			                        'type'    => 'select',
			                        'options' => array(
										'menu_left'   => esc_html('Menu Left','saasmaxcore'),
										'menu_center' => esc_html('Menu Center','saasmaxcore'),
										'menu_right'  => esc_html('Menu Right','saasmaxcore'),
									),
			                        'description' => esc_html__('Set the gallery menu position.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'show_when' => array(
			                        		'gallery_default_filtering','gallery_masonry_filtering'
			                        	),
			                        ),
			                        'value' => 'menu_center',
			                    ),		                    
			                    array(
			                        'name'    => 'total_column',
			                        'label'   => esc_html('Gallery Cloumn','saasmaxcore'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 1,
										'max'        => 6,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the gallery item column max column 6.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'hide_when' => 'gallery_slider',
			                        ),
			                        'value' => '3',
			                    ),
			                    array(
			                        'name'    => 'column_gaps',
			                        'label'   => esc_html('Column Gaps','saasmaxcore'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 0,
										'max'        => 30,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the gallery item gaps between item to item.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'gallery_style',
			                        	'hide_when' => 'gallery_slider',
			                        ),
			                        'value' => '10',
			                    ),
			                    array(
			                        'name'    => 'image_on_click',
			                        'label'   => esc_html__( 'Image On Click', 'saasmaxcore' ),
			                        'type'    => 'select',
			                        'options' => array(
										'no_action'    => esc_html('No Action','saasmaxcore'),
										'popup_button' => esc_html('Open In Popup','saasmaxcore'),
									),
			                        'description' => esc_html__('Set the gallery image on click event.', 'saasmaxcore'),
			                        'value'       => 'popup_button',
			                    ),

			                    array(
			                        'name'        => 'show_overlay_button',
			                        'label'       => esc_html__( 'Overlay Button And Details', 'saasmaxcore' ),
			                        'type'        => 'toggle',
			                        'description' => esc_html__('Set the toggle yes for showing gallery item button.', 'saasmaxcore'),
			                        'value'       => 'no',
			                    ),
			                    array(
			                        'name'    => 'button_type',
			                        'label'   => esc_html__( 'Select Button Type', 'saasmaxcore' ),
			                        'type'    => 'select',
			                        'options' => array(
										'icon_button' => esc_html('Icon Button','saasmaxcore'),
										'text_button' => esc_html('Text Button','saasmaxcore'),
									),
			                        'description' => esc_html__('Set the gallery item button which you want to show. like ( text button, icon button )', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'show_overlay_button',
			                        	'show_when' => 'yes',
			                        ),
			                        'value' => 'icon_button',
			                    ),
			                    array(
			                        'name'    => 'button_icon_type',
			                        'label'   => esc_html__( 'Button Icon Type', 'saasmaxcore' ),
			                        'type'    => 'select',
			                        'options' => array(
										'font_icon'  => esc_html('Font Icon','saasmaxcore'),
										'image_icon' => esc_html('Image Icon','saasmaxcore'),
									),
			                        'description' => esc_html__('Set the gallery icon type ( image or font ).', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'button_type',
			                        	'show_when' => 'icon_button',
			                        ),
			                        'value' => 'font_icon',
			                    ),
			                    array(
			                        'name'        => 'button_font_icon',
			                        'label'       => esc_html__( 'Button Icon', 'saasmaxcore' ),
			                        'type'        => 'icon_picker',
			                        'description' => esc_html__('Set the gallery item button icon.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'button_icon_type',
			                        	'show_when' => 'font_icon',
			                        ),
			                        'value' => 'flaticon-add',
			                    ),
			                    array(
			                        'name'        => 'button_image_icon',
			                        'label'       => esc_html__( 'Upload Icon', 'saasmaxcore' ),
			                        'type'        => 'attach_image',
			                        'description' => esc_html__('Set the gallery item button icon.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'button_icon_type',
			                        	'show_when' => 'image_icon',
			                        ),
			                        'value' => '',
			                    ),
			                    array(
			                        'name'        => 'button_text',
			                        'label'       => esc_html__( 'Button Text', 'saasmaxcore' ),
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the gallery item button text.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'button_type',
			                        	'show_when' => 'text_button',
			                        ),
			                        'value' => 'View',
			                    ),
			                    array(
			                        'name'        => 'custom_class',
			                        'label'       => 'Custom Class',
			                        'type'        => 'text',
			                        'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
			                    ),
		                	),

		                	'Style'	=>	array(
								array(
			                		'name'    => 'saasmaxcore_image_gallery_addon_style',
			                		'type'    => 'css',
			                		'options' => array(
										array(
											'screens'    => "any,1024,999,767,479",
											'Typography' => array(
												array('property' => 'color', 'label' => 'Color'),
												array('property' => 'background'),
												array('property' => 'font-size', 'label' => 'Font Size'),
												array('property' => 'font-weight', 'label' => 'Font Weight'),
												array('property' => 'font-style', 'label' => 'Font Style'),
												array('property' => 'font-family', 'label' => 'Font Family'),
												array('property' => 'text-align', 'label' => 'Text Align'),
												array('property' => 'text-shadow', 'label' => 'Text Shadow'),
												array('property' => 'text-transform', 'label' => 'Text Transform'),
												array('property' => 'text-decoration', 'label' => 'Text Decoration'),
												array('property' => 'line-height', 'label' => 'Line Height'),
												array('property' => 'letter-spacing', 'label' => 'Letter Spacing'),
												array('property' => 'overflow', 'label' => 'Overflow'),
												array('property' => 'word-break', 'label' => 'Word Break'),					
											),
											'Details Box' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.gallery-details'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.gallery-details'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.gallery-details'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.gallery-details'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.gallery-details'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.gallery-details'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.gallery-details'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.gallery-details'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.gallery-details'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.gallery-details'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.gallery-details'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.gallery-details'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.gallery-details'),
											),
											'Title' => array(
	                                            array('property' => 'color', 'label' => 'Color','selector' => '.gallery-title'),
	                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.gallery-title'),
	                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.gallery-title'),
	                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.gallery-title'),
	                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.gallery-title'),
	                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.gallery-title'),
	                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.gallery-title'),
	                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.gallery-title'),
	                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.gallery-title'),
	                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.gallery-title'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.gallery-title'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.gallery-title'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.gallery-title'),
											),
											'Box' => array(
												array('property' => 'margin', 'label' => 'Margin'),
												array('property' => 'padding', 'label' => 'Padding'),
												array('property' => 'border', 'label' => 'Border'),
												array('property' => 'width', 'label' => 'Width'),
												array('property' => 'height', 'label' => 'Height'),
												array('property' => 'border-radius', 'label' => 'Border Radius'),
												array('property' => 'float', 'label' => 'Float'),
												array('property' => 'display', 'label' => 'Display'),
												array('property' => 'box-shadow', 'label' => 'Box Shadow'),
												array('property' => 'opacity', 'label' => 'Opacity'),
											),
										),
									),
								),
		                	),
		                ),
		            ),  // End of elemnt kc_icon 	 
		        )
		    ); // End add map

		}
	}
}

if (!function_exists('saasmaxcore_image_gallery_addon_content')) {
	function saasmaxcore_image_gallery_addon_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'gallery_images'         => '',
			'gallery_style'          => '',
			'menu_position'          => '',
			'total_column'           => 3,
			'column_gaps'            => 20,
			'autoplay'               => '',
			'autoplay_timeout'       => '',
			'margin'                 => '',
			'slider_loop'            => '',
			'slider_navigation'      => '',
			'slide_on_tab'           => '',
			'slide_on_desktop'       => '',
			'slide_on_desktop_large' => '',
			'image_on_click'         => '',
			'show_overlay_button'    => '',
			'button_type'            => '',
			'button_icon_type'       => '',
			'button_font_icon'       => '',
			'button_image_icon'      => '',
			'button_text'            => '',
			'custom_class'           => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		$r_id = rand(5655,5874);

		switch ($gallery_style) {
			
			case 'gallery_default': 
				 $gallery_style = 'gallery_default';
				break;
			
			case 'gallery_default_filtering': 
				 $gallery_style = 'gallery_default_filtering';
				break;
			
			case 'gallery_masonry': 
				 $gallery_style = 'gallery_masonry';
				break;
			
			case 'gallery_masonry_filtering': 
				 $gallery_style = 'gallery_masonry_filtering';
				break;

			case 'gallery_slider': 
				 $gallery_style = 'gallery_slider';
				break;
			
			default: 
				$gallery_style = 'gallery_default';
				break;
		}
		
		if ( !empty( $menu_position ) ) {
			$menu_position = $menu_position;
		}else{
			$menu_position = '';
		}

		if ( $image_on_click == 'popup_button' ) {
			$image_on_click = 'popup_button';
			wp_enqueue_script('prettyPhoto');
			wp_enqueue_style( 'prettyPhoto');
		}elseif($image_on_click == 'no_action' ){
			$image_on_click = 'no_action';
		}else{
			$image_on_click = '';
		}


		if ( !empty( $autoplay ) ) {
			$autoplay = $autoplay;
		}else{
			$autoplay = true;
		}
		if ( !empty( $autoplay_timeout ) ) {
			$autoplay_timeout = $autoplay_timeout;
		}else{
			$autoplay_timeout = '1000';
		}
		if ( !empty( $margin ) ) {
			$margin = $margin;
		}else{
			$margin = 10;
		}
		if ( !empty( $slider_loop ) ) {
			$slider_loop = $slider_loop;
		}else{
			$slider_loop = true;
		}
		if ( !empty( $slider_navigation ) ) {
			$slider_navigation = $slider_navigation;
		}else{
			$slider_navigation = true;
		}
		if ( !empty( $slide_on_tab ) ) {
			$slide_on_tab = $slide_on_tab;
		}else{
			$slide_on_tab = '2';
		}
		if ( !empty( $slide_on_desktop ) ) {
			$slide_on_desktop = $slide_on_desktop;
		}else{
			$slide_on_desktop = '3';
		}
		if ( !empty( $slide_on_desktop_large ) ) {
			$slide_on_desktop_large = $slide_on_desktop_large;
		}else{
			$slide_on_desktop_large = '4';
		}

		/**
		 * [$show_overlay_button popup button for gallery]
		 * @var [type] string
		 */
		if ( $show_overlay_button == 'yes' ) {

			if ( $button_type == 'icon_button' ) {

				if ( $button_icon_type == 'font_icon' ) {
					$gallery_button = '<i class="'.esc_attr( $button_font_icon ).'"></i>';
				}elseif( $button_icon_type == 'image_icon' ){
					$button_image = $button_image_icon;
					$gallery_button = '<img src="'.esc_url( wp_get_attachment_image_url( $button_image, 'thumbnail' ) ).'" alt="">';
				}

			}elseif( $button_type == 'text_button' ){
				$gallery_button = $button_text;
			}else{
				$gallery_button = '';
			}
		}

		/**
		 * [$image_category for image category menu filtering.]
		 * @var array
		 */
		$image_category = array();
		if ( !empty( $gallery_images ) ) {

			foreach ($gallery_images as $single_image_details) {
				$image_category[] .=$single_image_details->image_category;
			}

		}
		$all_category = array_unique($image_category);
		ob_start();

	?>
		
	<?php if( $gallery_style == 'gallery_default_filtering' || $gallery_style == 'gallery_masonry' || $gallery_style == 'gallery_masonry_filtering' || $gallery_style == 'gallery_slider'  ) : ?>
	<script>
		(function($){
		    $(document).on("ready",function(){

		        <?php if( $gallery_style == 'gallery_default_filtering' ) : ?>		        
		            /*----------------------------
		                GALLERY DEFAULT FILTER
		            -----------------------------*/
		            var $blogMasonry = $('#<?php echo esc_attr( $gallery_style ).esc_attr( $r_id ); ?>');
		            if (typeof imagesLoaded === 'function') {
		                imagesLoaded($blogMasonry, function () {
		                    setTimeout(function () {
		                        $blogMasonry.isotope({
		                            itemSelector    : '.single-gallery-item',
		                            resizesContainer: false,
		                            layoutMode      : 'fitRows',
		                            filter          : '*',
		                            /*horizontalOrder: true,*/
		                        });
		                    }, 500);
		                });
		            };
		        <?php elseif( $gallery_style == 'gallery_masonry' || $gallery_style == 'gallery_masonry_filtering' ) : ?>
		            /*-------------------------------------------
		                GALLERY MASONRY & MASONRY FILTER ACTIVE 
		            --------------------------------------------*/
		            var $blogMasonry = $('#<?php echo esc_attr( $gallery_style ).esc_attr( $r_id ); ?>');
		            if (typeof imagesLoaded === 'function') {
		                imagesLoaded($blogMasonry, function () {
		                    setTimeout(function () {
		                        $blogMasonry.isotope({
		                            itemSelector    : '.single-gallery-item',
		                            resizesContainer: false,
		                            layoutMode      : 'masonry',
		                            filter          : '*',
		                            /*horizontalOrder: true,*/
		                        });
		                    }, 500);
		                });
		            };
		        <?php endif; ?>

		        <?php if( $gallery_style == 'gallery_default_filtering' || $gallery_style == 'gallery_masonry_filtering' ) : ?>		        	
		            /* -------------------------------------------------------
		             FILTER SET ACTIVE CLASS FOR STYLE
		            ----------------------------------------------------------*/
		            $('#gallery-filer-menu-<?php echo esc_attr( $r_id ); ?> li').on('click', function (event) {
		                $(this).siblings('.active').removeClass('active');
		                $(this).addClass('active');
		                event.preventDefault();
		            });
		            
		            /* ------------------------------
		             FILTERING
		             -------------------------------- */
		            $('#gallery-filer-menu-<?php echo esc_attr( $r_id ); ?> li').on('click', function () {
		                //$(this).addClass('active');
		                var filterValue = $(this).attr('data-filter');

		                $("#<?php echo esc_attr( $gallery_style ).esc_attr( $r_id ); ?>").isotope({
		                    filter          : filterValue,
		                    animationOptions: {
		                        duration: 750,
		                        easing  : 'linear',
		                        queue   : false,
		                    }
		                });
		                return false;
		            });
		        <?php endif; ?>

			    <?php if( $gallery_style == 'gallery_slider' ) : ?>

				    /*---------------------------
					    GALLERY SLIDER
					-----------------------------*/
				    var homeSlider = $("#<?php echo esc_attr( $gallery_style ).esc_attr( $r_id ); ?>");
				    homeSlider.owlCarousel({
				        merge          : true,
				        smartSpeed     : 1000,
				        loop           : <?php echo $slider_loop; ?>,
				        nav            : <?php echo $slider_navigation; ?>,
				        navText        : ['<div class="gallery_prev"></div>', '<div class="gallery_next"></div>'],
				        autoplay       : <?php echo $autoplay; ?>,
				        autoplayTimeout: <?php echo $autoplay_timeout; ?>,
				        margin         : <?php echo $margin; ?>,
				        responsiveClass: true,
				        responsive     : {
				            0: {
				                items: 1
				            },
				            600: {
				                items: <?php echo $slide_on_tab; ?>
				            },
				            1000: {
				                items: <?php echo $slide_on_desktop; ?>
				            },
				            1200: {
				                items: <?php echo $slide_on_desktop; ?>
				            },
				            1920: {
				                items: <?php echo $slide_on_desktop_large; ?>
				            }
				        }
				    });
				<?php endif; ?>
		    });
			
		})(jQuery)
	</script>
	<?php endif; ?>

		<div class="image-gallery-one <?php echo esc_attr( implode(' ', $master_class) ).' '.(isset( $custom_class ) ? $custom_class : ''); ?>">

			<?php if( $gallery_style == 'gallery_default_filtering' || $gallery_style == 'gallery_masonry_filtering' ) : ?>	
			<div class="gallery-filer-menu  <?php echo esc_attr( $menu_position ); ?>" id="gallery-filer-menu-<?php echo esc_attr( $r_id ); ?>">
				<ul>
					<li class="filter active" data-filter="*">All</li>
					<?php foreach ($all_category as $single_cat ) : ?>
					<li class="filter" data-filter=".<?php echo esc_attr( $single_cat); ?>"><?php echo esc_html( $single_cat ) ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>

			<div class="image-gallery-addon <?php echo esc_attr( $gallery_style ); ?>" id="<?php echo esc_attr( $gallery_style ).esc_attr( $r_id ); ?>">

				<?php if ( !empty( $gallery_images ) )  : ?>

				<?php foreach ($gallery_images as $image) : ?>
					<?php
						extract(
							$image_array = array(
								'gallery_id'        => $image->gallery_image,
								'image_title'       => $image->image_title,
								'image_description' => $image->image_description,
								'image_category'    => $image->image_category,
							)
						);
					?>
					<div class="single-gallery-item <?php echo esc_attr( $image_category ); ?>">
						<div class="single-gallery-item-warp">
						<?php if( $image_on_click == 'popup_button' ) : ?>
							<?php if( !empty( $gallery_id ) ) : ?>
								<div class="gallery-image"><a class="kc-image-link kc-pretty-photo" data-lightbox="kc-lightbox"  href="<?php echo esc_url( wp_get_attachment_image_url( $gallery_id, 'full' ) ); ?>"><img src="<?php echo esc_url( wp_get_attachment_image_url( $gallery_id, 'full' ) ); ?>" alt="<?php echo esc_attr( $image_title ); ?>"></a></div>
							<?php endif; ?>
						<?php elseif( $image_on_click == 'no_action' ) : ?>
							<?php if( !empty( $gallery_id ) ) : ?>
								<div class="gallery-image"><img src="<?php echo esc_url( wp_get_attachment_image_url( $gallery_id, 'full' ) ); ?>" alt="<?php echo esc_attr( $image_title ); ?>"></div>
							<?php endif; ?>
						<?php endif; ?>
						
						<?php if( $show_overlay_button == 'yes' ) : ?>
						<div class="gallery-details">
							<?php if( $show_overlay_button == 'yes' && $image_on_click == 'popup_button' ) : ?>
							<div class="popup-button">
								<?php if( !empty( $gallery_id ) ) : ?>
									<a class="kc-image-link kc-pretty-photo" data-lightbox="kc-lightbox"  href="<?php echo esc_url( wp_get_attachment_image_url( $gallery_id, 'full' ) ); ?>"><?php echo $gallery_button; ?></a>
								<?php endif; ?>
							</div>
							<?php endif; ?>
							<?php if( !empty( $image_title ) ) : ?>
							<div class="gallery-title"><?php echo esc_html( $image_title ); ?></div>
							<?php endif; ?>
							<?php if( !empty( $image_description ) ) : ?>
							<div class="gallery-description"><?php echo wpautop( esc_html( $image_description ) ); ?></div>
							<?php endif; ?>
						</div>
						<?php endif; ?>
						</div>
					</div>

				<?php endforeach; ?>

				<?php endif; ?>

			</div>
		</div>

		<?php
		$data = ob_get_clean();
		return $data;
	}
}
add_shortcode('saasmaxcore_image_gallery', 'saasmaxcore_image_gallery_addon_content');
?>