<?php

add_action('init', 'saasmaxcore_price_addon', 99);
if (!function_exists('saasmaxcore_price_addon')) {
	function saasmaxcore_price_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_price' => array(
					'name'        => esc_html__('Price Table', 'saasmaxcore'),
					'icon'        => 'bi-clip-board',
					'description' => esc_html__('Use this addon for price table.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
                            array(
                                'name'        => 'price_title',
                                'label'       => esc_html__('Price Title', 'saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__( 'Set the price title.', 'saasmaxcore' ),
                                'value'       => 'Standard',
                            ),
                            array(
                                'name'        => 'price_subtitle',
                                'label'       => esc_html__('Price Subtitle', 'saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__( 'Set the price subtitle.', 'saasmaxcore' ),
                                'value'       => 'Best For Forever',
                            ),
                            array(
                                'name'        => 'sale_promo_title',
                                'label'       => esc_html__('Price Promo Title', 'saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__( 'Set the price title.', 'saasmaxcore' ),
                                'value'       => '50% OFF',
                            ),
                            array(
                                'name'        => 'price_rate',
                                'label'       => esc_html__('Price Rate', 'saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__( 'Set the price rate.', 'saasmaxcore' ),
                                'value'       => '49',
                            ),
                            array(
                                'name'        => 'currency',
                                'label'       => esc_html__('Currency', 'saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__( 'Set the price currency sign.', 'saasmaxcore' ),
                                'value'       => '$',
                            ),
                            array(
                                'name'        => 'price_format',
                                'label'       => esc_html__('Price Format', 'saasmaxcore'),
                                'type'        => 'toggle',
                                'description' => esc_html__( 'Price format default $99 When turn on price format 99$.', 'saasmaxcore' ),
                                'value'       => 'no',
                            ),
                            array(
                                'name'        => 'per',
                                'label'       => esc_html__('Price Format', 'saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__( 'Set the price per month or year', 'saasmaxcore' ),
                                'value'       => '/month',
                            ),
                            array(
                                'name'        => 'enable_icon',
                                'label'       => esc_html__('Show Price Icon ?', 'saasmaxcore'),
                                'type'        => 'toggle',
                                'description' => esc_html__( 'If you want to show price icon you can set yes by toggle.', 'saasmaxcore' ),
                                'value'       => 'no',
                            ),
                            array(
                                'name'        => 'price_icon_type',
                                'label'       => esc_html__('Price Icon Type', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__( 'Select the price icon type.', 'saasmaxcore' ),
                                'options'     => array(
                                    'font_icon' => 'Font Icon',
                                    'img_icon'  => 'Image Icon',
                                ),
                                'relation'    => array(
                                    'parent'    => 'enable_icon',
                                    'show_when' => 'yes',
                                ),
                                'value' => 'font_icon',
                            ),
                            array(
                                'name'        => 'price_icon',
                                'label'       => esc_html__('Price Icon', 'saasmaxcore'),
                                'type'        => 'icon_picker',
                                'description' => esc_html__( 'Pick the price icon which you want to show.', 'saasmaxcore' ),
                                'relation'    => array(
                                    'parent'    => 'price_icon_type',
                                    'show_when' => 'font_icon',
                                ),
                                'value' => 'sl sl-paper-plane',
                            ),
                            array(
                                'name'        => 'price_image_icon',
                                'label'       => esc_html__('Price Image Icon', 'saasmaxcore'),
                                'type'        => 'attach_image',
                                'description' => esc_html__( 'Pick the price image icon which you want to show.', 'saasmaxcore' ),
                                'relation'    => array(
                                    'parent'    => 'price_icon_type',
                                    'show_when' => 'img_icon',
                                ),
                                'value' => '',
                            ),
                            array(
                                'name'        => 'price_header_structure',
                                'label'       => esc_html__('Price Header Structure', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__( 'Select the price header structure and icon, title, subtitle position.', 'saasmaxcore' ),
                                'options'     => array(
                                    'Title_Subtitle_Icon_Price' => 'Title Subtitle Icon Price',
                                    'Title_Subtitle_Price_Icon'  => 'Title Subtitle Price Icon',
                                    'Icon_Title_Subtitle_Price'  => 'Icon Title Subtitle Price',
                                    'Icon_Price_Title_Subtitle'  => 'Icon Price Title Subtitle',
                                    'Subtitle_Icon_Title_Price'  => 'Subtitle Icon Title Price',
                                    'Title_Icon_Subtitle_Price'  => 'Title Icon Subtitle Price',
                                    'Title_Price_Icon_Subtitle'  => 'Title Price Icon Subtitle',
                                    'Icon_Title_Price_Subtitle'  => 'Icon Title Price Subtitle',
                                    'Title_Price_Subtitle_Icon'  => 'Title Price Subtitle Icon',
                                ),
                                'value' => 'Icon_Title_Price_Subtitle',
                            ),
                            array(
                                'name'        => 'features_type',
                                'label'       => esc_html__('Features Type', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__( 'Select the features type which you want to show.', 'saasmaxcore' ),
                                'options'     => array(
                                    'default' => 'Default Features',
                                    'custom'  => 'Custom Features',
                                ),
                                'value' => 'default',
                            ),
                            array(
                                'name'        => 'default_features',
                                'label'       => esc_html__('Fetures List', 'saasmaxcore'),
                                'type'        => 'textarea',
                                'description' => esc_html__( 'Enter the value every item will be separate with a line break.', 'saasmaxcore' ),
                                'relation'    => array(
                                    'parent'    => 'features_type',
                                    'show_when' => 'default',
                                ),
                                'value' => base64_encode("Unlimited Web Space \nFREE Site Building \nFREE Domain Registar \n24/7/365 Support \nFREE Marketing & SEO Tools \n99.9% Service Uptime \n30 Day Money Back Guarantee")
                            ),
                            array(
                                'name'        => 'show_features_icon',
                                'label'       => esc_html__('Show Icon Attribute ?', 'saasmaxcore'),
                                'type'        => 'toggle',
                                'description' => esc_html__( 'If you want to show icon in every features item you can on by toggle.', 'saasmaxcore' ),
                                'value'       => 'no',
                                'relation'    => array(
                                    'parent'    => 'features_type',
                                    'show_when' => 'default',
                                ),
                            ),
                            array(
                                'name'     => 'features_icon',
                                'label'    => esc_html__('Icon Attribute', 'saasmaxcore'),
                                'type'     => 'icon_picker',
                                'value'    => 'sl sl-paper-plane',
                                'relation' => array(
                                    'parent'    => 'show_features_icon',
                                    'show_when' => 'yes',
                                ),
                            ),
                            array(
                                'type'        => 'group',
                                'label'       => esc_html__('Features List', 'saasmaxcore'),
                                'name'        => 'custom_features',
                                'description' => esc_html__( 'Repeat this fields with each item created, Each item corresponding features element.', 'saasmaxcore' ),
                                'options'     => array('add_text' => esc_html__('Add new price features', 'saasmaxcore')),
                                'value'       => base64_encode( json_encode(array(
                                    "1" => array(
                                        "features_name" => "Domain Registar",
                                    ),
                                    "2" => array(
                                        "features_name" => "Unlimited Space",
                                    ),
                                    "3" => array(
                                        "features_name" => "24/7 Supports",
                                    ),
                                    "4" => array(
                                        "features_name" => "99.9% Service Uptime",
                                    ),
                                    "5" => array(
                                        "features_name" => "Money Back Guarantee",
                                    ),
                                ) ) ),
                                'params' => array(
                                    array(
                                        'type'        => 'text',
                                        'label'       => esc_html__( 'Features Name', 'saasmaxcore' ),
                                        'name'        => 'features_name',
                                        'description' => esc_html__( 'Enter your features name.', 'saasmaxcore' ),
                                        'admin_label' => true,
                                    ),
                                    array(
                                        'name'        => 'show_custom_features_icon',
                                        'label'       => esc_html__('Show Icon Attribute ?', 'saasmaxcore'),
                                        'type'        => 'toggle',
                                        'description' => esc_html__( 'If you want to show icon in every features item you can on by toggle.', 'saasmaxcore' ),
                                        'value'       => 'no',
                                        'relation'    => array(
                                            'parent'    => 'features_type',
                                            'show_when' => 'custom',
                                        ),
                                    ),
                                    array(
                                        'name'     => 'custom_icon',
                                        'label'    => esc_html__('Icon Attribute', 'saasmaxcore'),
                                        'type'     => 'icon_picker',
                                        'value'    => 'sl sl-check',
                                        'relation' => array(
                                            'parent'    => 'show_custom_item_icon',
                                            'show_when' => 'yes',
                                        ),
                                    ),
                                ),
                                'relation' => array(
                                    'parent'    => 'features_type',
                                    'show_when' => 'custom',
                                ),
                            ),
							array(
								'name'        => 'show_button',
								'label'       => esc_html__('Show Button ?', 'saasmaxcore'),
								'type'        => 'toggle',
								'description' => esc_html__( 'If you dont want to show you can off by toggle.', 'saasmaxcore' ),
								'value'       => 'yes',
							),
							array(
								'name'     => 'button',
								'label'    => esc_html__('Button Link', 'saasmaxcore'),
								'type'     => 'link',
								'value'    => '#|Purchase|_blank',
								'relation' => array(
                                    'parent'    => 'show_button',
                                    'show_when' => 'yes',
                                ),
							),
							array(
								'name'     => 'show_icon',
								'label'    => esc_html__('Show Button Icon ?', 'saasmaxcore'),
								'type'     => 'toggle',
								'value'    => 'no',
								'relation' => array(
                                    'parent'    => 'show_button',
                                    'show_when' => 'yes',
                                ),
							),
							array(
								'name'     => 'button_icon',
								'label'    => esc_html__('Button Icon', 'saasmaxcore'),
								'type'     => 'icon_picker',
								'value'    => 'fa-long-arrow-alt-right',
								'relation' => array(
							        'parent'    => 'show_icon',
							        'show_when' => 'yes',
							    ),
							),
							array(
								'name'    => 'icon_position',
								'label'   => esc_html__('Button Icon Positon', 'saasmaxcore'),
								'type'    => 'select',
								'options' => array(
									'left'  => 'Icon Left',
									'right' => 'Icon Right',
								),
								'value'    => 'right',
								'relation' => array(
							        'parent'    => 'show_icon',
							        'show_when' => 'yes',
							    ),
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Header Style' => array(
							array(
								'name'    => 'saasmaxcore_price_addon_header_style',
								'type'    => 'css',
								'options' => array(
									array(
										'screens' => "any,1024,999,767,479",
										'PROMO'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.sale_promo'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.sale_promo'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.sale_promo'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.sale_promo'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.sale_promo'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.sale_promo'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.sale_promo'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.sale_promo'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.sale_promo'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.sale_promo'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.sale_promo'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.sale_promo'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.sale_promo'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.sale_promo'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.sale_promo'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.sale_promo'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.sale_promo'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.sale_promo'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.sale_promo'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.sale_promo'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.sale_promo'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.sale_promo'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.sale_promo'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.sale_promo'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.sale_promo'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.sale_promo'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.sale_promo'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.sale_promo'),
										),
                                        'HEADER WARP'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_header'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_header'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_header'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_header'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_header'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_header'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_header'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_header'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_header'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_header'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_header'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_header'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_header'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_header'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_header'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_header'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_header'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_header'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_header'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_header'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_header'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_header'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_header'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_header'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_header'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_header'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_header'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_header'),
                                        ),
                                        'HEADER BEFORE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_header:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_header:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_header:before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_header:before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_header:before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_header:before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_header:before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_header:before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_header:before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_header:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_header:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_header:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_header:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_header:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_header:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_header:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_header:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_header:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_header:before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_header:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_header:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_header:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_header:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_header:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_header:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_header:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_header:before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_header:before'),
                                        ),
                                        'HEADER AFTER'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_header:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_header:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_header:after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_header:after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_header:after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_header:after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_header:after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_header:after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_header:after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_header:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_header:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_header:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_header:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_header:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_header:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_header:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_header:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_header:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_header:after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_header:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_header:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_header:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_header:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_header:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_header:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_header:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_header:after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_header:after'),
                                        ),
                                        'ICON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_icon'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_icon'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_icon'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_icon'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_icon'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_icon'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_icon'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_icon'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_icon'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_icon'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_icon'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_icon'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_icon'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_icon'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_icon'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_icon'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_icon'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_icon'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_icon'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_icon'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_icon'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_icon'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_icon'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_icon'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_icon'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_icon'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_icon'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_icon'),
                                        ),
                                        'FONT ICON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_icon i'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_icon i'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_icon i'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_icon i'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_icon i'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_icon i'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_icon i'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_icon i'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_icon i'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_icon i'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_icon i'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_icon i'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_icon i'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_icon i'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_icon i'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_icon i'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_icon i'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_icon i'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_icon i'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_icon i'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_icon i'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_icon i'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_icon i'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_icon i'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_icon i'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_icon i'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_icon i'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_icon i'),
                                        ),
                                        'IMAGE ICON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_icon img'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_icon img'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_icon img'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_icon img'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_icon img'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_icon img'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_icon img'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_icon img'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_icon img'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_icon img'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_icon img'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_icon img'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_icon img'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_icon img'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_icon img'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_icon img'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_icon img'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_icon img'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_icon img'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_icon img'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_icon img'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_icon img'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_icon img'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_icon img'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_icon img'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_icon img'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_icon img'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_icon img'),
                                        ),
                                        'TITLE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_title'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_title'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_title'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_title'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_title'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_title'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_title'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_title'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_title'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_title'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_title'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_title'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_title'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_title'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_title'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_title'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_title'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_title'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_title'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_title'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_title'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_title'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_title'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_title'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_title'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_title'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_title'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_title'),
                                        ),
                                        'SUBTITLE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_subtitle'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_subtitle'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_subtitle'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_subtitle'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_subtitle'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_subtitle'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_subtitle'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_subtitle'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_subtitle'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_subtitle'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_subtitle'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_subtitle'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_subtitle'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_subtitle'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_subtitle'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_subtitle'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_subtitle'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_subtitle'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_subtitle'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_subtitle'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_subtitle'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_subtitle'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_subtitle'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_subtitle'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_subtitle'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_subtitle'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_subtitle'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_subtitle'),
                                        ),
                                        'PRICE WARP'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_rate'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_rate'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_rate'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_rate'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_rate'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_rate'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_rate'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_rate'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_rate'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_rate'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_rate'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_rate'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_rate'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_rate'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_rate'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_rate'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_rate'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_rate'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_rate'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_rate'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_rate'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_rate'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_rate'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_rate'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_rate'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_rate'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_rate'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_rate'),
                                        ),
                                        'PRICE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_rate .price'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_rate .price'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_rate .price'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_rate .price'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_rate .price'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_rate .price'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_rate .price'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_rate .price'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_rate .price'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_rate .price'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_rate .price'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_rate .price'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_rate .price'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_rate .price'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_rate .price'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_rate .price'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_rate .price'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_rate .price'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_rate .price'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_rate .price'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_rate .price'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_rate .price'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_rate .price'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_rate .price'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_rate .price'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_rate .price'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_rate .price'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_rate .price'),
                                        ),
                                        'CURRENCY'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_rate .currency'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_rate .currency'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_rate .currency'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_rate .currency'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_rate .currency'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_rate .currency'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_rate .currency'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_rate .currency'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_rate .currency'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_rate .currency'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_rate .currency'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_rate .currency'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_rate .currency'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_rate .currency'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_rate .currency'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_rate .currency'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_rate .currency'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_rate .currency'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_rate .currency'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_rate .currency'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_rate .currency'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_rate .currency'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_rate .currency'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_rate .currency'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_rate .currency'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_rate .currency'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_rate .currency'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_rate .currency'),
                                        ),
                                        'PAR'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_rate .par'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_rate .par'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_rate .par'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_rate .par'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_rate .par'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_rate .par'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_rate .par'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_rate .par'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_rate .par'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_rate .par'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_rate .par'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_rate .par'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_rate .par'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_rate .par'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_rate .par'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_rate .par'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_rate .par'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_rate .par'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_rate .par'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_rate .par'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_rate .par'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_rate .par'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_rate .par'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_rate .par'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_rate .par'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_rate .par'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_rate .par'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_rate .par'),
                                        ),
									),
								),
							),
						),
                        'Details Style' => array(
                            array(
                                'name'    => 'saasmaxcore_price_addon_details_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        'screens' => "any,1024,999,767,479",
                                        'ITEMS WARP'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_details'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_details'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_details'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_details'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_details'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_details'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_details'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_details'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_details'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_details'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_details'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_details'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_details'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_details'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_details'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_details'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_details'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_details'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_details'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_details'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_details'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_details'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_details'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_details'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_details'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_details'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_details'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_details'),
                                        ),
                                        'ITEMS WARP BEFORE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_details:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_details:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_details:before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_details:before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_details:before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_details:before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_details:before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_details:before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_details:before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_details:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_details:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_details:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_details:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_details:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_details:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_details:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_details:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_details:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_details:before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_details:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_details:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_details:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_details:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_details:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_details:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_details:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_details:before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_details:before'),
                                        ),
                                        'ITEMS WARP AFTER'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_details:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_details:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_details:after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_details:after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_details:after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_details:after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_details:after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_details:after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_details:after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_details:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_details:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_details:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_details:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_details:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_details:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_details:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_details:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_details:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_details:after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_details:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_details:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_details:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_details:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_details:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_details:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_details:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_details:after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_details:after'),
                                        ),
                                        'ITEMS'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_details li'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_details li'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_details li'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_details li'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_details li'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_details li'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_details li'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_details li'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_details li'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_details li'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_details li'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_details li'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_details li'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_details li'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_details li'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_details li'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_details li'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_details li'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_details li'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_details li'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_details li'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_details li'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_details li'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_details li'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_details li'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_details li'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_details li'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_details li'),
                                        ),
                                        'ITEMS ICON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_details li i'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_details li i'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_details li i'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_details li i'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_details li i'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_details li i'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_details li i'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_details li i'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_details li i'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_details li i'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_details li i'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_details li i'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_details li i'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_details li i'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_details li i'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_details li i'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_details li i'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_details li i'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_details li i'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_details li i'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_details li i'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_details li i'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_details li i'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_details li i'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_details li i'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_details li i'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_details li i'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_details li i'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                        'Footer Style' => array(
                            array(
                                'name'    => 'saasmaxcore_price_addon_footer_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        'screens' => "any,1024,999,767,479",
                                        'PRICE FOOTER'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_footer'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_footer'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_footer'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_footer'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_footer'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_footer'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_footer'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_footer'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_footer'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_footer'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_footer'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_footer'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_footer'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_footer'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_footer'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_footer'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_footer'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_footer'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_footer'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_footer'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_footer'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_footer'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_footer'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_footer'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_footer'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_footer'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_footer'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_footer'),
                                        ),
                                        'FOOTER BEFORE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_footer:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_footer:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_footer:before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_footer:before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_footer:before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_footer:before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_footer:before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_footer:before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_footer:before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_footer:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_footer:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_footer:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_footer:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_footer:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_footer:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_footer:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_footer:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_footer:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_footer:before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_footer:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_footer:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_footer:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_footer:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_footer:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_footer:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_footer:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_footer:before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_footer:before'),
                                        ),
                                        'FOOTER AFTER'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.price_footer:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.price_footer:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.price_footer:after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.price_footer:after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.price_footer:after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.price_footer:after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.price_footer:after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.price_footer:after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.price_footer:after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.price_footer:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.price_footer:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.price_footer:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.price_footer:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.price_footer:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.price_footer:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.price_footer:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.price_footer:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.price_footer:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.price_footer:after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.price_footer:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.price_footer:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.price_footer:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.price_footer:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.price_footer:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.price_footer:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.price_footer:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.price_footer:after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.price_footer:after'),
                                        ),
                                        'BUTTON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.purchase_button'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.purchase_button'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.purchase_button'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.purchase_button'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.purchase_button'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.purchase_button'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.purchase_button'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.purchase_button'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.purchase_button'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.purchase_button'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.purchase_button'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.purchase_button'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.purchase_button'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.purchase_button'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.purchase_button'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.purchase_button'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.purchase_button'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.purchase_button'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.purchase_button'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.purchase_button'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.purchase_button'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.purchase_button'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.purchase_button'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.purchase_button'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.purchase_button'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.purchase_button'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.purchase_button'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.purchase_button'),
                                        ),
                                        'BUTTON ICON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.purchase_button i'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.purchase_button i'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.purchase_button i'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.purchase_button i'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.purchase_button i'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.purchase_button i'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.purchase_button i'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.purchase_button i'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.purchase_button i'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.purchase_button i'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.purchase_button i'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.purchase_button i'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.purchase_button i'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.purchase_button i'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.purchase_button i'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.purchase_button i'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.purchase_button i'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.purchase_button i'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.purchase_button i'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.purchase_button i'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.purchase_button i'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.purchase_button i'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.purchase_button i'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.purchase_button i'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.purchase_button i'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.purchase_button i'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.purchase_button i'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.purchase_button i'),
                                        ),
                                        'HOVER' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.purchase_button:hover'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.purchase_button:hover'),
                                            array('property' => 'opacity', 'label' => 'Before Opacity & Background', 'selector' => '.purchase_button:hover:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.purchase_button:hover:before'),
                                            array('property' => 'opacity', 'label' => 'After Opacity & Background', 'selector' => '.purchase_button:hover:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.purchase_button:hover:after'),
                                            array('property' => 'color', 'label' => 'Icon Color', 'selector' => '.purchase_button:hover i'),
                                            array('property' => 'background-color', 'label' => 'Icon Background', 'selector' => '.purchase_button:hover i'),
                                            array('property' => 'margin', 'label' => 'Icon Margin', 'selector' => '.purchase_button:hover i'),
                                            array('property' => 'width', 'label' => 'Icon Width', 'selector' => '.purchase_button:hover i'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.purchase_button:hover'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.purchase_button:hover'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.purchase_button:hover'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.purchase_button:hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.purchase_button:hover'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.purchase_button:hover'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.purchase_button:hover'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.purchase_button:hover'),
                                        ),
                                        'BOX' => array(
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'background', 'label' => 'Background'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                        ),
                                        'BOX HOVER' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':hover'),
                                            array('property' => 'color', 'label' => 'Color', 'selector' => ':hover'),
                                            array('property' => 'color', 'label' => 'Icon Color', 'selector' => ':hover .price_icon'),
                                            array('property' => 'background-color', 'label' => 'Icon Background', 'selector' => ':hover .price_icon'),
                                            array('property' => 'color', 'label' => 'Title Color', 'selector' => ':hover .price_title'),
                                            array('property' => 'color', 'label' => 'Subtitle Color', 'selector' => ':hover .price_subtitle'),
                                            array('property' => 'color', 'label' => 'Price Warp Color', 'selector' => ':hover .price_rate'),
                                            array('property' => 'color', 'label' => 'Price Color', 'selector' => ':hover .price_rate .price'),
                                            array('property' => 'color', 'label' => 'Currency Color', 'selector' => ':hover .price_rate .currency'),
                                            array('property' => 'color', 'label' => 'Par Color', 'selector' => ':hover .price_rate .par'),
                                            array('property' => 'color', 'label' => 'Button Color', 'selector' => ':hover .purchase_button'),
                                            array('property' => 'background-color', 'label' => 'Button Backgroun', 'selector' => ':hover .purchase_button'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':hover'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':hover'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':hover'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':hover'),
                                        ),
                                        'BOX BEFORE' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => ':before'),
                                            array('property' => 'color', 'label' => 'Color','selector' => ':before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => ':before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => ':before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => ':before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => ':before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => ':before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => ':before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => ':before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => ':before'),
                                        ),
                                        'BOX AFTER' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => ':after'),
                                            array('property' => 'color', 'label' => 'Color','selector' => ':after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => ':after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => ':after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => ':after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => ':after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => ':after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => ':after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => ':after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => ':after'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                        'Box Style' => array(
                            array(
                                'name'    => 'saasmaxcore_price_addon_box_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        'screens' => "any,1024,999,767,479",
                                        'BOX' => array(
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'background', 'label' => 'Background'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                        ),
                                        'BOX HOVER' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':hover'),
                                            array('property' => 'color', 'label' => 'Color', 'selector' => ':hover'),
                                            array('property' => 'color', 'label' => 'Icon Color', 'selector' => ':hover .price_icon'),
                                            array('property' => 'background-color', 'label' => 'Icon Background', 'selector' => ':hover .price_icon'),
                                            array('property' => 'color', 'label' => 'Title Color', 'selector' => ':hover .price_title'),
                                            array('property' => 'color', 'label' => 'Subtitle Color', 'selector' => ':hover .price_subtitle'),
                                            array('property' => 'color', 'label' => 'Price Warp Color', 'selector' => ':hover .price_rate'),
                                            array('property' => 'color', 'label' => 'Price Color', 'selector' => ':hover .price_rate .price'),
                                            array('property' => 'color', 'label' => 'Currency Color', 'selector' => ':hover .price_rate .currency'),
                                            array('property' => 'color', 'label' => 'Par Color', 'selector' => ':hover .price_rate .par'),
                                            array('property' => 'color', 'label' => 'Button Color', 'selector' => ':hover .purchase_button'),
                                            array('property' => 'background-color', 'label' => 'Button Backgroun', 'selector' => ':hover .purchase_button'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':hover'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':hover'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':hover'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':hover'),
                                        ),
                                        'BOX BEFORE' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => ':before'),
                                            array('property' => 'color', 'label' => 'Color','selector' => ':before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => ':before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => ':before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => ':before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => ':before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => ':before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => ':before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => ':before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => ':before'),
                                        ),
                                        'BOX AFTER' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => ':after'),
                                            array('property' => 'color', 'label' => 'Color','selector' => ':after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => ':after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => ':after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => ':after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => ':after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => ':after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => ':after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => ':after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => ':after'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                        'Animate' => array(
                            array(
                                'name'  => 'animate',
                                'label' => esc_html__('Animate','saasmaxcore'),
                                'type'  => 'animate',
                            ),
                        ),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_price_content')) {
	function saasmaxcore_price_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'price_title'               => '',
			'price_subtitle'            => '',
			'sale_promo_title'          => '',
			'price_rate'                => '',
			'currency'                  => '',
			'price_format'              => '',
			'per'                       => '',
			'enable_icon'               => '',
			'price_icon_type'           => '',
			'price_icon'                => '',
			'price_image_icon'          => '',
			'price_header_structure'       => '',
			'features_type'             => '',
			'default_features'          => '',
			'show_features_icon'        => '',
			'features_icon'             => '',
			'custom_features'           => '',
			'features_name'             => '',
			'show_custom_features_icon' => '',
			'custom_features_icon'      => '',
			'show_button'               => '',
			'button'                    => '',
			'show_icon'                 => '',
			'button_icon'               => '',
			'icon_position'             => '',
			'custom_class'              => '',
		), $atts));
		$master_class = apply_filters('kc-el-class', $atts);

        // Title
        if ( !empty( $price_title ) ) {
            $title = '<h3 class="price_title">'.esc_html( $price_title ).'</h3>';
        }else{
            $title = '';
        }
        
        // Subtitle
        if ( !empty( $price_subtitle ) ) {
            $subtitle = '<div class="price_subtitle">'.esc_html( $price_subtitle ).'</div>';
        }else{
            $subtitle = '';
        }

        // Promo Title
        if ( !empty( $sale_promo_title ) ) {
            $sale_promo = '<div class="sale_promo">'.esc_html( $sale_promo_title ).'</div>';
        }else{
            $sale_promo = '';
        }

        // Price Rate
        if ( !empty( $price_rate ) ) {
            $rate = '<span class="price">'.esc_html( $price_rate ).'</span>';
        }else{
            $rate = '';
        }

        // Currentcy
        if ( !empty( $currency ) ) {
            $currency = '<span class="currency">'.esc_html( $currency ).'</span>';
        }else{
            $currency = '';
        }

        // Per
        if ( !empty( $per ) ) {
            $per = '<span class="par">'.esc_html( $per ).'</span>';
        }else{
            $per = '';
        }

        if ( !empty( $price_rate ) || !empty( $currency ) || !empty( $per ) ) {
            if ( 'yes' == $price_format ) {
                $price_rate = '<div class="price_rate">'.$currency.$rate.$per.'</div>';
            }else{
                $price_rate = '<div class="price_rate">'.$rate.$currency.$per.'</div>';                
            }
        }

        if ( 'yes' == $enable_icon ) {
            if ( 'font_icon' == $price_icon_type ) {
                if ( !empty( $price_icon ) ) {
                    $price_icon = '<div class="price_icon"><i class="'.esc_attr( $price_icon ).'"></i></div>';
                }else{
                    $price_icon = '';
                }

            }elseif ( 'img_icon' == $price_icon_type ) {
                if ( !empty( $price_image_icon ) ) {
                    $price_icon_url = wp_get_attachment_image_url( $price_image_icon, $size = 'full' );
                    $price_icon = '<div class="price_icon"><img src="'.esc_url( $price_icon_url ).'" alt=""></div>';
                }else{
                    $price_icon = '';
                }
            }else{
                $price_icon = '';
            }
        }else{
            $price_icon = '';
        }

        // Header Position  
        // Title_Subtitle_Icon_Price
        // Title_Subtitle_Price_Icon
        // Icon_Title_Subtitle_Price
        // Icon_Price_Title_Subtitle
        // Subtitle_Icon_Title_Price
        // Title_Icon_Subtitle_Price
        // Title_Price_Icon_Subtitle
        // Icon_Title_Price_Subtitle
        // Title_Price_Subtitle_Icon
        
        if ( 'Title_Subtitle_Icon_Price' == $price_header_structure ) {

            $price_header_details = $title . $subtitle . $price_icon . $price_rate;

        }elseif ( 'Title_Subtitle_Price_Icon' == $price_header_structure ) {

            $price_header_details = $title . $subtitle . $price_rate . $price_icon;

        }elseif ( 'Icon_Title_Subtitle_Price' == $price_header_structure ) {

            $price_header_details = $price_icon . $title . $subtitle . $price_rate;

        }elseif ( 'Icon_Price_Title_Subtitle' == $price_header_structure ) {

            $price_header_details = $price_icon . $price_rate . $title . $subtitle;
            
        }elseif ( 'Subtitle_Icon_Title_Price' == $price_header_structure ) {

            $price_header_details = $subtitle . $price_icon . $title . $price_rate;
            
        }elseif ( 'Title_Icon_Subtitle_Price' == $price_header_structure ) {

            $price_header_details = $title . $price_icon . $subtitle . $price_rate;
            
        }elseif ( 'Title_Price_Icon_Subtitle' == $price_header_structure ) {

            $price_header_details = $title . $price_rate . $price_icon . $subtitle;
            
        }elseif ( 'Icon_Title_Price_Subtitle' == $price_header_structure ) {

            $price_header_details = $price_icon . $title . $price_rate . $subtitle;
            
        }elseif ( 'Title_Price_Subtitle_Icon' == $price_header_structure ) {

            $price_header_details = $title . $price_rate . $subtitle . $price_icon;
            
        }

        // Price Header
        if ( !empty( $price_title ) || !empty( $price_subtitle ) || !empty( $price_title ) || ( !empty( $price_rate ) || !empty( $currency ) || !empty( $per ) ) ) {
            $price_header = '<div class="price_header">
                <div class="price_thumb_hidding">
                    '.( isset($price_header_details) ? $price_header_details : '' ).'
                </div>
            </div>';
        }

        // Features Type
        if ( 'default' == $features_type ) {

            if ( !empty( $default_features ) ) {

                if ( !empty( $features_icon ) ) {
                    $icon = $features_icon;
                }else{
                    $icon = '';
                }
                $pros = explode( "\n", $default_features );

                if( count( $pros ) ) {

                    $features_list = '<div class="price_details"><ul>';

                    foreach( $pros as $pro ) {
                        if ( 'yes' == $show_features_icon ) {
                            $features_list .= '<li><i class="'. esc_attr( $icon ) .'"></i> '. esc_html( $pro ) .' </li>';
                        } else {
                            $features_list .= '<li>'. esc_html( $pro ) .' </li>';
                        }
                    }

                    $features_list .= '</ul></div>';
                }
            }

        }elseif ( 'custom' == $features_type ) {

            $custom_features = $custom_features;
            array_shift($custom_features);
            if( count( $custom_features ) ) {

                $features_list = '<div class="price_details"><ul>';

                foreach( $custom_features as $single_features ) {
                    $icon = $single_features->custom_icon;
                    if ( 'yes' == $single_features->show_custom_features_icon ) {
                        $features_list .= '<li><i class="'. esc_attr( $icon ) .'"></i> '. esc_html( $single_features->features_name ) .' </li>';
                    } else {
                        $features_list .= '<li>'. esc_html( $single_features->features_name ) .' </li>';
                    }
                }
                $features_list .= '</ul></div>';
            }
        }

        // Purchase Button
		if ( !empty( $button_icon ) ) {
			$button_icon = $button_icon;
		}else{
			$button_icon = 'ti-star';
		}

		if ( !empty( $button ) ) {
			$btn = explode('|', $button);

			if ( !empty($btn[1]) ) {
				$button_text = $btn[1];
			}else{
				$button_text = 'Purchase';
			}

			if ( !empty($btn[2] ) ) {
				$target = 'target="'.$btn[2].'"';
			}else{
				$target = '';
			}
		}

        // Button Properties.
        if ( 'yes' == $show_button ) {
            if ( 'yes' == $show_icon ) {
                if ( 'right' == $icon_position) {
                    $button = '<a class="purchase_button" href="'. esc_url( $btn[0] ).'" '.$target.'>'.esc_html( $button_text ).'<i class="'.esc_attr( $button_icon ).'"></i></a>';
                }elseif ( 'left'  == $icon_position ) {
                    $button = '<a class="purchase_button" href="'. esc_url( $btn[0] ).'" '.$target.'><i class="'.esc_attr( $button_icon ).'"></i>'.esc_html( $button_text ).'</a>';
                }
            }else{
                $button = '<a class="purchase_button" href="'. esc_url( $btn[0] ).'" '.$target.'>'.esc_html( $button_text ).'</a>';
            }
            $price_button = '<div class="price_footer">
                '.(isset( $button ) ? $button : '').'
            </div>';
        }else{
            $price_button = '';
        }

        // Button Shortcode Data.
		$data = '<div class="single_price ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
            '.(isset( $sale_promo ) ? $sale_promo : '').'
            '.(isset( $price_header ) ? $price_header : '').'
            '.(isset( $features_list ) ? $features_list : '').'
            '.(isset( $price_button ) ? $price_button : '').'
        </div>';
		return $data;
	}
}
add_shortcode('saasmaxcore_price', 'saasmaxcore_price_content');
?>