<?php

add_action('init', 'saasmaxcore_subscriber_addon', 99);
if (!function_exists('saasmaxcore_subscriber_addon')) {
	function saasmaxcore_subscriber_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_subscriber' => array(
					'name'        => esc_html__('Suscriber Form', 'saasmaxcore'),
					'icon'        => 'bi-envelop',
					'description' => esc_html__('Use this addon for Ssubscriber Form.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
							array(
								'name'        => 'mailchimp_post_url',
								'label'       => esc_html__('MailChimp Post Url', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Paste your malchimp post url for mail list.', 'saasmaxcore'),
								'value'       => 'http://intimissibd.us14.list-manage.com/subscribe/post?u=a77a312486b6e42518623c58a&amp;id=4af1f9af4c',
							),
							array(
								'name'        => 'submit_text',
								'label'       => esc_html__('Submit Button Text', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add suscribe submit button text.', 'saasmaxcore'),
								'value'       => 'Subscribe',
							),
							array(
								'name'        => 'placeholder_text',
								'label'       => esc_html__('Input Placeholder Text', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add input field placeholder text.', 'saasmaxcore'),
								'value'       => 'email@example.com',
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Style' => array(
							array(
								'name'    => 'saasmaxcore_subscriber_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										"screens" => "any,1024,999,767,479",
										'Input'   => array(
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.subscriber-email'),
											array('property' => 'color', 'label' => 'Color', 'selector' => '.subscriber-email'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.subscriber-email'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.subscriber-email'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.subscriber-email'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.subscriber-email'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.subscriber-email'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.subscriber-email'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.subscriber-email'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.subscriber-email'),
										),
										'Button' => array(
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.subscriber-btn'),
											array('property' => 'color', 'label' => 'Color', 'selector' => '.subscriber-btn'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.subscriber-btn'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.subscriber-btn'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.subscriber-btn'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.subscriber-btn'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.subscriber-btn'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.subscriber-btn'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.subscriber-btn'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.subscriber-btn'),
										),
										'Button Hover' => array(
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.subscriber-btn:hover'),
											array('property' => 'color', 'label' => 'Color', 'selector' => '.subscriber-btn:hover'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.subscriber-btn:hover'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.subscriber-btn:hover'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.subscriber-btn:hover'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.subscriber-btn:hover'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.subscriber-btn:hover'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.subscriber-btn:hover'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.subscriber-btn:hover'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.subscriber-btn:hover'),
										),
										'Boxes' => array(
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'background', 'label' => 'Background'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'margin', 'label' => 'Margin'),
										),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_subscriber_content')) {
	function saasmaxcore_subscriber_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'mailchimp_post_url' => '',
			'submit_text'        => '',
			'placeholder_text'   => '',
			'custom_class'       => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		$r_id = rand(5655,5874);

		if( !empty( $mailchimp_post_url ) ){
			$post_url = $mailchimp_post_url;
		}else{
			$post_url = 'http://intimissibd.us14.list-manage.com/subscribe/post?u=a77a312486b6e42518623c58a&amp;id=4af1f9af4c';
		}

		if ( !empty( $submit_text ) ) {
			$submit_text = $submit_text;
		}else{
			$submit_text = 'Subscribe';
		}

		if ( !empty( $placeholder_text ) ) {
			$placeholder_text = $placeholder_text;
		}else{
			$placeholder_text = 'email@example.com';
		}
		wp_enqueue_script( 'ajaxchimp' );
		$script = '
			(function($){
				$(function(){
				  $("#mc-form-'.$r_id.'").ajaxChimp({
				        url: "'.$post_url.'",
				        callback: function (resp) {
				            if (resp.result === "success") {
				                $("#mc-form-'.$r_id.' input, #mc-form-'.$r_id.' button").hide();
				            }
				        }
				    });
				});
			})(jQuery);
		';
		wp_add_inline_script( 'saasmaxcore', $script );

		$data = '
		<form id="mc-form-'.$r_id.'" class="subscriber-form ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
			<label class="mt10" for="mc-email-'.$r_id.'"></label>
	        <input class="subscriber-email" type="email" id="mc-email-'.$r_id.'" placeholder="'.esc_attr( $placeholder_text ).'">
	        <button type="submit" class="plus-btn subscriber-btn">'.esc_html( $submit_text ).'</button>
		</form>';
		return $data;
	}
}
add_shortcode('saasmaxcore_subscriber', 'saasmaxcore_subscriber_content');
?>