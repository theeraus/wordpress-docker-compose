<?php

add_action('init', 'saasmaxcore_dual_button_addon', 99);
if (!function_exists('saasmaxcore_dual_button_addon')) {
	function saasmaxcore_dual_button_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
			'saasmaxcore_dual_button' => array(
				'name'			=> esc_html__( 'Dual Button', 'saasmaxcore' ),
				'category'		=> 'THEME CORE',
				'icon'			=> 'fa-clone',
				'description'	=> esc_html__( 'The dual button side by side', 'saasmaxcore' ),
				'params' => array(
					'left' => array(
						array(
							'type'			=> 'text',
							'label'			=> esc_html__( 'Label Button Left', 'kingcomposer' ),
							'name'			=> 'button_one_text',
							'description'	=> esc_html__( 'Add the text that appears on the left button.', 'kingcomposer' ),
							'value' 		=> esc_html__( 'Left Button', 'kingcomposer' ),
						),
						array(
							'type'			=> 'link',
							'label'			=> esc_html__( 'Button Left', 'saasmaxcore' ),
							'name'			=> 'button_one_link',
							'description'	=> esc_html__( 'Add your relative URL. Each URL contains link, anchor text and target attributes.', 'saasmaxcore' ),
							'value' 		=> '#|Button Left|_self',
						),
						array(
							'type' 			=> 'toggle',
							'name' 			=> 'show_button_one_icon',
							'label' 		=> esc_html__( 'Show Icon Button Left?', 'saasmaxcore' ),
							'description'	=> esc_html__( 'Display icon button left.', 'saasmaxcore' ),
							'description' 	=> '',
						),
						array(
							'type' 			=> 'icon_picker',
							'name'		 	=> 'button_one_icon',
							'label' 		=> esc_html__( 'Icon Button Left', 'saasmaxcore' ),
							'value'         => 'fa-leaf',
							'description' 	=> esc_html__( 'Select icon for left button', 'saasmaxcore' ),
							'relation'		=> array(
								'parent'	=> 'show_button_one_icon',
								'show_when'	=> 'yes'
							)
						),
						array(
							'type'			=> 'dropdown',
							'name'			=> 'button_one_icon_position',
							'label'			=> esc_html__( 'Icon Position Button Left', 'saasmaxcore' ),
							'description'	=> esc_html__( '', 'saasmaxcore'),
							'value'     	=> 'left',
							'options'		=> array(
								'left'	=> esc_html__('Left', 'saasmaxcore'),
								'right'	=> esc_html__('Right', 'saasmaxcore'),
							),
							'relation'		=> array(
								'parent'	=> 'show_button_one_icon',
								'show_when'	=> 'yes'
							)
						),
						array(
							'type'			=> 'text',
							'label'			=> esc_html__( 'Extra Class', 'saasmaxcore' ),
							'name'			=> 'extra_class',
							'description'	=> esc_html__( '', 'saasmaxcore'),
							'value'			=> ''
						),
						array(
							'name' 		=> 'left_css',
							'label' 	=> esc_html__( 'Style Left Button', 'saasmaxcore' ),
							'type' 		=> 'css',
							'options' 	=> array(
								array(
									'screens' => "any,1024,999,767,479",
									'Button' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.dual-button-one a'),
										array('property' => 'background', 'label' => 'Background', 'selector' => '.dual-button-one a'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.dual-button-one a'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.dual-button-one a'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.dual-button-one a'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.dual-button-one a'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.dual-button-one a'),
										array('property' => 'border', 'label' => 'Border', 'selector' => '.dual-button-one a'),
										array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.dual-button-one a'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.dual-button-one a'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.dual-button-one a'),
										array('property' => 'margin', 'label' => 'Icon Spacing', 'selector' => '.dual-button-one a i')
									),
									'Button Hover' => array(
										array('property' => 'color', 'label' => 'Color Hover', 'selector' => '.dual-button-one a:hover'),
										array('property' => 'background', 'label' => 'BG Hover', 'selector' => '.dual-button-one a:hover'),
										array('property' => 'border-color', 'label' => 'Border Color Hover', 'selector' => '.dual-button-one a:hover'),
										array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.dual-button-one a:hover'),
										array('property' => 'margin', 'label' => 'Icon Spacing Hover', 'selector' => '.dual-button-one a:hover i')
									)
								)
							)
						)
					),
					'right' => array(
						array(
							'type'			=> 'text',
							'label'			=> esc_html__( 'Label Button Right', 'kingcomposer' ),
							'name'			=> 'button_two_text',
							'description'	=> esc_html__( 'Add the text that appears on the left button.', 'kingcomposer' ),
							'value' 		=> esc_html__( 'Right Button', 'kingcomposer' ),
						),
						array(
							'type'			=> 'link',
							'label'			=> esc_html__( 'Button Right', 'saasmaxcore' ),
							'name'			=> 'button_two_link',
							'description'	=> esc_html__( 'Add your relative URL. Each URL contains link, anchor text and target attributes.', 'saasmaxcore' ),
							'value' 		=> '#|Button Right|_self',
						),
						array(
							'type' 			=> 'toggle',
							'name' 			=> 'show_button_two_icon',
							'label' 		=> esc_html__( 'Show Icon Button Right?', 'saasmaxcore' ),
							'description'	=> esc_html__( 'Display icon right button.', 'saasmaxcore' ),
							'description' 	=> '',
						),
						array(
							'type' 			=> 'icon_picker',
							'name'		 	=> 'button_two_icon',
							'label' 		=> esc_html__( 'Icon Button Right', 'saasmaxcore' ),
							'value'         => 'fa-leaf',
							'description' 	=> esc_html__( 'Select icon for button right', 'saasmaxcore' ),
							'relation'		=> array(
								'parent'	=> 'show_button_two_icon',
								'show_when'	=> 'yes'
							)
						),
						array(
							'type'			=> 'dropdown',
							'name'			=> 'button_two_icon_position',
							'label'			=> esc_html__( 'Icon Position Button Right', 'saasmaxcore' ),
							'description'	=> esc_html__( '', 'saasmaxcore'),
							'value'     	=> 'left',
							'options'		=> array(
								'left'	=> esc_html__('Left', 'saasmaxcore'),
								'right'	=> esc_html__('Right', 'saasmaxcore'),
							),
							'relation'		=> array(
								'parent'	=> 'show_button_two_icon',
								'show_when'	=> 'yes'
							)
						),
						array(
							'name' => 'right_css',
							'label' => 'Style Right Button',
							'type' => 'css',
							'options' => array(
								array(
									'screens' => "any,1024,999,767,479",
									'Button' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.dual-button-two a'),
										array('property' => 'background', 'label' => 'Background', 'selector' => '.dual-button-two a'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.dual-button-two a'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.dual-button-two a'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.dual-button-two a'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.dual-button-two a'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.dual-button-two a'),
										array('property' => 'border', 'label' => 'Border', 'selector' => '.dual-button-two a'),
										array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.dual-button-two a'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.dual-button-two a'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.dual-button-two a'),
										array('property' => 'margin', 'label' => 'Icon Spacing', 'selector' => '.dual-button-two a i')
									),
									'Button Hover' => array(
										array('property' => 'color', 'label' => 'Color Hover', 'selector' => '.dual-button-two a:hover'),
										array('property' => 'background', 'label' => 'BG Hover', 'selector' => '.dual-button-two a:hover'),
										array('property' => 'border-color', 'label' => 'Border Color Hover', 'selector' => '.dual-button-two a:hover'),
										array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.dual-button-two a:hover'),
										array('property' => 'margin', 'label' => 'Icon Spacing Hover', 'selector' => '.dual-button-two a:hover i')
									)
								)
							)
						)
					),
					'separator' => array(
						array(
							'type'			=> 'dropdown',
							'name'			=> 'middle_text',
							'label'			=> esc_html__( 'Separator', 'saasmaxcore' ),
							'description'	=> esc_html__( '', 'saasmaxcore'),
							'value'     	=> 'icon',
							'options'		=> array(
								'none'	=> esc_html__('None', 'saasmaxcore'),
								'text'	=> esc_html__('Text', 'saasmaxcore'),
								'icon'	=> esc_html__('Icon', 'saasmaxcore')
							)
						),
						array(
							'type' 			=> 'icon_picker',
							'name'		 	=> 'separator_icon',
							'label' 		=> esc_html__( 'Icon', 'saasmaxcore' ),
							'value'         => 'fa-leaf',
							'description' 	=> esc_html__( 'Select icon for middle 2 button', 'saasmaxcore' ),
							'relation'		=> array(
								'parent'	=> 'middle_text',
								'show_when'	=> 'icon'
							)
						),
						array(
							'type'			=> 'text',
							'label'			=> esc_html__( 'Text', 'saasmaxcore' ),
							'name'			=> 'separator_text',
							'description' 	=> esc_html__( 'Insert text middle', 'saasmaxcore' ),
							'value'			=> esc_html__( 'OR', 'saasmaxcore' ),
							'relation'		=> array(
								'parent'	=> 'middle_text',
								'show_when'	=> 'text'
							)
						),
						array(
							'name' => 'separator_css',
							'label' => 'Style Separator',
							'type' => 'css',
							'options' => array(
								array(
									'screens' => "any,1024,999,767,479",
									'Style' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.dual-button-middle span, .dual-button-middle i'),
										array('property' => 'background', 'label' => 'Background', 'selector' => '.dual-button-middle'),
										array('property' => 'height', 'label' => 'Height', 'selector' => '.dual-button-middle'),
										array('property' => 'width', 'label' => 'Width', 'selector' => '.dual-button-middle'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.dual-button-middle span, .dual-button-middle i'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.dual-button-middle span, .dual-button-middle i'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.dual-button-middle span, .dual-button-middle i'),
										array('property' => 'border', 'label' => 'Border', 'selector' => '.dual-button-middle'),
										array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.dual-button-middle'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.dual-button-middle'),
										array('property' => 'color', 'label' => 'Icon Color', 'selector' => '.dual-button-middle span, .dual-button-middle i'),
										array('property' => 'background', 'label' => 'Icon Background', 'selector' => '.dual-button-middle span,.dual-button-middle i'),
										array('property' => 'height', 'label' => 'Icon Height', 'selector' => '.dual-button-middle span,.dual-button-middle i'),
										array('property' => 'width', 'label' => 'Icon Width', 'selector' => '.dual-button-middle span,.dual-button-middle i'),
										array('property' => 'font-size', 'label' => 'Icon Font Size', 'selector' => '.dual-button-middle span, .dual-button-middle i'),
										array('property' => 'border', 'label' => 'Icon Border', 'selector' => '.dual-button-middle span,.dual-button-middle i'),
										array('property' => 'border-radius', 'label' => 'Icon Border Radius', 'selector' => '.dual-button-middle span,.dual-button-middle i'),
										array('property' => 'margin', 'label' => 'Icon Margin', 'selector' => '.dual-button-middle span,.dual-button-middle i'),
									),
                                    'BEFORE' => array(
                                        array('property' => 'background', 'label' => 'Background', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'display', 'label' => 'Display','selector' => '.dual-button-middle:before'),
                                        array('property' => 'width', 'label' => 'WIdth','selector' => '.dual-button-middle:before'),
                                        array('property' => 'height', 'label' => 'Height','selector' => '.dual-button-middle:before'),
                                        array('property' => 'position', 'label' => 'Position', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'left', 'label' => 'Left', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'right', 'label' => 'Right', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'top', 'label' => 'Top', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'transform', 'label' => 'Transform', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'border', 'label' => 'Border', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'padding', 'label' => 'Padding', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'margin', 'label' => 'Margin', 'selector' => '.dual-button-middle:before'),
                                        array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.dual-button-middle:before'),
                                    ),
                                    'AFTER' => array(
                                        array('property' => 'background', 'label' => 'Background', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'display', 'label' => 'Display','selector' => '.dual-button-middle:after'),
                                        array('property' => 'width', 'label' => 'WIdth','selector' => '.dual-button-middle:after'),
                                        array('property' => 'height', 'label' => 'Height','selector' => '.dual-button-middle:after'),
                                        array('property' => 'position', 'label' => 'Position', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'left', 'label' => 'Left', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'right', 'label' => 'Right', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'top', 'label' => 'Top', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'transform', 'label' => 'Transform', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'border', 'label' => 'Border', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'padding', 'label' => 'Padding', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'margin', 'label' => 'Margin', 'selector' => '.dual-button-middle:after'),
                                        array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.dual-button-middle:after'),
                                    ),
								)
							)
						)
					),
					'animate' => array(
						array(
							'name'    => 'animate',
							'type'    => 'animate'
						)
					)
				)
			)

			));
		}
	}
}

if (!function_exists('saasmaxcore_dual_button_content')) {
	function saasmaxcore_dual_button_content($atts, $content = '') {
		extract($atts);

		$el_classes = apply_filters( 'kc-el-class', $atts );
		$el_classes[] = 'dual-button';
		if( !empty( $extra_class ) ){
			$el_classes[] = $extra_class;
		}

		// Separator
		if ( 'none' != $middle_text ) {
			if ( 'text' == $middle_text ) {
				$separator = '<div class="dual-button-middle"><span>'.esc_html( $separator_text ).'</span></div>';
			}elseif( 'icon' == $middle_text ){
				$separator = '<div class="dual-button-middle"><i class="'.esc_attr( $separator_icon ).'"></i></div>';
			}
		}else{
			$separator = '';
		}

		// Button 1

		if ( !empty( $button_one_icon ) ) {
			$button_one_icon = $button_one_icon;
		}else{
			$button_one_icon = 'ti-star';
		}

		if ( !empty( $button_one_text ) ) {
			$button_one_text = $button_one_text;
		}else{
			$button_one_text = 'Read More';
		}

		if ( !empty( $button_one_link ) ) {
			$button_one_link = explode('|', $button_one_link);

			if ( !empty($button_one_link[1]) ) {
				$button_one_text = $button_one_link[1];
			}else{
				$button_one_text = $button_one_text;
			}

			if ( !empty($button_one_link[2] ) ) {
				$button_one_target = 'target="'.$button_one_link[2].'"';
			}else{
				$button_one_target = '_self';
			}
		}

		if ( 'yes' == $show_button_one_icon ) {
			if ( 'right' == $button_one_icon_position) {
				$button_left = '<div class="dual-button-one"><a class="dual_button_link" href="'. esc_url( $button_one_link[0] ).'" '.$button_one_target.'>'.esc_html( $button_one_text ).'<i class="'.esc_attr( $button_one_icon ).'"></i></a></div>';
			}elseif ( 'left'  == $button_one_icon_position ) {
				$button_left = '<div class="dual-button-one"><a class="dual_button_link" href="'. esc_url( $button_one_link[0] ).'" '.$button_one_target.'><i class="'.esc_attr( $button_one_icon ).'"></i>'.esc_html( $button_one_text ).'</a></div>';
			}
		}else{
			$button_left = '<div class="dual-button-one"><a class="dual_button_link" href="'. esc_url( $button_one_link[0] ).'" '.$button_one_target.'>'.esc_html( $button_one_text ).'</a>'. $separator .'</div>';
		}

		// Button 2
		if ( !empty( $button_two_icon ) ) {
			$button_two_icon = $button_two_icon;
		}else{
			$button_two_icon = 'ti-star';
		}

		if ( !empty( $button_two_text ) ) {
			$button_two_text = $button_two_text;
		}else{
			$button_two_text = 'Read More';
		}

		if ( !empty( $button_two_link ) ) {
			$button_two_link = explode('|', $button_two_link);

			if ( !empty($button_two_link[1]) ) {
				$button_two_text = $button_two_link[1];
			}else{
				$button_two_text = $button_two_text;
			}

			if ( !empty($button_two_link[2] ) ) {
				$button_two_target = 'target="'.$button_two_link[2].'"';
			}else{
				$button_two_target = '_self';
			}
		}


		if ( 'yes' == $show_button_two_icon ) {
			if ( 'right' == $button_two_icon_position) {
				$button_right = '<div class="dual-button-two"><a class="dual_button_link" href="'. esc_url( $button_two_link[0] ).'" '.$button_two_target.'>'.esc_html( $button_two_text ).'<i class="'.esc_attr( $button_two_icon ).'"></i></a></div>';
			}elseif ( 'left'  == $button_two_icon_position ) {
				$button_right = '<div class="dual-button-two"><a class="dual_button_link" href="'. esc_url( $button_two_link[0] ).'" '.$button_two_target.'><i class="'.esc_attr( $button_two_icon ).'"></i>'.esc_html( $button_two_text ).'</a></div>';
			}
		}else{
			$button_right = '<div class="dual-button-two"><a class="dual_button_link" href="'. esc_url( $button_two_link[0] ).'" '.$button_two_target.'>'.esc_html( $button_two_text ).'</a></div>';
		}

		$output = '
		<div class="' . esc_attr(implode(' ', $el_classes )) . '">
			<div class="dual-button-wrap">
				'.(isset( $button_left ) ? $button_left : '').'
				'.(isset( $button_right ) ? $button_right : '').'
			</div>
		</div>';
		return $output;

	}
}
add_shortcode('saasmaxcore_dual_button', 'saasmaxcore_dual_button_content');
?>