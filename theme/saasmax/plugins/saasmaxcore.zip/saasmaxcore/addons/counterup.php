<?php

add_action('init', 'saasmaxcore_counter_addon', 99);
if (!function_exists('saasmaxcore_counter_addon')) {
	function saasmaxcore_counter_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_counter' => array(
					'name'        => esc_html__('Counter Up', 'saasmaxcore'),
					'icon'        => 'fa-sort-numeric-up',
					'description' => esc_html__('Use this addon for counter up.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
                            array(
                                'name'        => 'counter_structure',
                                'label'       => esc_html__('Counter Structure', 'saasmaxcore'),
                                'type'        => 'select',
                                'description' => esc_html__( 'Select the structure and icon, title, subtitle position.', 'saasmaxcore' ),
                                'options'     => array(
                                    'Counter_Subtitle_Icon'          => 'Counter Subtitle Icon',
                                    'Icon_Counter_Subtitle'          => 'Icon Counter Subtitle',
                                    'Counter_Title_Icon'          => 'Counter Title Icon',
                                    'Counter_Icon_Title'          => 'Counter Icon Title',
                                    'Icon_Counter_Title'          => 'Icon Counter Title',
                                    'Title_Counter_Icon'          => 'Title Counter Icon',
                                    'Icon_Counter_Title_Subtitle' => 'Icon Counter Title Subtitle',
                                    'Icon_Title_Counter_Subtitle' => 'Icon Title Counter Subtitle',
                                    'Title_Subtitle_Icon_Counter' => 'Title Subtitle Icon Counter',
                                    'Title_Subtitle_Counter_Icon' => 'Title Subtitle Counter Icon',
                                    'Icon_Title_Subtitle_Counter' => 'Icon Title Subtitle Counter',
                                    'Subtitle_Icon_Title_Counter' => 'Subtitle Icon Title Counter',
                                    'Title_Icon_Subtitle_Counter' => 'Title Icon Subtitle Counter',
                                    'Title_Counter_Icon_Subtitle' => 'Title Counter Icon Subtitle',
                                    'Title_Counter_Subtitle_Icon' => 'Title Counter Subtitle Icon',
                                ),
                                'value' => 'Counter_Subtitle_Icon',
                            ),
							array(
								'name'  => 'show_icon',
								'label' => esc_html__('Show Icon ?', 'saasmaxcore'),
								'type'  => 'toggle',
								'value' => 'no',
							),
                            array(
                                'name'        => 'icon_type',
                                'label'       => esc_html__('Icon Type', 'saasmaxcore'),
                                'description' => esc_html__('Select the icon type which you want to show.', 'saasmaxcore'),
                                'type'        => 'select',
                                'options'     => array(
                                    'font_icon'  => 'Font Icon',
                                    'image_icon' => 'Image Icon',
                                ),
                                'relation'    => array(
                                    'parent'    => 'show_icon',
                                    'show_when' => 'yes',
                                ),
                                'value' => 'font_icon',
                            ),
							array(
                                'name'        => 'font_icon',
                                'label'       => esc_html__('Font Icon', 'saasmaxcore'),
                                'description' => esc_html__('Select the icon type which you want to show.', 'saasmaxcore'),
                                'type'        => 'icon_picker',
                                'relation'    => array(
                                    'parent'    => 'icon_type',
                                    'show_when' => 'font_icon',
                                ),
                                'value' => 'sl sl-paper-plane',
							),
                            array(
                                'name'        => 'image_icon',
                                'label'       => esc_html__('Font Icon', 'saasmaxcore'),
                                'description' => esc_html__('Select the icon type which you want to show.', 'saasmaxcore'),
                                'type'        => 'attach_image',
                                'relation'    => array(
                                    'parent'    => 'icon_type',
                                    'show_when' => 'image_icon',
                                ),
                                'value' => '',
                            ),
                            array(
                                'name'        => 'count_text',
                                'label'       => esc_html__('Count Text', 'saasmaxcore'),
                                'description' => esc_html__('Set the count text for fun fact', 'saasmaxcore'),
                                'type'        => 'text',
                                'value'       => '320',
                            ),
                            array(
                                'name'  => 'show_sign',
                                'label' => esc_html__('Show Counter Bedge ?', 'saasmaxcore'),
                                'type'  => 'toggle',
                                'value' => 'no',
                            ),
                            array(
                                'name'        => 'counter_sign',
                                'label'       => esc_html__('Counter Bedge Icon', 'saasmaxcore'),
                                'description' => esc_html__('Select the icon type which you want to show.', 'saasmaxcore'),
                                'type'        => 'icon_picker',
                                'relation'    => array(
                                    'parent'    => 'show_sign',
                                    'show_when' => 'yes',
                                ),
                                'value' => 'flaticon-add',
                            ),
                            array(
                                'name'        => 'title',
                                'label'       => esc_html__('Title', 'saasmaxcore'),
                                'description' => esc_html__('Set the title type which you want to show.', 'saasmaxcore'),
                                'type'        => 'text',
                                'value'       => 'Award Win',
                            ),
                            array(
                                'name'        => 'subtitle',
                                'label'       => esc_html__('Subtitle', 'saasmaxcore'),
                                'description' => esc_html__('Set the subtitle for fun fact', 'saasmaxcore'),
                                'type'        => 'text',
                                'value'       => 'This is subtitle',
                            ),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Style' => array(
							array(
								'name'    => 'saasmaxcore_counter_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										'screens' => "any,1024,999,767,479",
										'ICON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.fact_icon'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.fact_icon'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.fact_icon'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.fact_icon'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.fact_icon'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.fact_icon'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.fact_icon'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.fact_icon'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.fact_icon'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.fact_icon'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.fact_icon'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.fact_icon'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.fact_icon'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.fact_icon'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.fact_icon'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.fact_icon'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.fact_icon'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.fact_icon'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.fact_icon'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.fact_icon'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.fact_icon'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.fact_icon'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.fact_icon'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.fact_icon'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.fact_icon'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.fact_icon'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.fact_icon'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.fact_icon'),
										),
										'IMAGE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.fact_icon img'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.fact_icon img'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.fact_icon img'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.fact_icon img'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.fact_icon img'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.fact_icon img'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.fact_icon img'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.fact_icon img'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.fact_icon img'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.fact_icon img'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.fact_icon img'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.fact_icon img'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.fact_icon img'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.fact_icon img'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.fact_icon img'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.fact_icon img'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.fact_icon img'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.fact_icon img'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.fact_icon img'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.fact_icon img'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.fact_icon img'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.fact_icon img'),
										),
                                        'COUNTER'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.fact_count_text'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.fact_count_text'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.fact_count_text'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.fact_count_text'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.fact_count_text'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.fact_count_text'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.fact_count_text'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.fact_count_text'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.fact_count_text'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.fact_count_text'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.fact_count_text'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.fact_count_text'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.fact_count_text'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.fact_count_text'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.fact_count_text'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.fact_count_text'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.fact_count_text'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.fact_count_text'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.fact_count_text'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.fact_count_text'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.fact_count_text'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.fact_count_text'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.fact_count_text'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.fact_count_text'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.fact_count_text'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.fact_count_text'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.fact_count_text'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.fact_count_text'),
                                        ),
                                        'BEDGE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.counter_bedge'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.counter_bedge'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.counter_bedge'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.counter_bedge'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.counter_bedge'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.counter_bedge'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.counter_bedge'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.counter_bedge'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.counter_bedge'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.counter_bedge'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.counter_bedge'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.counter_bedge'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.counter_bedge'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.counter_bedge'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.counter_bedge'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.counter_bedge'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.counter_bedge'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.counter_bedge'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.counter_bedge'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.counter_bedge'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.counter_bedge'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.counter_bedge'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.counter_bedge'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.counter_bedge'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.counter_bedge'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.counter_bedge'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.counter_bedge'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.counter_bedge'),
                                        ),
                                        'COUNTER AFTER' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => '.fact_count_text:after'),
                                            array('property' => 'color', 'label' => 'Color','selector' => '.fact_count_text:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.fact_count_text:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.fact_count_text:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.fact_count_text:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.fact_count_text:after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.fact_count_text:after'),
                                        ),
                                        'TITLE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.fact_title'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.fact_title'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.fact_title'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.fact_title'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.fact_title'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.fact_title'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.fact_title'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.fact_title'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.fact_title'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.fact_title'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.fact_title'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.fact_title'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.fact_title'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.fact_title'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.fact_title'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.fact_title'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.fact_title'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.fact_title'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.fact_title'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.fact_title'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.fact_title'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.fact_title'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.fact_title'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.fact_title'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.fact_title'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.fact_title'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.fact_title'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.fact_title'),
                                        ),
                                        'SUBTITLE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.fact_subtitle'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.fact_subtitle'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.fact_subtitle'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.fact_subtitle'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.fact_subtitle'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.fact_subtitle'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.fact_subtitle'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.fact_subtitle'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.fact_subtitle'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.fact_subtitle'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.fact_subtitle'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.fact_subtitle'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.fact_subtitle'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.fact_subtitle'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.fact_subtitle'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.fact_subtitle'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.fact_subtitle'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.fact_subtitle'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.fact_subtitle'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.fact_subtitle'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.fact_subtitle'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.fact_subtitle'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.fact_subtitle'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.fact_subtitle'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.fact_subtitle'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.fact_subtitle'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.fact_subtitle'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.fact_subtitle'),
                                        ),
										'BOXES' => array(
                                            array('property' => 'color', 'label' => 'Color'),
											array('property' => 'background', 'label' => 'Background'),
                                            array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                            array('property' => 'transform', 'label' => 'Transform'),
											array('property' => 'overflow', 'label' => 'Overflow'),
										),
                                        'BOX BEFORE' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => ':before'),
                                            array('property' => 'color', 'label' => 'Color','selector' => ':before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => ':before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => ':before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => ':before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => ':before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => ':before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => ':before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => ':before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => ':before'),
                                        ),
                                        'BOX AFTER' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => ':after'),
                                            array('property' => 'color', 'label' => 'Color','selector' => ':after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => ':after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => ':after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => ':after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => ':after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => ':after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => ':after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => ':after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => ':after'),
                                        ),
                                        'BOX HOVER' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => ':hover'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':hover'),
                                            array('property' => 'opacity', 'label' => 'Before Opacity & Background', 'selector' => ':hover:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':hover:before'),
                                            array('property' => 'opacity', 'label' => 'After Opacity & Background', 'selector' => ':hover:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':hover:after'),
                                            array('property' => 'color', 'label' => 'Icon Color', 'selector' => ':hover .fact_icon'),
                                            array('property' => 'background-color', 'label' => 'Icon Background', 'selector' => ':hover .fact_icon'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':hover'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':hover'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':hover'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':hover'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':hover'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':hover'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => ':hover'),
                                        ),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_counter_content')) {
	function saasmaxcore_counter_content($atts, $content = '') {
		extract(shortcode_atts(array(
            'counter_structure' => '',
            'show_icon'         => '',
            'icon_type'         => '',
            'font_icon'         => '',
            'image_icon'        => '',
            'count_text'        => '',
            'show_sign'        => '',
            'counter_sign'        => '',
            'title'             => '',
            'subtitle'          => '',
            'background_icon'   => '',
            'icon_position'     => '',
            'custom_class'      => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);
        wp_enqueue_style( 'odometer' );
        wp_enqueue_script( 'odometer' );

        if ( 'yes' == $show_icon ) {
            if ( 'font_icon' == $icon_type ) {
                if ( !empty( $font_icon ) ) {
                    $icon = '<div class="fact_icon"><i class="'.esc_attr( $font_icon ).'"></i></div>';
                }else{
                    $icon = '';
                }
            }elseif ( 'image_icon' == $icon_type ) {
                if ( !empty( $image_icon ) ) {
                    $icon_url = wp_get_attachment_image_url( $image_icon, $size = 'full' );
                    $icon = '<div class="fact_icon"><img src="'.esc_url( $icon_url ).'" alt=""></div>';
                }else{
                    $icon = '';
                }
            }
        }else{
            $icon = '';
        }

        if ( 'yes' == $show_sign ) {
            if ( !empty( $counter_sign ) ) {
                $sign_bedge = '<span class="counter_bedge"><i class="'.esc_attr( $counter_sign ).'"></i></span>';
            }else{
                $sign_bedge = '';
            }
        }else{
            $sign_bedge = '';
        }

        // Fact Count
        if ( !empty( $count_text ) ) {
            if ( 'yes' == $show_sign ) {
                $counter = '<div class="bedge_counter"><h3 class="odometer fact_count_text" data-fact-count="'.esc_attr( $count_text ).'">00</h3>'. $sign_bedge .'</div>';
            }else{
                $counter = '<h3 class="odometer fact_count_text" data-fact-count="'.esc_attr( $count_text ).'">00</h3>';
            }
        }else{
            $counter = '';
        }

        // Title
        if ( !empty( $title ) ) {
            $title = '<h3 class="fact_title">'.esc_html( $title ).'</h3>';
        }else{
            $title = '';
        }
        
        // Subtitle
        if ( !empty( $subtitle ) ) {
            $subtitle = '<div class="fact_subtitle">'.esc_html( $subtitle ).'</div>';
        }else{
            $subtitle = '';
        }

        // Counter Data Structure
        // Icon_Counter_Title_Subtitle
        // Icon_Title_Counter_Subtitle
        // Title_Subtitle_Icon_Counter
        // Title_Subtitle_Counter_Icon
        // Icon_Title_Subtitle_Counter
        // Subtitle_Icon_Title_Counter
        // Title_Icon_Subtitle_Counter
        // Title_Counter_Icon_Subtitle
        // Title_Counter_Subtitle_Icon
        // Icon_Counter_Title
        
        if ( 'Icon_Counter_Title_Subtitle' == $counter_structure ) {
            $counter_data = $icon . $counter . $title . $subtitle;
        }elseif ( 'Icon_Title_Counter_Subtitle' == $counter_structure ) {
            $counter_data = $icon . $title  . $counter . $subtitle;
        }elseif ( 'Title_Subtitle_Icon_Counter' == $counter_structure ) {
            $counter_data = $title . $subtitle . $icon . $counter;
        }elseif ( 'Title_Subtitle_Counter_Icon' == $counter_structure ) {
            $counter_data = $title . $subtitle . $counter . $icon;
        }elseif ( 'Icon_Title_Subtitle_Counter' == $counter_structure ) {
            $counter_data = $icon . $title . $subtitle . $counter;
        }elseif ( 'Subtitle_Icon_Title_Counter' == $counter_structure ) {
            $counter_data = $subtitle . $icon . $title . $counter;
        }elseif ( 'Title_Icon_Subtitle_Counter' == $counter_structure ) {
            $counter_data = $title . $icon . $subtitle . $counter;
        }elseif ( 'Title_Counter_Icon_Subtitle' == $counter_structure ) {
            $counter_data = $title . $counter . $icon . $subtitle;
        }elseif ( 'Title_Counter_Subtitle_Icon' == $counter_structure ) {
            $counter_data = $title . $counter . $subtitle . $icon;
        }elseif ( 'Icon_Counter_Title' == $counter_structure ) {
            $counter_data = $icon . $counter . $title;
        }elseif ( 'Title_Counter_Icon' == $counter_structure ) {
            $counter_data = $title . $counter . $icon;
        }elseif ( 'Counter_Title_Icon' == $counter_structure ) {
            $counter_data = $counter . $title . $icon;
        }elseif ( 'Counter_Icon_Title' == $counter_structure ) {
            $counter_data = $counter . $icon . $title;
        }elseif ( 'Counter_Subtitle_Icon' == $counter_structure ) {
            $counter_data = $counter . $subtitle . $icon;
        }elseif ( 'Icon_Counter_Subtitle' == $counter_structure ) {
            $counter_data = $icon . $counter . $subtitle;
        }else{
            $counter_data = '';
        }


		$data = '
		<div class="single-counter-fact ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
			'.( isset( $counter_data ) ? $counter_data : '' ).'
		</div>';
		return $data;
	}
}
add_shortcode('saasmaxcore_counter', 'saasmaxcore_counter_content');
?>