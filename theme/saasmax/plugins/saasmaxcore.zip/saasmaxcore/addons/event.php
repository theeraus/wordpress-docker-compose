<?php

add_action('init', 'saasmaxcore_event_addon', 99);
if (!function_exists('saasmaxcore_event_addon')) {
	function saasmaxcore_event_addon() {
		if (function_exists('kc_add_map')) {
		    kc_add_map(
		        array(	 
		            'saasmaxcore_event' => array(
		                'name'        => esc_html__('Single Event','chariy-toolkit'),
		                'description' => esc_html__('Use this addon for add single event.', 'chariy-toolkit'),
		                'icon'        => 'bi-calendar',
		                'category'    => 'THEME CORE',
		                'params'      => array(
		                	'Genaral' => array(
			                    array(
			                        'name'        => 'event_thumb',
			                        'label'       => esc_html__('Event Thumbnail','saasmaxcore'),
			                        'type'        => 'attach_image',
			                        'description' => esc_html__('Set the event thumbnail image size ( 370px x 450px ).', 'chariy-toolkit'),
			                    ),
			                    array(
			                        'name'        => 'event_title',
			                        'label'       => esc_html__('Event Title','saasmaxcore'),
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the event title.', 'chariy-toolkit'),
			                    ),
			                    array(
			                        'name'        => 'event_description',
			                        'label'       => esc_html__('Event Description','saasmaxcore'),
			                        'type'        => 'textarea',
			                        'description' => esc_html__('Set the event title.', 'chariy-toolkit'),
			                    ),
			                    array(
			                        'name'        => 'event_date',
			                        'label'       => esc_html__('Event Day','saasmaxcore'),
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the event expected date. Write 3 letter of month and first letter must be Uppecase like ( Jan 31 2020 )', 'chariy-toolkit'),
			                        'value'=> 'Jan 31 2020'
			                    ),
			                    array(
			                        'name'        => 'event_start',
			                        'label'       => esc_html__('Event Starting Time','saasmaxcore'),
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the event starting and ending time.', 'chariy-toolkit'),
			                        'value'       => '10.00 AM - 2.00 PM',
			                    ),
			                    array(
			                        'name'        => 'event_location',
			                        'label'       => esc_html__('Event Location','saasmaxcore'),
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the location for event.', 'chariy-toolkit'),
			                        'value'       => '167 Stefhen St. New York',
			                    ),
			                    array(
			                        'name'        => 'enable_link',
			                        'label'       => 'Enable Link In Title',
			                        'type'        => 'toggle',
			                        'value'       => 'no',
			                        'description' => esc_html__('If you want set custom link you can check.', 'chariy-toolkit'),
			                    ),
			                    array(
			                        'name'        => 'event_link',
			                        'label'       => esc_html__('Event Link','saasmaxcore'),
			                        'type'        => 'link',
			                        'description' => esc_html__('If you want set custom link you can check.', 'chariy-toolkit'),
			                        'relation'    => array(
			                        	'parent'    => 'enable_link',
			                        	'show_when' => 'yes',
			                        ),
			                    ),
			                    array(
			                        'name'        => 'custom_class',
			                        'label'       => 'Custom Class',
			                        'type'        => 'text',
			                        'description' => esc_html__('Add your extra custom class.', 'chariy-toolkit'),
			                    ),
		                	),
		                	'Style'	=>	array(
								array(
			                		'name'    => 'saasmaxcore_button_style',
			                		'type'    => 'css',
			                		'options' => array(
										array(
											'screens'    => "any,1024,999,767,479",
											'Typography' => array(
												array('property' => 'color', 'label' => 'Color'),
												array('property' => 'background'),
												array('property' => 'font-size', 'label' => 'Font Size'),
												array('property' => 'font-weight', 'label' => 'Font Weight'),
												array('property' => 'font-style', 'label' => 'Font Style'),
												array('property' => 'font-family', 'label' => 'Font Family'),
												array('property' => 'text-align', 'label' => 'Text Align'),
												array('property' => 'text-shadow', 'label' => 'Text Shadow'),
												array('property' => 'text-transform', 'label' => 'Text Transform'),
												array('property' => 'text-decoration', 'label' => 'Text Decoration'),
												array('property' => 'line-height', 'label' => 'Line Height'),
												array('property' => 'letter-spacing', 'label' => 'Letter Spacing'),
												array('property' => 'overflow', 'label' => 'Overflow'),
												array('property' => 'word-break', 'label' => 'Word Break'),					
											),
											'Thumb' => array(
												array('property' => 'width', 'label' => 'Width', 'selector' => '.event-thumb'),
												array('property' => 'height', 'label' => 'Height', 'selector' => '.event-thumb'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.event-thumb'),
											),
											'Date' => array(
												array('property' => 'color', 'label' => 'Color', 'selector' => '.event_date'),
												array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.event_date'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.event_date'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.event_date'),
											),
											'Title' => array(
												array('property' => 'color', 'label' => 'Color', 'selector' => '.event_title'),
												array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.event_title'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.event_title'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.event_title'),
											),
											'Title Link' => array(
												array('property' => 'color', 'label' => 'Color', 'selector' => '.event_title a'),
												array('property' => 'color', 'label' => 'Hover Color', 'selector' => '.event_title a:hover'),
											),
											'Countdown' => array(
												array('property' => 'background', 'label' => 'Background', 'selector' => '.event_lounch_time'),
												array('property' => 'color', 'label' => 'Color', 'selector' => '.event_lounch_time'),
												array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.event_lounch_time'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.event_lounch_time'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.event_lounch_time'),
											),
											'Box' => array(
												array('property' => 'background', 'label' => 'Background'),
												array('property' => 'width', 'label' => 'Width'),
												array('property' => 'height', 'label' => 'Height'),
												array('property' => 'box-shadow', 'label' => 'Box Shadow'),
												array('property' => 'border', 'label' => 'Border'),
												array('property' => 'border-radius', 'label' => 'Border Radius'),
												array('property' => 'float', 'label' => 'Float'),
												array('property' => 'display', 'label' => 'Display'),
												array('property' => 'margin', 'label' => 'Margin'),
												array('property' => 'padding', 'label' => 'Padding'),
											),
										),
										array()
									)
								),
		                	),
		                ),
		            ),  // End of elemnt kc_icon 	 
		        )
		    ); // End add map

		}
	}
}

if (!function_exists('saasmaxcore_event_content')) {
	function saasmaxcore_event_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'event_title'       => '',
			'event_description' => '',
			'event_date'        => '',
			'event_start'       => '',
			'event_thumb'       => '',
			'event_location'    => '',
			'enable_link'       => '',
			'event_link'        => '',
			'custom_class'      => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		$r_id = rand(5655,5874);

		if ( $enable_link == 'yes' && !empty( $event_title ) ) {

			if ( !empty( $event_link ) ) {
				$link = explode('|', $event_link);
			}else{
				$link = array();
			}

			$event_title = '<h3 class="event_title"><a href="'.(isset( $link[0] ) ? esc_url($link[0]) : '').'" '.(isset($link[2]) ? 'target="'.$link[2].'"' : '').'>'.esc_html( $event_title ).'</a></h3>';
		}elseif( !empty( $event_title ) ){
			$event_title = '<h3 class="event_title">'.esc_html( $event_title ).'</h3>';
		}else{
			$event_title = '';
		}

		if ( !empty( $event_description ) ){
			$event_description = wpautop( esc_html__( $event_description ) );
		}else{
			$event_description = '';
		}
		
		if ( !empty( $event_date ) ) {
			$count_data = explode(' ', $event_date );
			var_dump($count_data);
			switch ($count_data[1]) {
				case 'Jan':
					$month = '01';
					break;
				
				case 'Feb':
					$month = '02';
					break;
				
				case 'Mar':
					$month = '03';
					break;
				
				case 'Apr':
					$month = '04';
					break;
				
				case 'May':
					$month = '05';
					break;
				
				case 'Jun':
					$month = '06';
					break;
				
				case 'Jul':
					$month = '07';
					break;
				
				case 'Aug':
					$month = '08';
					break;
				
				case 'Sep':
					$month = '09';
					break;
				
				case 'Oct':
					$month = '10';
					break;
				
				case 'Nov':
					$month = '11';
					break;
				
				case 'Dec':
					$month = '12';
					break;
				
				default:
					$month = '01';
					break;
			}
			$day = $count_data[1];
			$year = $count_data[2];

			$event_coundown = '<div class="event_lounch_time" data-countdown="'.$year.'/'.$month.'/'.$day.'"></div>';
		}

		if ( !empty( $event_date ) ) {
			$event_date = '<div class="event_date">'.esc_html( $event_date ).'</div>';
		}else{
			$event_date = '';
		}

		if ( !empty( $event_start ) ) {
			$event_start = '<span><i class="ti-time"></i> '.$event_start.'</span> ';
		}else{
			$event_start = '';
		}

		if ( !empty( $event_location ) ) {
			$event_location = '<span><i class="ti-location-pin"></i> '.esc_html( $event_location ).'</span>';
		}else{
			$event_location = '';
		}

		if ( !empty( $event_start ) || !empty( $event_location ) ) {
			$event_start_and_end = '
			<div class="event_location_time">
				<div class="event_location">
					<p>'.$event_start.''.$event_location.'</p>
				</div>
			</div>';
		}else{
			$event_start_and_end = '';
		}

		if ( !empty( $event_thumb ) ) {
			$event_thumb = '<img src="'.esc_url( wp_get_attachment_image_url( $event_thumb, 'full') ).'" alt =""/>';
		}else{
			$event_thumb = '';
		}
		$data = '
		<div class="single-event-two blue '.esc_attr( implode(' ', $master_class) ).' '.(isset( $custom_class ) ? $custom_class : '').'">
			<div class="event-thumb">
				'.(isset( $event_thumb ) ? $event_thumb : '' ).'
			</div>
			<div class="event-details">
				'.( isset( $event_date ) ? $event_date : '' ).'
				'.( isset( $event_title ) ? $event_title : '' ).'
				'.( isset( $event_description ) ? $event_description : '' ).'
				'.( isset( $event_start_and_end ) ? $event_start_and_end : '' ).'			
			</div>
			'.( isset( $event_coundown ) ? $event_coundown : '' ).'
		</div>';

		return $data;
	}
}
add_shortcode('saasmaxcore_event', 'saasmaxcore_event_content');
?>