<?php

add_action('init', 'saasmaxcore_welcome_area', 99);
if (!function_exists('saasmaxcore_welcome_area')) {
	function saasmaxcore_welcome_area() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_welcome' => array(
					'name'        => esc_html__('Welcome Area', 'saasmaxcore'),
					'icon'        => 'bi-article',
					'description' => esc_html__('Use this addon welcome area.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
							array(
								'name'  => 'welcome_subtitle',
								'label' => esc_html__('Subtitle', 'saasmaxcore'),
								'type'  => 'text',
							),
							array(
								'name'  => 'welcome_title',
								'label' => esc_html__('Title', 'saasmaxcore'),
								'type'  => 'text',
							),
							array(
								'name'  => 'welcome_description',
								'label' => esc_html__('Short Descripton', 'saasmaxcore'),
								'type'  => 'textarea',
							),
							array(
								'name'    => 'welcome_button',
								'label'   => esc_html__('Buttons', 'saasmaxcore'),
								'type'    => 'group',
								'options' => array(
									'add_text' => 'Add Button',
								),
								'params' => array(
									array(
										'type'  => 'text',
										'label' => 'Button Text',
										'name'  => 'button_text',
										'value' => 'Button Text',
									),
									array(
										'type'  => 'link',
										'label' => 'Button Link',
										'name'  => 'button_link',
										'value' => 'http://example.com',
									),
									array(
										'type'  => 'text',
										'label' => 'Button Class',
										'name'  => 'custom_class',
									),
								),
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Style' => array(
							array(
								'name'    => 'saasmaxcore_welcome_area_style',
								'type'    => 'css',
								'options' => array(
									array(
										"screens"      => "any,1024,999,767,479",
										'Text Waraper' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.welcome-text'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.welcome-text'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome-text'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome-text'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome-text'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome-text'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome-text'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome-text'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome-text'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome-text'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome-text'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome-text'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome-text'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.welcome-text'),
										),
										'Subtitle' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.welcome_subtitle'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.welcome_subtitle'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.welcome_subtitle'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.welcome_subtitle'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome_subtitle'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.welcome_subtitle'),
										),
                                        'Subtitle Before' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.welcome_subtitle:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.welcome_subtitle:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.welcome_subtitle:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.welcome_subtitle:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome_subtitle:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.welcome_subtitle:before'),
                                        ),
                                        'Subtitle After' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.welcome_subtitle:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.welcome_subtitle:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.welcome_subtitle:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.welcome_subtitle:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome_subtitle:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.welcome_subtitle:after'),
                                        ),
										'Title' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.welcome_title'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.welcome_title'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome_title'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome_title'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome_title'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome_title'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome_title'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome_title'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome_title'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome_title'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome_title'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.welcome_title'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome_title'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome_title'),
										),
										'Description' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.welcome_description'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.welcome_description'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.welcome_description'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.welcome_description'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.welcome_description'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.welcome_description'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.welcome_description'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.welcome_description'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.welcome_description'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.welcome_description'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.welcome_description'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.welcome_description'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.welcome_description'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.welcome_description'),
										),
										'Button Waraper' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.home-button'),
											array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.home-button'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.home-button'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.home-button'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.home-button'),
											array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.home-button'),
											array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.home-button'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.home-button'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.home-button'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.home-button'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.home-button'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.home-button'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.home-button'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.home-button'),
										),
                                        'Buttons' => array(
                                            array('property' => 'color', 'label' => 'Color', 'selector' => '.home-button a'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.home-button a'),
                                            array('property' => 'width', 'label' => 'Width', 'selector' => '.home-button a'),
                                            array('property' => 'height', 'label' => 'height', 'selector' => '.home-button a'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.home-button a'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.home-button a'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.home-button a'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.home-button a'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.home-button a'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.home-button a'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.home-button a'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.home-button a'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.home-button a'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.home-button a'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.home-button a'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.home-button a'),
                                        ),
										'Buttons Hover' => array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.home-button a:hover'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.home-button a:hover'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.home-button a:hover'),
											array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.home-button a:hover'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.home-button a:hover'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.home-button a:hover'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.home-button a:hover'),
										),
										'Boxes' => array(
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'border-radius', 'label' => 'Border Radius'),
											array('property' => 'display', 'label' => 'Display'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'margin', 'label' => 'Margin'),
										),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_welcome_content')) {
	function saasmaxcore_welcome_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'welcome_title'                => '',
			'welcome_subtitle'             => '',
			'welcome_description'          => '',
			'welcome_button'               => '',
			'enable_welcome_mockup_slider' => '',
			'welcome_slide_phone_mockup'   => '',
			'welcome_slide_images'         => '',
			'custom_class'                 => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		if (!empty($welcome_subtitle)) {
			$welcome_subtitle = '<h4 class="welcome_subtitle wow fadeInUp" data-wow-delay="0.3s">' . esc_html($welcome_subtitle) . '</h4>';
		} else {
			$welcome_subtitle = '';
		}

		if (!empty($welcome_title)) {
			$welcome_title = '<h1 class="welcome_title wow fadeInUp" data-wow-delay="0.6s">' . esc_html($welcome_title) . '</h1>';
		} else {
			$welcome_title = '';
		}

		if (!empty($welcome_description)) {
			$welcome_description = '<div class="welcome_description wow fadeInUp" data-wow-delay="0.9s">' . wpautop(esc_html($welcome_description)) . '</div>';
		} else {
			$welcome_description = '';
		}

		if (!empty($welcome_slide_images)) {
			$slide_images = explode(',', $welcome_slide_images);
		} else {
			$slide_images = '';
		}

		if (!empty($welcome_button)) {
			$welcome_area_button = '
            <div class="home-button xs-mt40 wow fadeInUp" data-wow-delay="1s">';
			foreach ($welcome_button as $single_button) {

				$welcome_area_button .= '
                <a class="left '.esc_attr( $single_button->custom_class ).'" href="' . esc_url($single_button->button_link) . '">' . esc_html($single_button->button_text) . '</a>';
			}
			$welcome_area_button .= '
            </div>';
		} else {
			$welcome_area_button = '';
		}

		$data = '
        <div class="welcome-text-area ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
            <div class="welcome-text">
                ' . (isset($welcome_subtitle) ? $welcome_subtitle : '') . '
                ' . (isset($welcome_title) ? $welcome_title : '') . '
                ' . (isset($welcome_description) ? $welcome_description : '') . '
                ' . (isset($welcome_area_button) ? $welcome_area_button : '') . '
            </div>
        </div>';
		return $data;
	}
}
add_shortcode('saasmaxcore_welcome', 'saasmaxcore_welcome_content');
?>