<?php

add_action('init', 'saasmaxcore_button_addon', 99);
if (!function_exists('saasmaxcore_button_addon')) {
	function saasmaxcore_button_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_button' => array(
					'name'        => esc_html__('Button', 'saasmaxcore'),
					'icon'        => 'sl-link',
					'description' => esc_html__('Use this addon for button.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
							array(
								'name'     => 'button_text',
								'label'    => esc_html__('Button Text', 'saasmaxcore'),
								'type'     => 'text',
								'value' => 'Read More',
							),
							array(
								'name'    => 'button_link',
								'label'   => esc_html__('Button Link', 'saasmaxcore'),
								'type'    => 'link',
								'value' => 'https://google.com',
							),
							array(
								'name'  => 'show_icon',
								'label' => esc_html__('Show Icon ?', 'saasmaxcore'),
								'type'  => 'toggle',
								'value' => 'no',
							),
							array(
								'name'     => 'button_icon',
								'label'    => esc_html__('Button Icon', 'saasmaxcore'),
								'type'     => 'icon_picker',
								'value'    => 'fa-long-arrow-alt-right',
								'relation' => array(
							        'parent'    => 'show_icon',
							        'show_when' => 'yes',
							    ),
							),
							array(
								'name'    => 'icon_position',
								'label'   => esc_html__('Button Icon Positon', 'saasmaxcore'),
								'type'    => 'select',
								'options' => array(
									'left' => 'Icon Left',
									'right'  => 'Icon Right',
								),
								'value' => 'right',
								'relation' => array(
							        'parent'    => 'show_icon',
							        'show_when' => 'yes',
							    ),
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Style' => array(
							array(
								'name'    => 'saasmaxcore_button_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										'screens' => "any,1024,999,767,479",
										'BUTTON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.genaral_button'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.genaral_button'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.genaral_button'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.genaral_button'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.genaral_button'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.genaral_button'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.genaral_button'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.genaral_button'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.genaral_button'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.genaral_button'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.genaral_button'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.genaral_button'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.genaral_button'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.genaral_button'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.genaral_button'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.genaral_button'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.genaral_button'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.genaral_button'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.genaral_button'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.genaral_button'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.genaral_button'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.genaral_button'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.genaral_button'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.genaral_button'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.genaral_button'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.genaral_button'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.genaral_button'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.genaral_button'),
										),
										'ICON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.genaral_button i'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.genaral_button i'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.genaral_button i'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.genaral_button i'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.genaral_button i'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.genaral_button i'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.genaral_button i'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.genaral_button i'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.genaral_button i'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.genaral_button i'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.genaral_button i'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.genaral_button i'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.genaral_button i'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.genaral_button i'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.genaral_button i'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.genaral_button i'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.genaral_button i'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.genaral_button i'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.genaral_button i'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.genaral_button i'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.genaral_button i'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.genaral_button i'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.genaral_button i'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.genaral_button i'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.genaral_button i'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.genaral_button i'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.genaral_button i'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.genaral_button i'),
										),
										'BEFORE' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => '.genaral_button:before'),
                                            array('property' => 'color', 'label' => 'Color','selector' => '.genaral_button:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.genaral_button:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.genaral_button:before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.genaral_button:before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.genaral_button:before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.genaral_button:before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.genaral_button:before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.genaral_button:before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.genaral_button:before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.genaral_button:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.genaral_button:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.genaral_button:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.genaral_button:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.genaral_button:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.genaral_button:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.genaral_button:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.genaral_button:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.genaral_button:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.genaral_button:before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.genaral_button:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.genaral_button:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.genaral_button:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.genaral_button:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.genaral_button:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.genaral_button:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.genaral_button:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.genaral_button:before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.genaral_button:before'),
										),
										'AFTER' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => '.genaral_button:after'),
                                            array('property' => 'color', 'label' => 'Color','selector' => '.genaral_button:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.genaral_button:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.genaral_button:after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.genaral_button:after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.genaral_button:after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.genaral_button:after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.genaral_button:after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.genaral_button:after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.genaral_button:after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.genaral_button:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.genaral_button:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.genaral_button:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.genaral_button:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.genaral_button:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.genaral_button:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.genaral_button:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.genaral_button:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.genaral_button:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.genaral_button:after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.genaral_button:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.genaral_button:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.genaral_button:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.genaral_button:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.genaral_button:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.genaral_button:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.genaral_button:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.genaral_button:after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.genaral_button:after'),
										),
										'HOVER' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.genaral_button:hover'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.genaral_button:hover'),
                                            array('property' => 'opacity', 'label' => 'Before Opacity & Background', 'selector' => '.genaral_button:hover:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.genaral_button:hover:before'),
                                            array('property' => 'opacity', 'label' => 'After Opacity & Background', 'selector' => '.genaral_button:hover:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.genaral_button:hover:after'),
                                            array('property' => 'color', 'label' => 'Icon Color', 'selector' => '.genaral_button:hover i'),
                                            array('property' => 'background-color', 'label' => 'Icon Background', 'selector' => '.genaral_button:hover i'),
                                            array('property' => 'margin', 'label' => 'Icon Margin', 'selector' => '.genaral_button:hover i'),
                                            array('property' => 'width', 'label' => 'Icon Width', 'selector' => '.genaral_button:hover i'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.genaral_button:hover'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.genaral_button:hover'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.genaral_button:hover'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.genaral_button:hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.genaral_button:hover'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.genaral_button:hover'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.genaral_button:hover'),
											array('property' => 'custom', 'label' => 'Custom', 'selector' => '.genaral_button:hover'),
										),
										'BOXES' => array(
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'background', 'label' => 'Background'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'margin', 'label' => 'Margin'),
										),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_button_content')) {
	function saasmaxcore_button_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'button_text'   => '',
			'button_link'   => '',
			'show_icon'     => '',
			'button_icon'   => '',
			'icon_position' => '',
			'custom_class'  => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		if ( !empty( $button_icon ) ) {
			$button_icon = $button_icon;
		}else{
			$button_icon = 'ti-star';
		}

		if ( !empty( $button_text ) ) {
			$button_text = $button_text;
		}else{
			$button_text = 'Read More';
		}

		if ( !empty( $button_link ) ) {
			$btn = explode('|', $button_link);

			if ( !empty($btn[1]) ) {
				$button_text = $btn[1];
			}else{
				$button_text = $button_text;
			}

			if ( !empty($btn[2] ) ) {
				$target = 'target="'.$btn[2].'"';
			}else{
				$target = '';
			}
		}

		if ( 'yes' == $show_icon ) {
			if ( 'right' == $icon_position) {
				$button = '<a class="genaral_button" href="'. esc_url( $btn[0] ).'" '.$target.'>'.esc_html( $button_text ).'<i class="'.esc_attr( $button_icon ).'"></i></a>';
			}elseif ( 'left'  == $icon_position ) {
				$button = '<a class="genaral_button" href="'. esc_url( $btn[0] ).'" '.$target.'><i class="'.esc_attr( $button_icon ).'"></i>'.esc_html( $button_text ).'</a>';
			}
		}else{
			$button = '<a class="genaral_button" href="'. esc_url( $btn[0] ).'" '.$target.'>'.esc_html( $button_text ).'</a>';
		}

		$data = '
		<div class="read-more-button ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
			'.(isset( $button ) ? $button : '').'
		</div>';
		return $data;
	}
}
add_shortcode('saasmaxcore_button', 'saasmaxcore_button_content');
?>