<?php

add_action('init', 'saasmaxcore_qrcode_addon', 99);
if (!function_exists('saasmaxcore_qrcode_addon')) {
	function saasmaxcore_qrcode_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_qrcode' => array(
					'name'        => esc_html__('QR CODE', 'saasmaxcore'),
					'icon'        => 'fa fa-qrcode',
					'description' => esc_html__('Use this addon for makeing QR code anything.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
							/*array(
								'name'     => 'title',
								'label'    => esc_html__('QR Quode Title', 'saasmaxcore'),
								'type'     => 'text',
								'value' => '',
							),
                            array(
                                'name'     => 'subtitle',
                                'label'    => esc_html__('QR Code Subtitle', 'saasmaxcore'),
                                'type'     => 'text',
                                'value' => '',
                            ),*/
                            array(
                                'name'     => 'qr_text',
                                'type'     => 'textarea',
                                'label'    => esc_html__('QR Code Text', 'saasmaxcore'),
                                'description' => esc_html__( 'Set the QR code text, you can use ( link / address / name ) etc.' ,'saasmaxcore' ),
                            ),
							array(
								'name'    => 'qr_color',
								'label'   => esc_html__('Qr Code Color', 'saasmaxcore'),
								'type'    => 'color_picker',
								'value' => '#202020',
							),
                            array(
                                'name'    => 'qr_bg_color',
                                'label'   => esc_html__('Qr Code Background', 'saasmaxcore'),
                                'type'    => 'color_picker',
                                'value' => '#ffffff',
                            ),
                            array(
                                'name'     => 'qr_height',
                                'label'    => esc_html__('Qr Code Height', 'saasmaxcore'),
                                'type'     => 'text',
                                'value'    => '150',
                            ),
							array(
								'name'  => 'qr_width',
								'label' => esc_html__('Qr Code Width', 'saasmaxcore'),
								'type'  => 'text',
								'value' => '150',
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Style' => array(
							array(
								'name'    => 'saasmaxcore_qrcode_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										'screens' => "any,1024,999,767,479",
										'QRCODE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.qrcode'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.qrcode'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.qrcode'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.qrcode'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.qrcode'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.qrcode'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.qrcode'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.qrcode'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.qrcode'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.qrcode'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.qrcode'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.qrcode'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.qrcode'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.qrcode'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.qrcode'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.qrcode'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.qrcode'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.qrcode'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.qrcode'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '.qrcode'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.qrcode'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.qrcode'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.qrcode'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.qrcode'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.qrcode'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.qrcode'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.qrcode'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '.qrcode'),
										),
										'BOXES' => array(
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'background', 'label' => 'Background'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'margin', 'label' => 'Margin'),
										),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_qrcode_content')) {
	function saasmaxcore_qrcode_content($atts, $content = '') {
		extract(shortcode_atts(array(
            /*'title'        => '',
            'subtitle'     => '',*/
            'qr_text'      => '',
            'qr_color'     => '',
            'qr_bg_color'  => '',
            'qr_height'    => '',
            'qr_width'     => '',
            'custom_class' => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

        $qr_color = !empty( $qr_color ) ? $qr_color : '#202020';
        $qr_bg_color = !empty( $qr_bg_color ) ? $qr_bg_color : '#ffffff';

        wp_enqueue_script( 'qrcode' );
        $script = '
            ;(function($) {
                jQuery(document).on("ready",function() {
                    var qrdata = $(".qrcode").attr("data-qrcode");
                    jQuery(".qrcode").qrcode({
                        width: '.$qr_width.',
                        height: '.$qr_height.',
                        foreground:"'.$qr_color.'",
                        background: "'.$qr_bg_color.'",
                        text: qrdata,
                    });
                });
            })( jQuery );
        ';
        wp_add_inline_script( 'saasmaxcore', $script );

		if ( !empty( $title ) ) {
			$title = $title;
		}else{
			$title = '';
		}

		if ( !empty( $subtitle ) ) {
			$subtitle = $subtitle;
		}else{
			$subtitle = '';
		}

        if ( !empty($qr_text) ) {
			$qrcode = '<div class="qrcode" data-qrcode="'. $qr_text .'"></div>';
		}else{
			$qrcode = '';
		}
		$data = '
		<div class="qrcode-warp ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
            '.(isset( $title ) ? $title : '').'
            '.(isset( $subtitle ) ? $subtitle : '').'
			'.(isset( $qrcode ) ? $qrcode : '').'
		</div>';
		return $data;
	}
}
add_shortcode('saasmaxcore_qrcode', 'saasmaxcore_qrcode_content');
?>