<?php

add_action('init', 'saasmaxcore_testmonial_single_addon', 99);
if (!function_exists('saasmaxcore_testmonial_single_addon')) {
	function saasmaxcore_testmonial_single_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_testmonial_single' => array(
					'name'        => esc_html__('Single Testmonial Item', 'saasmaxcore'),
					'icon'        => 'et et-chat',
					'description' => esc_html__('Use this addon for Testmonial.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
							array(
								'name'        => 'testmonial_style',
								'label'       => esc_html__('Select Testmonial Style', 'saasmaxcore'),
								'description' => esc_html__('Select your testmonial which you want to show.', 'saasmaxcore'),
								'type'        => 'radio_image',
								'options'     => array(
									'testmonial-style-five'  => plugins_url( '../assets/img/testmonial/testmonial_1.png', __FILE__ ),
									'testmonial-style-six'   => plugins_url( '../assets/img/testmonial/testmonial_2.png', __FILE__ ),
									'testmonial-style-seven' => plugins_url( '../assets/img/testmonial/testmonial_3.png', __FILE__ ),
									'testmonial-style-eight' => plugins_url( '../assets/img/testmonial/testmonial_4.png', __FILE__ ),
									'testmonial-style-nine'  => plugins_url( '../assets/img/testmonial/testmonial_5.png', __FILE__ ),
								),
								'value' => 'testmonial-style-five',
							),
							array(
								'type'  => 'text',
								'label' => esc_html__( 'Testmonial Type Title', 'saasmaxcore' ),
								'name'  => 'testmonial_title',
								'value' => '“ Design Quality & Usability ”',
							),
							array(
								'type'  => 'text',
								'label' => esc_html__( 'Testmonial Author Name', 'saasmaxcore' ),
								'name'  => 'member_name',
								'value' => 'John Doe',
							),
							array(
								'type'  => 'text',
								'label' => 'Designation',
								'name'  => 'member_company',
								'value' => 'CEO & Founder',
							),
							array(
								'type'  => 'attach_image_url',
								'label' => esc_html__( 'Testmonial Member Image', 'saasmaxcore' ),
								'name'  => 'member_image',
								'value' => get_template_directory_uri().'/assets/img/testmonial.jpg',
							),
							array(
								'type'  => 'attach_image_url',
								'label' => esc_html__( 'Testmonial Quote Image', 'saasmaxcore' ),
								'name'  => 'quote_image',
								'value' => plugins_url( '../assets/img/quote.png', __FILE__ ),
							),
							array(
								'type'  => 'textarea',
								'label' => esc_html__( 'Testmonial Content', 'saasmaxcore' ),
								'name'  => 'member_desc',
								'value' => 'Lorem ipsum madolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor coli incidit labore Lorem ipsum amet madolor sit amet Lorem ipsum madolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor coli incidit labore Lorem ipsum amet madolor sit amet',
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Waraper Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Style' => array(
							array(
								'name'    => 'saasmaxcore_testmonial_single_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										"screens"        => "any,1024,999,767,479",
										'Quote'=> array(
											array('property' => 'background', 'label' => 'Background', 'selector' => '.testmonial-quote'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.testmonial-quote'),
											array('property' => 'filter', 'label' => 'Filter', 'selector' => '.testmonial-quote'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.testmonial-quote'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.testmonial-quote'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.testmonial-quote'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.testmonial-quote'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.testmonial-quote'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.testmonial-quote'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.testmonial-quote'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.testmonial-quote'),
										),
										'Content'=> array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.author-content'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.author-content'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.author-content'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.author-content'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.author-content'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.author-content'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.author-content'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.author-content'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.author-content'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.author-content'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.author-content'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.author-content'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.author-content'),
										),
										'Title'=> array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.testmonial_title'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.testmonial_title'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.testmonial_title'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.testmonial_title'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.testmonial_title'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.testmonial_title'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.testmonial_title'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.testmonial_title'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.testmonial_title'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.testmonial_title'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.testmonial_title'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.testmonial_title'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.testmonial_title'),
										),
										'Name'=> array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.member_name'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.member_name'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.member_name'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.member_name'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.member_name'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.member_name'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.member_name'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.member_name'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member_name'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member_name'),
										),
										'Designation Warp'=> array(
											array('property' => 'background', 'label' => 'Background', 'selector' => '.member-name-and-photo'),
											array('property' => 'filter', 'label' => 'Filter', 'selector' => '.member-name-and-photo'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.member-name-and-photo'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.member-name-and-photo'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.member-name-and-photo'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.member-name-and-photo'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.member-name-and-photo'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member-name-and-photo'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member-name-and-photo'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.member-name-and-photo'),
										),
										'Designation'=> array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.member-designation-details p'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.member-designation-details p'),
											array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.member-designation-details p'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.member-designation-details p'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.member-designation-details p'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.member-designation-details p'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.member-designation-details p'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.member-designation-details p'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.member-designation-details p'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.member-designation-details p'),
										),
										'Thumb Warp'=> array(
											array('property' => 'background', 'label' => 'Background', 'selector' => '.single-testmonial-photo'),
											array('property' => 'filter', 'label' => 'Filter', 'selector' => '.single-testmonial-photo'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.single-testmonial-photo'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.single-testmonial-photo'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.single-testmonial-photo'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-testmonial-photo'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-testmonial-photo'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-testmonial-photo'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-testmonial-photo'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single-testmonial-photo'),
										),
										'Thumb'=> array(
											array('property' => 'background', 'label' => 'Background', 'selector' => '.single-testmonial-photo img'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.single-testmonial-photo img'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.single-testmonial-photo img'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-testmonial-photo img'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-testmonial-photo img'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-testmonial-photo img'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-testmonial-photo img'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single-testmonial-photo img'),
										),
										'Thumb Before'=> array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-testmonial-photo:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single-testmonial-photo:before'),
										),
										'Navigaton'=> array(
											array('property' => 'color', 'label' => 'Color', 'selector' => '.owl-nav > div'),
											array('property' => 'background-color', 'label' => 'Background', 'selector' => '.owl-nav > div'),
											array('property' => 'color', 'label' => 'Hover Color', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'background-color', 'label' => 'Hover Background', 'selector' => '.owl-nav > div:hover'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.owl-nav > div'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-nav > div'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-nav > div'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-nav > div'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-nav > div'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-nav > div'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-nav > div'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-nav > div'),
										),
										'Dot Warap'=> array(
											array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-dots'),
											array('property' => 'color', 'label' => 'Hover Color', 'selector' => '.owl-dots'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.owl-dots'),
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.owl-dots'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-dots'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-dots'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.owl-dots'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.owl-dots'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.owl-dots'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.owl-dots'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.owl-dots'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.owl-dots'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.owl-dots'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-dots'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-dots'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-dots'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-dots'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-dots'),
										),
										'Dot'=> array(
											array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-dots > div'),
											array('property' => 'color', 'label' => 'Hover Color', 'selector' => '.owl-dots > div'),
											array('property' => 'display', 'label' => 'Display', 'selector' => '.owl-dots > div'),
											array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.owl-dots > div'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-dots > div'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-dots > div'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.owl-dots > div'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-dots > div'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-dots > div'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-dots > div'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-dots > div'),
											array('property' => 'transform', 'label' => 'Transform', 'selector' => '.owl-dots > div'),
											array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-dots > div'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-dots > div'),
										),
										'Dot Active'=> array(
											array('property' => 'background', 'label' => 'Background', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'color', 'label' => 'Hover Color', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'transform', 'label' => 'Transform', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'transition', 'label' => 'Transition', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
											array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.owl-dots > div.active,.owl-dots > div:hover'),
										),
										'Boxes'=> array(
											array('property' => 'background', 'label' => 'Background'),
											array('property' => 'color', 'label' => 'Color'),
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'width', 'label' => 'Width'),
											array('property' => 'height', 'label' => 'Height'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'margin', 'label' => 'Margin'),
											array('property' => 'padding', 'label' => 'Padding'),
										),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_testmonial_single_content')) {
	function saasmaxcore_testmonial_single_content($atts, $content = '') {
		extract($atts);
		$r_id = rand(355,566);
		$master_class = apply_filters('kc-el-class', $atts);


			$testmonial_content = '';

			if ('testmonial-style-nine' == $testmonial_style ) {
				$testmonial_content .='
				<div class="single-testmonial-nine"><div class="row flex-v-center">';

					if ( !empty( $member_image ) ) {
						$testmonial_content .='
						<div class="col-md-6">
							<div class="author-img">
								<img src="'.esc_url( $member_image ).'" alt="'.esc_attr( get_the_title() ).'">
							</div>
						</div>';
					}

					if (  !empty( $member_desc) || !empty( $member_name) ) {
						$testmonial_content .='
						<div class="col-md-6">';
						if( !empty( $member_desc ) ){
							$testmonial_content .='
						    <div class="author-content">';
							    if ( !empty( $quote_image ) ) {
							    	$testmonial_content .='<div class="testmonial-quote"><img src="'.$quote_image.'" alt=""></div>';
							    }
						        
						        if ( !empty( $testmonial_title ) ) {
						        	$testmonial_content .='<h3 class="testmonial_title">'. esc_html( $testmonial_title ) .'</h3>';
						        }
						        $testmonial_content .=''.wpautop( $member_desc ).'';
							$testmonial_content .='
						    </div>';
						}
						if( !empty( $member_name ) ){

							if( !empty( $member_image ) ){
								$testmonial_content .='
								<div class="member-designation-details">
									<div class="member-name-and-photo">';
										$testmonial_content .='
										<div class="single-testmonial-photo">
											<img src="'.esc_url( $member_image ).'" alt="'.esc_attr( get_the_title() ).'">
										</div>';
									if( !empty( $member_name ) ){
										$testmonial_content .='
										<h4 class="member_name">'.esc_html( $member_name ).'</h4>';
									}
									if( !empty( $member_company ) ){
										$testmonial_content .='
										<p>'.esc_html( $member_company ).'</p>';
									}
									$testmonial_content .='
									</div>
								</div>';
						    }
						}
						$testmonial_content .='
						</div>';
					}

				    $testmonial_content .='
				</div></div>';
			}else{
				$testmonial_content .='
				<div class="single-testmonial">';
				if( !empty( $member_desc ) ){
					$testmonial_content .='
				    <div class="author-content">';
					    if ( !empty( $quote_image ) ) {
					    	$testmonial_content .='<div class="testmonial-quote"><img src="'.$quote_image.'" alt=""></div>';
					    }
				        if ( !empty( $testmonial_title ) ) {
				        	$testmonial_content .='<h3 class="testmonial_title">'. esc_html( $testmonial_title ) .'</h3>';
				        }
						$testmonial_content .=''.wpautop( $member_desc ).'';
					$testmonial_content .='
				    </div>';
				}
				if( !empty( $member_image ) || !empty( $member_name ) ){

					if( !empty( $member_image ) ){
						$testmonial_content .='
						<div class="member-designation-details">
							<div class="member-name-and-photo">';
								$testmonial_content .='
								<div class="single-testmonial-photo">
									<img src="'.esc_url( $member_image ).'" alt="'.esc_attr( get_the_title() ).'">
								</div>';
							if( !empty( $member_name ) ){
								$testmonial_content .='
								<h4 class="member_name">'.esc_html( $member_name ).'</h4>';
							}
							if( !empty( $member_company ) ){
								$testmonial_content .='
								<p>'.esc_html( $member_company ).'</p>';
							}
							$testmonial_content .='
							</div>
						</div>';
				    }
				}
				    $testmonial_content .='
				</div>';
			}

	$data = '
	<div class="'.$testmonial_style.' ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
		'.(isset( $testmonial_content ) ? $testmonial_content : '').'
	</div>';
	return $data;
	}
}
add_shortcode('saasmaxcore_testmonial_single', 'saasmaxcore_testmonial_single_content');
?>