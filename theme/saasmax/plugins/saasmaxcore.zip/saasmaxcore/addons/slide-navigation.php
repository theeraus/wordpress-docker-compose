<?php

add_action('init', 'saasmaxcore_slide_control_addon', 99);
if (!function_exists('saasmaxcore_slide_control_addon')) {
	function saasmaxcore_slide_control_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_slide_control' => array(
					'name'        => esc_html__('Slide Navigation', 'saasmaxcore'),
					'icon'        => 'bi-accordion-horizontal',
					'description' => esc_html__('Use this addon for slide navigaiton.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
                            array(
                                'name'     => 'control_class_id',
                                'label'    => esc_html__('Slider Area CLASS or ID', 'saasmaxcore'),
                                'description'    => esc_html__('Set the slider id or class ( basically you need to here thore slider area id where is slider already showing ) if don\'t have any id plese set a id then paste here like ( .class_name for class ) and ( #id_name for id ).', 'saasmaxcore'),
                                'type'     => 'text',
                                'value' => '',
                            ),
                            array(
                                'name'     => 'control_type',
                                'label'    => esc_html__('Button Text', 'saasmaxcore'),
                                'type'     => 'select',
                                'options' => array(
                                    'icon_button' => 'Icon Button',
                                    'text_button' => 'Text Button',
                                    'image_button' => 'Image Button',
                                ),
                                'value' => 'icon_button',
                            ),
							array(
								'name'     => 'next_icon',
								'label'    => esc_html__('Next Button Icon', 'saasmaxcore'),
                                'description'    => esc_html__('Set the slider next button icon.', 'saasmaxcore'),
								'type'     => 'icon_picker',
								'value'    => 'sl-arrow-right',
								'relation' => array(
							        'parent'    => 'control_type',
							        'show_when' => 'icon_button',
							    ),
							),
                            array(
                                'name'     => 'prev_icon',
                                'label'    => esc_html__('Previous Button Icon', 'saasmaxcore'),
                                'description'    => esc_html__('Set the slider previous button icon.', 'saasmaxcore'),
                                'type'     => 'icon_picker',
                                'value'    => 'sl-arrow-left',
                                'relation' => array(
                                    'parent'    => 'control_type',
                                    'show_when' => 'icon_button',
                                ),
                            ),
                            array(
                                'name'     => 'next_text',
                                'label'    => esc_html__('Next Button Text', 'saasmaxcore'),
                                'description'    => esc_html__('Set the slider next button text.', 'saasmaxcore'),
                                'type'     => 'text',
                                'value' => 'Next',
                                'relation' => array(
                                    'parent'    => 'control_type',
                                    'show_when' => 'text_button',
                                ),
                            ),
                            array(
                                'name'     => 'prev_text',
                                'label'    => esc_html__('Previous Button Text', 'saasmaxcore'),
                                'description'    => esc_html__('Set the slider previous button text.', 'saasmaxcore'),
                                'type'     => 'text',
                                'value' => 'Prev',
                                'relation' => array(
                                    'parent'    => 'control_type',
                                    'show_when' => 'text_button',
                                ),
                            ),
                            array(
                                'name'     => 'next_image',
                                'label'    => esc_html__('Next Button Image Icon', 'saasmaxcore'),
                                'description'    => esc_html__('Set the slider next button image icon.', 'saasmaxcore'),
                                'type'     => 'attach_image',
                                'value' => '',
                                'relation' => array(
                                    'parent'    => 'control_type',
                                    'show_when' => 'image_button',
                                ),
                            ),
                            array(
                                'name'     => 'prev_image',
                                'label'    => esc_html__('Previous Button Image Icon', 'saasmaxcore'),
                                'description'    => esc_html__('Set the slider previous button image icon.', 'saasmaxcore'),
                                'type'     => 'attach_image',
                                'value' => '',
                                'relation' => array(
                                    'parent'    => 'control_type',
                                    'show_when' => 'image_button',
                                ),
                            ),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Style' => array(
							array(
								'name'    => 'saasmaxcore_slide_control_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										'screens' => "any,1024,999,767,479",
										'BUTTON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '> div'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '> div'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '> div'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '> div'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '> div'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '> div'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '> div'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '> div'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '> div'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '> div'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '> div'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '> div'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '> div'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '> div'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '> div'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '> div'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '> div'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '> div'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '> div'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '> div'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '> div'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '> div'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '> div'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '> div'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '> div'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '> div'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '> div'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '> div'),
										),
										'ICON'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '> div i'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '> div i'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '> div i'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '> div i'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '> div i'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '> div i'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '> div i'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '> div i'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '> div i'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '> div i'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '> div i'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '> div i'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '> div i'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '> div i'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '> div i'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '> div i'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '> div i'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '> div i'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '> div i'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '> div i'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '> div i'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '> div i'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '> div i'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '> div i'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '> div i'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '> div i'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '> div i'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '> div i'),
										),
                                        'IMAGE'  => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '> div img'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '> div img'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '> div img'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '> div img'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '> div img'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '> div img'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '> div img'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '> div img'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '> div img'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '> div img'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '> div img'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '> div img'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '> div img'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '> div img'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '> div img'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '> div img'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '> div img'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '> div img'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '> div img'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '> div img'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '> div img'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '> div img'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '> div img'),
                                        ),
										'BEFORE' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => '> div:before'),
                                            array('property' => 'color', 'label' => 'Color','selector' => '> div:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '> div:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '> div:before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '> div:before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '> div:before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '> div:before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '> div:before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '> div:before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '> div:before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '> div:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '> div:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '> div:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '> div:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '> div:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '> div:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '> div:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '> div:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '> div:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '> div:before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '> div:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '> div:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '> div:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '> div:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '> div:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '> div:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '> div:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '> div:before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '> div:before'),
										),
										'AFTER' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => '> div:after'),
                                            array('property' => 'color', 'label' => 'Color','selector' => '> div:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '> div:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '> div:after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '> div:after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '> div:after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '> div:after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '> div:after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '> div:after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '> div:after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '> div:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '> div:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '> div:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '> div:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '> div:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '> div:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '> div:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '> div:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '> div:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '> div:after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => '> div:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '> div:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '> div:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '> div:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '> div:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '> div:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '> div:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '> div:after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => '> div:after'),
										),
										'HOVER' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '> div:hover'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '> div:hover'),
                                            array('property' => 'opacity', 'label' => 'Before Opacity & Background', 'selector' => '> div:hover:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '> div:hover:before'),
                                            array('property' => 'opacity', 'label' => 'After Opacity & Background', 'selector' => '> div:hover:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '> div:hover:after'),
                                            array('property' => 'color', 'label' => 'Icon Color', 'selector' => '> div:hover i'),
                                            array('property' => 'background-color', 'label' => 'Icon Background', 'selector' => '> div:hover i'),
                                            array('property' => 'margin', 'label' => 'Icon Margin', 'selector' => '> div:hover i'),
                                            array('property' => 'width', 'label' => 'Icon Width', 'selector' => '> div:hover i'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '> div:hover'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '> div:hover'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '> div:hover'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '> div:hover'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '> div:hover'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '> div:hover'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '> div:hover'),
											array('property' => 'custom', 'label' => 'Custom', 'selector' => '> div:hover'),
										),
										'BOXES' => array(
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'background', 'label' => 'Background'),
											array('property' => 'display', 'label' => 'Display'),											
											array('property' => 'width', 'label' => 'Width'),
											array('property' => 'height', 'label' => 'Height'),
											array('property' => 'float', 'label' => 'Float'),
											array('property' => 'position', 'label' => 'Position'),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'margin', 'label' => 'Margin'),
										),
                                        'BOX BEFORE' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => ':before'),
                                            array('property' => 'color', 'label' => 'Color','selector' => ':before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':before'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => ':before'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => ':before'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => ':before'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => ':before'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => ':before'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => ':before'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => ':before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':before'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':before'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => ':before'),
                                        ),
                                        'BOX AFTER' => array(
                                            array('property' => 'content', 'label' => 'Content','selector' => ':after'),
                                            array('property' => 'color', 'label' => 'Color','selector' => ':after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => ':after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => ':after'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => ':after'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => ':after'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => ':after'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => ':after'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => ':after'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => ':after'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => ':after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => ':after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => ':after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => ':after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => ':after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => ':after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => ':after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => ':after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => ':after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => ':after'),
                                            array('property' => 'transition', 'label' => 'Transition', 'selector' => ':after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => ':after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => ':after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => ':after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => ':after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => ':after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => ':after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => ':after'),
                                            array('property' => 'custom', 'label' => 'Custom', 'selector' => ':after'),
                                        ),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_slide_control_content')) {
	function saasmaxcore_slide_control_content($atts, $content = '') {
		extract( $atts );
		$master_class = apply_filters('kc-el-class', $atts);


        if ( 'icon_button'  == $control_type ) {

            if ( !empty( $next_icon ) ) {
                $next = '<div class="navigation_next"><i class="'.esc_attr( $next_icon ).'"></i></div>';
            }else{
                $next = '<div class="navigation_next"><i class="sl sl-arrow-right"></i></div>';
            }
            if ( !empty( $prev_icon ) ) {
                $prev = '<div class="navigation_prev"><i class="'.esc_attr( $prev_icon ).'"></i></div>';
            }else{
                $prev = '<div class="navigation_prev"><i class="sl sl-arrow-left"></i></div>';
            }

        }elseif ( 'text_button'  == $control_type ) {

            if ( !empty( $next_text ) ) {
                $next = '<div class="navigation_next txt_button">'.esc_html( $next_text ).'</i></div>';
            }else{
                $next = '<div class="navigation_next txt_button">'.esc_html__( 'Next', 'saasmaxcore' ).'</div>';
            }
            if ( !empty( $prev_text ) ) {
                $prev = '<div class="navigation_prev txt_button">'.esc_html( $prev_text ).'</div>';
            }else{
                $prev = '<div class="navigation_prev txt_button">'.esc_html__( 'Prev', 'saasmaxcore' ).'</div>';
            }

        }elseif ( 'image_button'  == $control_type ) {

            if ( !empty( $next_image ) ) {
                $icon_url = wp_get_attachment_image_url( $next_image , 'thumbnail' );
                $next = '<div class="navigation_next img_button"><img src="'.esc_url( $icon_url ).'" alt="'.esc_attr__( 'Next', 'saasmaxcore' ).'"></div>';
            }else{
                $next = '<div class="navigation_next"></div>';
            }
            if ( !empty( $prev_image ) ) {
                $icon_url = wp_get_attachment_image_url( $prev_image , 'thumbnail' );
                $prev = '<div class="navigation_prev img_button"><img src="'.esc_url( $icon_url ).'" alt="'.esc_attr__( 'Previous', 'saasmaxcore' ).'"></div>';
            }else{
                $prev = '<div class="navigation_prev"></div>';
            }
        }

        if ( !empty( $control_class_id ) ) {
            $control_class_id = $control_class_id .' .owl-carousel';
        }else{
            $control_class_id = '.owl-carousel';
        }
        $navigation = $prev . $next;

        $script = '
            (function($){
                "use strict";
                $(window).on("load",function(){
                    var owl = jQuery("'.$control_class_id.'");
                    jQuery(".navigation_next").click(function () {
                        owl.trigger("next.owl.carousel");
                    });
                    jQuery(".navigation_prev").click(function () {
                        owl.trigger("prev.owl.carousel", [300]);
                    });
                });
            })(jQuery);
        ';
        wp_add_inline_script( 'saasmaxcore', $script );

		$data = '
		<div class="slide_navigation ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
			'.(isset( $navigation ) ? $navigation : '').'
		</div>';
		return $data;
	}
}
add_shortcode('saasmaxcore_slide_control', 'saasmaxcore_slide_control_content');
?>