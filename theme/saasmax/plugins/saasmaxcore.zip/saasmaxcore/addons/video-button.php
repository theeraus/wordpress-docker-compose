<?php

add_action('init', 'saasmaxcore_video_button_addon', 99);
if (!function_exists('saasmaxcore_video_button_addon')) {
	function saasmaxcore_video_button_addon() {
		if (function_exists('kc_add_map')) {
			kc_add_map(array(
				'saasmaxcore_video_button' => array(
					'name'        => esc_html__('Video Popup Button', 'saasmaxcore'),
					'icon'        => 'et-video',
					'description' => esc_html__('Use this addon for Video Popup.', 'saasmaxcore'),
					'category'    => 'THEME CORE',
					'params'      => array(
						'General' => array(
							array(
								'name'    => 'button_type',
								'label'   => esc_html__('Button Icon', 'saasmaxcore'),
								'type'    => 'select',
								'options' => array(
									'btn_icon' => 'Icon Button',
									'btn_txt'  => 'Text Button',
									'both'  => 'Text With Button',
								),
								'value' => 'btn_icon',
							),
							array(
								'name'     => 'button_icon',
								'label'    => esc_html__('Button Icon', 'saasmaxcore'),
								'type'     => 'icon_picker',
								'value'    => 'flaticon-play-button-1',
								'relation' => array(
							        'parent'    => 'button_type',
							        'show_when' => array('btn_icon','both'),
							    ),
							),
							array(
								'name'     => 'button_text',
								'label'    => esc_html__('Button Text', 'saasmaxcore'),
								'type'     => 'text',
								'relation' => array(
							        'parent'    => 'button_type',
							        'show_when' => array('btn_txt','both')
							    ),
								'value' => 'Watch Video',
							),
							array(
								'name'    => 'channel_type',
								'label'   => esc_html__('Channel Type', 'saasmaxcore'),
								'type'    => 'select',
								'options' => array(
									'youtube' => 'Youtube',
									'vimeo'   => 'Vimeo',
								),
								'value' => 'youtube',
							),
							array(
								'name'  => 'video_id',
								'label' => esc_html__('Video Id', 'saasmaxcore'),
								'type'  => 'text',
								'value' => 'j1S66liv1t8',
							),
							array(
								'name'        => 'custom_class',
								'label'       => esc_html__('Custom Class', 'saasmaxcore'),
								'type'        => 'text',
								'description' => esc_html__('Add your extra custom class.', 'saasmaxcore'),
							),
						),
						'Style' => array(
							array(
								'name'    => 'saasmaxcore_video_button_addon_style',
								'type'    => 'css',
								'options' => array(
									array(
										'screens' => "any,1024,999,767,479",
										'Button'  => array(
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.video-area-popup'),
											array('property' => 'color', 'label' => 'Color', 'selector' => '.video-area-popup'),
											array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.video-area-popup'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.video-area-popup'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.video-area-popup'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.video-area-popup'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.video-area-popup'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.video-area-popup'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.video-area-popup'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.video-area-popup'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.video-area-popup'),
										),
										'Button Hover' => array(
											array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.video-area-popup:hover'),
											array('property' => 'color', 'label' => 'Color', 'selector' => '.video-area-popup:hover'),
											array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.video-area-popup:hover'),
											array('property' => 'background', 'label' => 'Background', 'selector' => '.video-area-popup:hover'),
											array('property' => 'border', 'label' => 'Border', 'selector' => '.video-area-popup:hover'),
											array('property' => 'width', 'label' => 'Width', 'selector' => '.video-area-popup:hover'),
											array('property' => 'height', 'label' => 'Height', 'selector' => '.video-area-popup:hover'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.video-area-popup:hover'),
											array('property' => 'padding', 'label' => 'Padding', 'selector' => '.video-area-popup:hover'),
											array('property' => 'margin', 'label' => 'Margin', 'selector' => '.video-area-popup:hover'),
										),
										'Boxes' => array(
											array('property' => 'text-align', 'label' => 'Text Align'),
											array('property' => 'background', 'label' => 'Background'),
                                            array('property' => 'position', 'label' => 'Position',),
                                            array('property' => 'left', 'label' => 'Left',),
                                            array('property' => 'right', 'label' => 'Right',),
                                            array('property' => 'top', 'label' => 'Top',),
                                            array('property' => 'bottom', 'label' => 'Bottom',),
                                            array('property' => 'transform', 'label' => 'Transform',),
                                            array('property' => 'transition', 'label' => 'Transition',),
                                            array('property' => 'z-index', 'label' => 'Z-Index',),
											array('property' => 'border', 'label' => 'Border'),
											array('property' => 'box-shadow', 'label' => 'Box Shadow'),
											array('property' => 'padding', 'label' => 'Padding'),
											array('property' => 'margin', 'label' => 'Margin'),
										),
									),
								),
							),
						),
					),
				),
			));
		}
	}
}

if (!function_exists('saasmaxcore_video_button_content')) {
	function saasmaxcore_video_button_content($atts, $content = '') {
		extract(shortcode_atts(array(
			'button_type'  => '',
			'button_icon'  => '',
			'button_text'  => '',
			'video_id'     => '',
			'channel_type' => 'youtube',
			'custom_class' => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		$r_id = rand(5655,5874);

		if ( !empty( $button_icon ) ) {
			$button_icon = $button_icon;
		}else{
			$button_icon = 'ti-control-play';
		}

		if ( !empty( $button_text ) ) {
			$button_text = $button_text;
		}else{
			$button_text = 'Watch Video';
		}
		
		if ( !empty( $video_id ) ) {
			$video_id = $video_id;
		}else{
			$video_id = 'j1S66liv1t8';
		}

		if ( !empty( $channel_type ) ) {
			$channel_type = $channel_type;
		}else{
			$channel_type = 'youtube';
		}

		if ( $button_type ==  "btn_icon" ) {
			$video_button = '<span id="video-popup-'.$r_id.'" data-video-id="'.$video_id.'" class="video-area-popup"><i class="'.$button_icon.'"></i></span>';
		}elseif ( $button_type ==  "btn_txt" ){
			$video_button = '<span id="video-popup-'.$r_id.'" data-video-id="'.$video_id.'" class="video-area-popup">'.$button_text.'</span>';
		}elseif($button_type ==  "both"){
			$video_button = '<span id="video-popup-'.$r_id.'" data-video-id="'.$video_id.'" class="video-area-popup"><i class="'.$button_icon.'"></i></span>
			<span>'.$button_text.'</span>';
		}else{
			$video_button = '';
		}

		wp_enqueue_script( 'modal-video' );
		wp_enqueue_style( 'modal-video' );
		$data = '
		<script>
			(function($){
				$(document).on("ready",function(){
				    var $videoModal = $("#video-popup-'.$r_id.'");
				    $videoModal.modalVideo({
				        channel: "'.$channel_type.'"
				    });
				});
			})(jQuery);
		</script>
		<div class="video-promo-button ' . esc_attr(implode(' ', $master_class)) . ' ' . (!empty($custom_class) ? $custom_class : '') . ' ">
			<div class="video-promo-content">
				'.(isset( $video_button ) ? $video_button : '').'
			</div>
		</div>';
		return $data;
	}
}
add_shortcode('saasmaxcore_video_button', 'saasmaxcore_video_button_content');
?>