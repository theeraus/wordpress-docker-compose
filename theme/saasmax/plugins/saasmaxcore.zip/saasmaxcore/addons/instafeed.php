<?php 
add_action('init', 'saasmaxcore_instagram_addon', 99 ); 
if (  !function_exists('saasmaxcore_instagram_addon') ) {
	function saasmaxcore_instagram_addon() { 
		if (function_exists('kc_add_map')){ 
	        kc_add_map(
	            array(
	                'saasmaxcore_instagram' => array(
	                    'name'        => 'Instagram Feed',
	                    'description' => esc_html__('Display Instagram Feed', 'saasmaxcore'),
	                    'icon'        => 'sl-social-instagram',
	                    'category'    => 'THEME CORE',
	                    'params'      => array(
							'Genaral'=> array(
		                        array(
		                            'name'        => 'get_from',
		                            'label'       => esc_html__('Show Feed From','saasmaxcore'),
		                            'type'        => 'select',
		                            'description' => esc_html__('Select the feed shoing option where from you want to show','saasmaxcore'),
		                            'options'     => array(
		                                'user'   => esc_html__('Show Form Default User','saasmaxcore'),
		                                'tagged' => esc_html__('Show Related Tag','saasmaxcore'),
		                            ),
		                        ),
		                        array(
		                            'name'        => 'preffered_tag',
		                            'label'       => esc_html__('Tag Name','saasmaxcore'),
		                            'type'        => 'text',
		                            'description' => esc_html__('Set the tag name which tagged feed you want to show.','saasmaxcore'),
		                            'value'       => 'charity',
		                            'relation'    => array(
		                            	'parent'    => 'get_from',
		                            	'show_when' => 'tagged',
		                            ),
		                        ),
		                        array(
		                            'name'        => 'user_id',
		                            'label'       => esc_html__('User Id','saasmaxcore'),
		                            'type'        => 'text',
		                            'description' => esc_html__('Set the user ID for get instagram feed','saasmaxcore'),
		                            'value'       => '8616541633',
		                        ),
		                        array(
		                            'name'        => 'access_token',
		                            'label'       => esc_html__('Access Token','saasmaxcore'),
		                            'type'        => 'text',
		                            'description' => esc_html__('Paste your access token for get instagram feed.','saasmaxcore'),
		                            'value'       => '8616541633.2a45a81.15ce43649b1c489f989c87e4d7ec8b63',
		                        ),
		                        array(
		                            'name'        => 'show_photos',
		                            'label'       => esc_html__('Show Total Items','saasmaxcore'),
		                            'type'        => 'text',
		                            'description' => esc_html__('Set the value in decimel fow showing images','saasmaxcore'),
		                            'value'       => '10',
		                        ),
		                        array(
		                            'name'        => 'resulation',
		                            'label'       => esc_html__('Posts Order','saasmaxcore'),
		                            'type'        => 'select',
		                            'description' => esc_html__('Select the feed images size','saasmaxcore'),
		                            'options'     => array(
		                                'standard_resolution' => esc_html__('Standard Resolution','saasmaxcore'),
		                                'low_resolution'      => esc_html__('Low Resolution','saasmaxcore'),
		                                'thumbnail'           => esc_html__('Thumbnail','saasmaxcore'),
		                            ),
		                            'value' => 'standard_resolution',
		                        ),		                    
			                    array(
			                        'name'    => 'total_column',
			                        'label'   => esc_html__('Gallery Cloumn','saasmaxcore'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 1,
										'max'        => 6,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the gallery item column max column 6.', 'saasmaxcore'),
			                        'value'       => '3',
			                    ),
			                    array(
			                        'name'    => 'column_gaps',
			                        'label'   => esc_html__('Column Gaps','saasmaxcore'),
			                        'type'    => 'number_slider',
			                        'options' => array(
										'min'        => 0,
										'max'        => 30,
										'show_input' => true
									),
			                        'description' => esc_html__('Set the gallery item gaps between item to item.', 'saasmaxcore'),
			                        'value'       => '10',
			                    ),
							),
							'Style'=> array(
	                            array(
	                                'name'    => 'saasmaxcore_instagram_addon_style',
	                                'type'    => 'css',
	                                'options' => array(
	                                    array(
	                                        "screens"     => "any,1024,999,767,479",
	                                        'Single Item' => array(
	                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-feed-item'),
	                                            array('property' => 'width', 'label' => 'Width', 'selector' => '.single-feed-item'),
	                                            array('property' => 'height', 'label' => 'Height', 'selector' => '.single-feed-item'),
	                                            array('property' => 'display', 'label' => 'Display', 'selector' => '.single-feed-item'),
	                                            array('property' => 'float', 'label' => 'Float', 'selector' => '.single-feed-item'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-feed-item'),
	                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-feed-item'),
	                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-feed-item'),
	                                        ),
	                                        'Boxes' => array(
	                                            array('property' => 'text-align', 'label' => 'Text Align'),
	                                            array('property' => 'border', 'label' => 'Border'),
	                                            array('property' => 'overflow', 'Overflow' => 'Margin'),
	                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
	                                            array('property' => 'padding', 'label' => 'Padding'),
	                                            array('property' => 'margin', 'label' => 'Margin'),
	                                        )
	                                    )
	                                ),
	                            )
							),
		                )
	                ),
	            )
	        ); // KC ADD MAP
	    }
	}
}

// Instagram Shortcode.
function saasmaxcore_instagram_shortcode_content( $atts, $content = '' ) {
	extract(shortcode_atts( array(
		'get_from'      => 'user',
		'preffered_tag' => '',
		'user_id'       => '8616541633',
		'access_token'  => '8616541633.2a45a81.15ce43649b1c489f989c87e4d7ec8b63',
		'show_photos'   => '10',
		'resulation'    => 'standard_resolution',
		'total_column'  => '',
		'column_gaps'   => '',

	), $atts));

	// do shortcode actions here
	$master_class = apply_filters( 'kc-el-class', $atts );

	$instagram_rand_id = rand(753,951);
    wp_enqueue_script( 'instafeed');

	// Colum & Gautter.
	$GLOBALS['total_column'] = $total_column;
	$GLOBALS['column_gaps']  = $column_gaps;

	if ( !function_exists('saasmaxcore_instagram_inline_style') ) {
		function saasmaxcore_instagram_inline_style(){
			wp_register_style( 'gallery-inline-style', false);
			wp_enqueue_style( 'gallery-inline-style' );

			global $total_column;
			global $column_gaps;

			$width    = 100/$total_column;
			$gaps     = $column_gaps/2;
			$main_gap = $column_gaps;

			$data_styles = '
				.core-instagram-feed {
					overflow: hidden;
				}
				.instagram-feed-content{
					margin:-'.$gaps.'px;
					overflow:hidden;
				}
				.single-feed-item{
					width:'.$width.'%;
					padding:'.$gaps.'px;
					float:left;
				}

				@media only screen and (min-width: 1920px) {
					.instagram-feed-content{
						margin:-'.$gaps.'px;
					}
					.single-feed-item{
						width:'.$width.'%;
						padding:'.$gaps.'px;
					}
				}
				@media only screen and (min-width: 992px) and (max-width: 1200px) {
					.instagram-feed-content{
						margin:-'.$gaps.'px;
					}
					.single-feed-item{
						width:'.$width.'%;
						padding:'.$gaps.'px;
					}
				}
				@media (min-width: 768px) and (max-width: 991px) {
					.single-feed-item{
						width:33.333%;
						padding:'.$gaps.'px;
					}
				}
				@media only screen and (max-width: 767px) {
					.single-feed-item{
						width:50%;
					}
				}
			';
			wp_add_inline_style( 'gallery-inline-style', $data_styles );
		}
	}
	/*if ( function_exists('saasmaxcore_instagram_inline_style') ) {
		saasmaxcore_instagram_inline_style();
	}*/
	$instagram_markup = '
	<script>
		(function($){
			jQuery(document).ready(function($){
				var feed = new Instafeed({
					get: \''.$get_from.'\',';
					if( $get_from == 'tagged' ){
						$instagram_markup .= 
						'tagName:\''.$preffered_tag.'\',';   	
					}		        
					$instagram_markup .= '
					userId     : '.$user_id.',
					accessToken: \''.$access_token.'\',
					target: \'instagram-'.$instagram_rand_id.'\',
					limit     : '.$show_photos.',     //max 60 images..
					resolution: \''.$resulation.'\',
					template: \'<div class="single-feed-item"><a href="{{link}}"><img src="{{image}}" /></a></div>\',
					after: function () {
						var el = document.getElementById(\'instagram-'.$instagram_rand_id.'\');
						if (el.classList)
							el.classList.add(\'show\');
						else
							el.className += \' \' + \'show\';
					}
				});
				feed.run();
			});
		})(jQuery);
	</script>';
	$instagram_markup .= '<div class="core-instagram-feed '.esc_attr( implode( ' ', $master_class ) ).'">';
        $instagram_markup .= '<div class="instagram instagram-feed-content" id="instagram-'.$instagram_rand_id.'"></div>';
    $instagram_markup .= '</div>';
	return $instagram_markup ;
}
add_shortcode( 'saasmaxcore_instagram', 'saasmaxcore_instagram_shortcode_content');