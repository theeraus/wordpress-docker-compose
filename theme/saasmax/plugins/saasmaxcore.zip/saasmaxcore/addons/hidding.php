<?php

add_action('init', 'single_hidding_addon' , 99 );
if(!function_exists('single_hidding_addon')){
    function single_hidding_addon(){
       if( function_exists('kc_add_map') ){
           kc_add_map(array(
                'single_hidding' => array(
                    'name'        => esc_html__('Single Hidding Title','saasmaxcore'),
                    'icon'        => 'bi-direction-right',
                    'description' => esc_html__( 'Use this addon for single hidding title.', 'saasmaxcore' ),
                    'category'    => 'THEME CORE',
                    'params'      => array(
                        'General' => array(
                            array(
                                'name'  => 'hidding',
                                'label' => esc_html__('Hidding','saasmaxcore'),
                                'type'  => 'text',
                            ),
                            array(
                                'name'    => 'heading_type',
                                'label'   => esc_html__('Heading Type','saasmaxcore'),
                                'type'    => 'select',
                                'options' => array(
                                    'h1'  => 'H1',
                                    'h2'  => 'H2',
                                    'h3'  => 'H3',
                                    'h4'  => 'H4',
                                    'h5'  => 'H5',
                                    'h6'  => 'H6',
                                    'div' => 'DIV',
                                    'p'   => 'P',
                                ),
                                'value'       => 'h3',
                                'description' => esc_html__('Default Heading: H3','saasmaxcore'),
                            ),
                            array(
                                'name'        => 'custom_class',
                                'label'       => esc_html__('Custom Class','saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__('Add your extra custom any class if you set ( white ) it will get automatically white text color.','saasmaxcore'),
                            ),
                        ),
                        'Style' => array(
                            array(
                                'name'    => 'single_hidding_addon_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        "screens" => "any,1024,999,767,479",
                                        'STYLE'    => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.single_hidding'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single_hidding'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.single_hidding'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.single_hidding'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.single_hidding'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.single_hidding'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.single_hidding'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.single_hidding'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.single_hidding'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.single_hidding'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.single_hidding'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.single_hidding'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.single_hidding'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.single_hidding'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.single_hidding'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.single_hidding'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.single_hidding'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.single_hidding'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.single_hidding'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.single_hidding'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single_hidding'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single_hidding'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single_hidding'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single_hidding'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single_hidding'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single_hidding'),
                                        ),
                                        'BEFORE' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single_hidding:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.single_hidding:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.single_hidding:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.single_hidding:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.single_hidding:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.single_hidding:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.single_hidding:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.single_hidding:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.single_hidding:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.single_hidding:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.single_hidding:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.single_hidding:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single_hidding:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single_hidding:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single_hidding:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single_hidding:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single_hidding:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single_hidding:before'),
                                        ),
                                        'AFTER' => array(
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single_hidding:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.single_hidding:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.single_hidding:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.single_hidding:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.single_hidding:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.single_hidding:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.single_hidding:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.single_hidding:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.single_hidding:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.single_hidding:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.single_hidding:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.single_hidding:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single_hidding:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single_hidding:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single_hidding:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single_hidding:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single_hidding:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.single_hidding:after'),
                                        ),
                                        'BOXES' => array(
                                            array('property' => 'display', 'label' => 'Display'),
                                            array('property' => 'opacity', 'Opacity' => 'Display'),
                                            array('property' => 'width', 'label' => 'WIdth'),
                                            array('property' => 'height', 'label' => 'Height'),
                                            array('property' => 'position', 'label' => 'Text Align'),
                                            array('property' => 'left', 'label' => 'Left'),
                                            array('property' => 'right', 'label' => 'Right'),
                                            array('property' => 'top', 'label' => 'Top'),
                                            array('property' => 'bottom', 'label' => 'Bottom'),
                                            array('property' => 'z-index', 'label' => 'Z-Index'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                            array('property' => 'overflow', 'label' => 'Overflow'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                        'Animate' => array(
                            array(
                                'name'  => 'animate',
                                'label' => esc_html__('Animate','saasmaxcore'),
                                'type'  => 'animate',
                            ),
                        ),
                    ),
                ),
           ));
       }
    }
}

if( ! function_exists('single_hidding_addon_content') ){
    function single_hidding_addon_content( $atts , $content = '' ){
        extract( $atts );        
        $master_class = apply_filters( 'kc-el-class', $atts );

        if( !empty( $heading_type ) ){
            $heading_type = $heading_type;
        }else{
            $heading_type = 'p';
        }

        if( ! empty($hidding) ){
            $hidding = '<'.(isset($heading_type) ? $heading_type : '' ).' class="single_hidding">'.esc_html($hidding).'</'.(isset($heading_type) ? $heading_type : '' ).'>';
        }else{
            $hidding = '';
        }
        
        $data = '
        <div class="hidding-warapper '.esc_attr( implode( ' ', $master_class ) ).' '.( !empty($custom_class) ? $custom_class : '' ).' ">
            '.( isset( $hidding ) ? $hidding : '' ).'
        </div>';
        return $data;
        
    }
}
add_shortcode('single_hidding','single_hidding_addon_content');
?>