<?php

add_action('init', 'saasmaxcore_causes_addon', 99);
if (!function_exists('saasmaxcore_causes_addon')) {
	function saasmaxcore_causes_addon() {
		if (function_exists('kc_add_map')) {
		    kc_add_map(
		        array(	 
		            'saasmaxcore_causes' => array(
		                'name'        => esc_html__('Single Causes','saasmaxcore'),
		                'description' => esc_html__('Use this addon for show single causes.', 'saasmaxcore'),
		                'icon'        => 'et-megaphone',
		                'category'    => 'THEME CORE',
		                'params'      => array(
		                	'Genaral' => array(
			                    array(
			                        'name'        => 'causes_thumb',
			                        'label'       => esc_html__('Causes Thumbnail','saasmaxcore'),
			                        'type'        => 'attach_image',
			                        'description' => esc_html__('Set the causes thumbnail image.', 'saasmaxcore')
			                    ),
			                    array(
			                        'name'        => 'causes_title',
			                        'label'       => esc_html__('Causes Title','saasmaxcore'),
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the causes title.', 'saasmaxcore')
			                    ),
			                    array(
			                        'name'        => 'causes_description',
			                        'label'       => esc_html__('Causes Description','saasmaxcore'),
			                        'type'        => 'textarea',
			                        'description' => esc_html__('Set the causes description.', 'saasmaxcore')
			                    ),
			                    array(
			                        'name'        => 'causes_category',
			                        'label'       => esc_html__('Causes Category','saasmaxcore'),
			                        'type'        => 'text',
			                        'description' => esc_html__('Set the causes category.', 'saasmaxcore')
			                    ),
			                    array(
			                        'name'        => 'enable_link',
			                        'label'       => esc_html__('Set Link','saasmaxcore'),
			                        'type'        => 'toggle',
			                        'value'       => 'no',
			                        'description' => esc_html__('If you want set custom link you can check.', 'saasmaxcore')
			                    ),
			                    array(
			                        'name'        => 'causes_link',
			                        'label'       => esc_html__('Event Link','saasmaxcore'),
			                        'type'        => 'link',
			                        'value'       => 'http://example.com',
			                        'description' => esc_html__('If you want set custom link you can check.', 'saasmaxcore'),
			                        'relation'    => array(
			                        	'parent'    => 'enable_link',
			                        	'show_when' => 'yes',
			                        ),
			                    ),
			                    array(
			                        'name'        => 'custom_class',
			                        'label'       => esc_html__('Custom Class','saasmaxcore'),
			                        'type'        => 'text',
			                        'description' => esc_html__('Add your extra custom class.', 'saasmaxcore')
			                    ),
		                	),
		                	'Progress' => array(
								array(
									'type'        => 'text',
									'label'       => esc_html__('Raised Text','saasmaxcore'),
									'name'        => 'raised_text',
									'description' => esc_html__('Set the raised text.','saasmaxcore'),
									'value'       => 'Funded',
								),
								array(
									'label'       => esc_html__('Progress Percent','saasmaxcore'),
									'name'        => 'progress_percent',
									'description' => esc_html__('Set the prgoress percent value in integer.','saasmaxcore'),
									'type'        => 'number_slider',
									'options'     => array(
										'min'        => 0,
										'max'        => 100,
										'unit'       => '%',
										'show_input' => true
									),
									'value' => '10%',
								),
								array(
									'type'        => 'color_picker',
									'label'       => esc_html__('Progressbar Color','saasmaxcore'),
									'name'        => 'progress_color',
									'description' => esc_html__('Set the progress color.','saasmaxcore'),
									'value'       => '#f85d1c',
								),
								array(
									'type'        => 'color_picker',
									'label'       => esc_html__('Progress Background','saasmaxcore'),
									'name'        => 'progress_bg',
									'description' => esc_html__('Set the progress background color.','saasmaxcore'),
									'value'       => '#f3f3f3',
								),
		                	),
		                	'Style'	=>	array(
								array(
			                		'name'    => 'saasmaxcore_causes_addon_style',
			                		'type'    => 'css',
			                		'options' => array(
										array(
											'screens'    => "any,1024,999,767,479",
											'Typography' => array(
												array('property' => 'color', 'label' => 'Color'),
												array('property' => 'background'),
												array('property' => 'font-size', 'label' => 'Font Size'),
												array('property' => 'font-weight', 'label' => 'Font Weight'),
												array('property' => 'font-style', 'label' => 'Font Style'),
												array('property' => 'font-family', 'label' => 'Font Family'),
												array('property' => 'text-align', 'label' => 'Text Align'),
												array('property' => 'text-shadow', 'label' => 'Text Shadow'),
												array('property' => 'text-transform', 'label' => 'Text Transform'),
												array('property' => 'text-decoration', 'label' => 'Text Decoration'),
												array('property' => 'line-height', 'label' => 'Line Height'),
												array('property' => 'letter-spacing', 'label' => 'Letter Spacing'),
												array('property' => 'overflow', 'label' => 'Overflow'),
												array('property' => 'word-break', 'label' => 'Word Break'),					
											),
											'Category' => array(
												array('property' => 'color', 'label' => 'Color', 'selector' => '.causes_category'),
												array('property' => 'background', 'label' => 'Background', 'selector' => '.causes_category'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.causes_category'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.causes_category'),
											),
											'Causes Details' => array(
												array('property' => 'color', 'label' => 'Color', 'selector' => '.causes-details'),
												array('property' => 'border', 'label' => 'Border', 'selector' => '.causes-details'),
												array('property' => 'background', 'label' => 'Background', 'selector' => '.causes-details'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.causes-details'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.causes-details'),
											),
											'Title' => array(
												array('property' => 'color', 'label' => 'Color', 'selector' => '.causes_title'),
												array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.causes_title'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.causes_title'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.causes_title'),
											),
											'Progressbar' => array(
												array('property' => 'height', 'label' => 'Height', 'selector' => '.causes-goal'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.causes-goal'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.causes-goal'),
											),
											'Raised Container' => array(
												array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.raised_fund_and_contribute'),
												array('property' => 'color', 'label' => 'Color', 'selector' => '.raised_fund_and_contribute'),
												array('property' => 'display', 'label' => 'Display', 'selector' => '.raised_fund_and_contribute'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.raised_fund_and_contribute'),
                                            ),
											'Raised Text' => array(
												array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.raised_fund_and_contribute .raised'),
												array('property' => 'color', 'label' => 'Color', 'selector' => '.raised_fund_and_contribute .raised'),
												array('property' => 'display', 'label' => 'Display', 'selector' => '.raised_fund_and_contribute .raised'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.raised_fund_and_contribute .raised'),
											),
											'Raised Percent' => array(
												array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.raised_fund_and_contribute .raised span'),
												array('property' => 'color', 'label' => 'Color', 'selector' => '.raised_fund_and_contribute .raised span'),
												array('property' => 'margin', 'label' => 'Margin', 'selector' => '.raised_fund_and_contribute .raised span'),
											),
											'Button' => array(
												array('property' => 'color', 'label' => 'Color', 'selector' => '.raised_fund_and_contribute .contribute'),
												array('property' => 'background', 'label' => 'Background', 'selector' => '.raised_fund_and_contribute .contribute'),
												array('property' => 'border', 'label' => 'Border', 'selector' => '.raised_fund_and_contribute .contribute'),
												array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.raised_fund_and_contribute .contribute'),
												array('property' => 'padding', 'label' => 'Padding', 'selector' => '.raised_fund_and_contribute .contribute'),
											),
											'Button Hover' => array(
												array('property' => 'color', 'label' => 'Color', 'selector' => '.raised_fund_and_contribute .contribute:hover'),
												array('property' => 'background', 'label' => 'Background', 'selector' => '.raised_fund_and_contribute .contribute:hover'),
												array('property' => 'border', 'label' => 'Border', 'selector' => '.raised_fund_and_contribute .contribute:hover'),
												array('box-shadow', 'label' => 'Box Shadow', 'selector' => '.raised_fund_and_contribute .contribute:hover'),
											),
											'Box' => array(
												array('property' => 'background', 'label' => 'Background'),
												array('property' => 'width', 'label' => 'Width'),
												array('property' => 'height', 'label' => 'Height'),
												array('property' => 'box-shadow', 'label' => 'Box Shadow'),
												array('property' => 'border', 'label' => 'Border'),
												array('property' => 'border-radius', 'label' => 'Border Radius'),
												array('property' => 'float', 'label' => 'Float'),
												array('property' => 'display', 'label' => 'Display'),
												array('property' => 'margin', 'label' => 'Margin'),
												array('property' => 'padding', 'label' => 'Padding'),
											),
										),
									)
								),
		                	),
		                ),
		            ),  // End of elemnt kc_icon 	 
		        )
		    ); // End add map

		}
	}
}

if (!function_exists('saasmaxcore_causes_addon_content')) {
	function saasmaxcore_causes_addon_content($atts, $content = '') {
		$allvalue = extract(shortcode_atts(array(
			'causes_thumb'       => '',
			'causes_title'       => '',
			'causes_description' => '',
			'causes_category'    => '',
			'raised_text'        => '',
			'progress_percent'   => '',
			'progress_bg'        => '',
			'progress_color'     => '',
			'enable_link'        => '',
			'causes_link'        => '',
			'custom_class'       => '',
		), $atts));

		$master_class = apply_filters('kc-el-class', $atts);

		$r_id = rand(5655,5874);

		if ( !empty( $causes_thumb ) ) {
			$causes_thumb = '<div class="causes_thumb"><img src="'.esc_url( wp_get_attachment_image_url( $causes_thumb, 'large') ).'" alt=""></div>';
		}else{
			$causes_thumb = '';
		}

		if ( !empty( $causes_link ) ) {
			$link = explode('|', $causes_link);
		}
		

		if ( $enable_link == 'yes' && !empty( $causes_title ) ) {
			$causes_title = '<h3 class="causes_title"><a href="'.esc_url($link[0]).'"  '.( isset($link[2]) ? 'target="'.$link[2].'"' : '' ).'>'.esc_html( $causes_title ).'</a></h3>';
			$causes_button = '<a href="'.esc_url($link[0]).'" class="contribute" '.( isset($link[2]) ? 'target="'.$link[2].'"' : '' ).'>'.esc_html( $link[1] ).'</a>';

		}elseif( !empty( $causes_title ) ){
			$causes_title = '<h3 class="causes_title">'.esc_html( $causes_title ).'</h3>';
		}else{
			$causes_title = '';
		}
		
		if( !empty( $causes_description ) ){
			$causes_description = '<div class="causes_description">'.wpautop( esc_html( $causes_description ) ).'</div>';
		}else{
			$causes_description = '';
		}

		if ( !empty( $causes_category ) ) {
			$causes_category = '<div class="causes_category">'.esc_html( $causes_category ).'</div>';
		}else{
			$causes_category = '';
		}

		if ( !empty( $progress_percent ) ) {
			if ( !empty( $progress_color ) ) {
				$progress_color = $progress_color;
			}else{
				$progress_color = '';
			}
			if ( !empty( $progress_bg ) ) {
				$progress_bg = $progress_bg;
			}else{
				$progress_bg = '';
			}

			$progressbar = '
			<div class="causes-goal" style="background-color:'.$progress_bg.';">
				<div class="goal-status" data-progress-animation="'.$progress_percent.'" style="background-color:'.$progress_color.';"></div>
			</div>';
		}else{
			$progressbar = '';
		}

		$raised_warapper = '
		<div class="raised_fund_and_contribute">';
			if ( !empty( $raised_text ) ) {
				$raised_text = '<div class="raised"><span>'.$progress_percent.'</span> '.$raised_text.'</div>';
			}else{
				$raised_text = '';
			}
			$raised_warapper .= $raised_text.$causes_button;
		$raised_warapper .='
		</div>';

		$data = '
		<div class="single-causes-two '.esc_attr( implode(' ', $master_class) ).' '.(isset( $custom_class ) ? $custom_class : '').'">
			'.( isset( $causes_thumb ) ? $causes_thumb : '' ).'
			<div class="causes-details">
			'.( isset( $causes_category ) ? $causes_category : '' ).'
			'.( isset( $causes_title ) ? $causes_title : '' ).'
			'.( isset( $causes_description ) ? $causes_description : '' ).'
			'.( isset( $progressbar ) ? $progressbar : '' ).'
			'.( isset( $raised_warapper ) ? $raised_warapper : '' ).'
			</div>
		</div>';

		return $data;
	}
}
add_shortcode('saasmaxcore_causes', 'saasmaxcore_causes_addon_content');
?>