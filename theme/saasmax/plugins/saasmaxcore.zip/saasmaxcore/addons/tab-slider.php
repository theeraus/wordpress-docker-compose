<?php

add_action('init', 'saasmaxcore_tab_slider_addon' , 99 );
if(!function_exists('saasmaxcore_tab_slider_addon')){
    function saasmaxcore_tab_slider_addon(){
       if( function_exists('kc_add_map') ){
           kc_add_map(array(
                'saasmaxcore_tab_slider' => array(
                    'name'        => esc_html__('Tab Image Slider','saasmaxcore'),
                    'icon'        => 'et-browser',
                    'description' => esc_html__( 'Use this addon tab content and image slider.', 'saasmaxcore' ),
                    'category'    => 'THEME CORE',
                    'params'      => array(
                        'General' => array(
                            array(
                                'name'       => 'tab_slides',
                                'label'      => esc_html__('Tab Image Slides','saasmaxcore'),
                                'type'       => 'group',
                                'options'    => array('add_text' => esc_html__('Add New Tab', 'saasmaxcore')),
                                'descriptin' => esc_html__( 'click add new and add one by one single tab details.', 'saasmaxcore' ),
                                'params'     => array(
                                    array(
                                        'name'  => 'thumb',
                                        'label' => esc_html__('Upload Tab Tamb','saasmaxcore'),
                                        'type'  => 'attach_image',
                                    ),
                                    array(
                                        'name'        => 'title',
                                        'label'       => esc_html__('Title','saasmaxcore'),
                                        'type'        => 'text',
                                        'description' => esc_html__('Set the title.','saasmaxcore'),
                                    ),
                                    array(
                                        'name'    => 'heading_type',
                                        'label'   => esc_html__('Heading Type','saasmaxcore'),
                                        'type'    => 'select',
                                        'options' => array(
                                            'h1'  => 'H1',
                                            'h2'  => 'H2',
                                            'h3'  => 'H3',
                                            'h4'  => 'H4',
                                            'h5'  => 'H5',
                                            'h6'  => 'H6',
                                            'div' => 'DIV',
                                            'p'   => 'P',
                                        ),
                                        'value'       => 'h3',
                                        'description' => esc_html__('Default Heading: H3','saasmaxcore'),
                                    ),
                                    array(
                                        'name'  => 'subtitle',
                                        'label' => esc_html__('Sub Title','saasmaxcore'),
                                        'type'  => 'text',
                                    ),
                                    array(
                                        'name'  => 'description',
                                        'label' => esc_html__('Tab Descripton','saasmaxcore'),
                                        'type'  => 'textarea',
                                    ),
                                ),
                            ),
                            array(
                                'name'        => 'custom_class',
                                'label'       => esc_html__('Custom Class','saasmaxcore'),
                                'type'        => 'text',
                                'description' => esc_html__('Add your extra custom class.','saasmaxcore'),
                            ),
                        ),
						'Options' => array(
							array(
								'name'        => 'content_align',
								'label'       => esc_html__('Slide Content Position', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set slide content position left or right.', 'saasmaxcore'),
								'options'     => array(
									'left_content'  => esc_html('Left Content','saasmaxcore'),
									'right_content' => esc_html('Right Content','saasmaxcore'),
								),
								'value' => 'right_content',
							),
							array(
								'name'        => 'item_on_large',
								'label'       => esc_html__('Item On Large Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on large device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 10,
									'show_input' => true
								),
								'value' => '4',
							),
							array(
								'name'        => 'item_on_medium',
								'label'       => esc_html__('Item On Medium Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on medium device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 10,
									'show_input' => true
								),
								'value' => '3',
							),
							array(
								'name'        => 'item_on_tablet',
								'label'       => esc_html__('Item On Tablet Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on tablet device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 10,
									'show_input' => true
								),
								'value' => '2',
							),
							array(
								'name'        => 'item_on_mobile',
								'label'       => esc_html__('Item On Mobile Device', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide item on mobile device', 'saasmaxcore'),
								'options'     => array(
									'min'        => 1,
									'max'        => 10,
									'show_input' => true
								),
								'value' => '1',
							),
							array(
								'name'        => 'autoplay',
								'label'       => esc_html__('Slide Autoplay', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set slide autoplay yes or no.', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'false',
							),
							array(
								'name'        => 'autoplaytimeout',
								'label'       => esc_html__('Autoplay Timeout', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide autoplay timeout', 'saasmaxcore'),
								'options'     => array(
									'min'        => 500,
									'max'        => 10000,
									'show_input' => true
								),
								'value' => '2000',
							),
							array(
								'name'        => 'slide_speed',
								'label'       => esc_html__('Slide Speed', 'saasmaxcore'),
								'type'        => 'number_slider',
								'description' => esc_html__('Please set slide speed', 'saasmaxcore'),
								'options'     => array(
									'min'        => 500,
									'max'        => 5000,
									'show_input' => true
								),
								'value' => '500',
							),
							array(
								'name'        => 'loop',
								'label'       => esc_html__('Slide Loop', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider loop yes or no', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'false',
							),
							array(
								'name'        => 'nav',
								'label'       => esc_html__('Slide Navigaion', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider navigation', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'true',
							),
							array(
								'name'        => 'nav_next_icon',
								'label'       => esc_html__('Navigaion Next Icon', 'saasmaxcore'),
								'type'        => 'icon_picker',
								'description' => esc_html__('Please set the slider navigation next icon.', 'saasmaxcore'),
								'relation'    => array(
									'show_when' => 'true',
									'parent'    => 'nav',
								),

								'value' => 'sl sl-arrow-right',
							),
							array(
								'name'        => 'nav_prev_icon',
								'label'       => esc_html__('Navigaion Prev Icon', 'saasmaxcore'),
								'type'        => 'icon_picker',
								'description' => esc_html__('Please set the slider navigation prev icon.', 'saasmaxcore'),
								'relation'    => array(
									'show_when' => 'true',
									'parent'    => 'nav',
								),

								'value' => 'sl sl-arrow-left',
							),
							array(
								'name'        => 'center',
								'label'       => esc_html__('Slide Center', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set if need slider center mode.', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'false',
							),
							array(
								'name'        => 'vertical',
								'label'       => esc_html__('Slide Vertially', 'saasmaxcore'),
								'type'        => 'select',
								'description' => esc_html__('Please set the slider vertically', 'saasmaxcore'),
								'options'     => array(
									'true'  => esc_html('Yes','saasmaxcore'),
									'false' => esc_html('No','saasmaxcore'),
								),
								'value' => 'true',
							),
						),
                        'Style' => array(
                            array(
                                'name'    => 'saasmaxcore_tab_slider_addon_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        "screens"          => "any,1024,999,767,479",
                                        'Details Warapper' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.single-event-list-content'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.single-event-list-content'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.single-event-list-content'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.single-event-list-content'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-event-list-content'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.single-event-list-content'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.single-event-list-content'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.single-event-list-content'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.single-event-list-content'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.single-event-list-content'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single-event-list-content'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-event-list-content'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-event-list-content'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-event-list-content'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-event-list-content'),
                                        ),
                                        'Title' => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.tab_title'),
                                            array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.tab_title'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.tab_title'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.tab_title'),
                                            array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.tab_title'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.tab_title'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.tab_title'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.tab_title'),
                                            array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.tab_title'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.tab_title'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.tab_title'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.tab_title'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.tab_title'),
                                        ),
                                        'Subtitle'    => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.tab_subtitle'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.tab_subtitle'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.tab_subtitle'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.tab_subtitle'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.tab_subtitle'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.tab_subtitle'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.tab_subtitle'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.tab_subtitle'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.tab_subtitle'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.tab_subtitle'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.tab_subtitle'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.tab_subtitle'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.tab_subtitle'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.tab_subtitle'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.tab_subtitle'),
                                        ),
                                        'Image'    => array(
                                            array('property' => 'color', 'label' => 'Color','selector' => '.single-event-list-thumb img'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.single-event-list-thumb img'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.single-event-list-thumb img'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.single-event-list-thumb img'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.single-event-list-thumb img'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.single-event-list-thumb img'),
                                        ),
                                        'Boxes' => array(
                                            array('property' => 'text-align', 'label' => 'Text Align'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
           ));
       }
    }
}

if( ! function_exists('saasmaxcore_tab_slider_content') ){
    function saasmaxcore_tab_slider_content( $atts , $content = '' ){
        extract( $atts );
        $master_class = apply_filters( 'kc-el-class', $atts );

        $image_array   = array();
        $content_array = array();
        foreach ( $tab_slides as $slide_values ) {

            extract($content = array(
                'title'        => $slide_values->title,
                'heading_type' => $slide_values->heading_type,
                'subtitle'     => $slide_values->subtitle,
                'description'  => $slide_values->description,
            ));

            if( !empty( $heading_type ) ){
                $heading = $heading_type;
            }else{
                $heading = 'p';
            }

            if( ! empty($title) ){
                $title = '<'.(isset($heading) ? $heading : '' ).' class="tab_title">'.esc_html($title).'</'.(isset($heading) ? $heading : '' ).'>';
            }else{
                $title = '';
            }
            
            if( !empty($subtitle) ){
                $subtitle = '<div class="tab_subtitle">'.esc_html($subtitle).'</div>';
            }else{
                $subtitle = '';
            }
            
            if( !empty($description) ){
                $description = '<div class="tab_description">'.wpautop(esc_html($description)).'</div>';
            }else{
                $description = '';
            }

            $image_array[]='<div class="single-event-list-thumb"><img src="'.wp_get_attachment_image_url( $slide_values->thumb, 'full' ).'" alt="'.get_the_title( $slide_values->thumb ).'"></div>';
            $content_array[]='<div class="single-event-list-content">
                                '.(isset($title) ? $title : '' ).
                                (isset($subtitle) ? $subtitle : '' ).
                                (isset($description) ? $description : '' ).'</div>';
        }

        wp_enqueue_script( 'owl-carousel' );
        wp_enqueue_style( 'owl-carousel' );
        wp_enqueue_script( 'slick' );
        wp_enqueue_style( 'slick' );

        $data = '
        <script>
            (function($){
                $(document).ready(function(){
                    /*-----------------------------
                        EVENT SLICK ACTIVE
                    -----------------------------*/
                    var eventSlickList = $(".event-list-content");
                    if (eventSlickList.length > 0) {
                        eventSlickList.slick({
                            dots           : false,
                            arrows         : false,
                            infinite       : '.$loop.',
                            focusOnSelect  : true,
                            vertical       : '.$vertical.',
                            verticalSwiping: '.$vertical.',
                            centerMode     : '.$center.',
                            autoplay       : '.$autoplay.',
                            autoplaySpeed  : '.$autoplaytimeout.',
                            asNavFor       : ".event-list-thumbs",
                            speed          : '.$slide_speed.',
                            slidesToShow   : '.$item_on_large.',
                            slidesToScroll : 1,
                            responsive     : [{
                                breakpoint: 1200,
                                settings  : {
                                    slidesToShow  : '.$item_on_medium.',
                                    slidesToScroll: 1,
                                }
                            }, {
                                breakpoint: 992,
                                settings  : {
                                    slidesToShow  : '.$item_on_tablet.',
                                    slidesToScroll: 1
                                }
                            }, {
                                breakpoint: 768,
                                settings  : {
                                    slidesToShow  : '.$item_on_mobile.',
                                    slidesToScroll: 1
                                }
                            }]
                        });
                    }
                    /*---------------------------
                        EVENT THUMBS SLIDER
                    -----------------------------*/
                    var eventThumbsSlider = $(".event-list-thumbs");
                    eventThumbsSlider.slick({
                        dots     : false,
                        arrows   : '.$nav.',
                        infinite : '.$loop.',
                        asNavFor : ".event-list-content",
                        prevArrow: \'<div class="slick-prev" style=""><i class="'.$nav_prev_icon.'"></i></div>\',
                        nextArrow:\'<div class="slick-next" style=""><i class="'.$nav_next_icon.'"></i></div>\',
                        speed         : '.$slide_speed.',
                        slidesToShow  : 1,
                        slidesToScroll: 1,
                        responsive    : [
                            {
                            breakpoint: 1024,
                            settings  : {
                                    slidesToShow  : 1,
                                    slidesToScroll: 1
                                }
                            },{
                            breakpoint: 600,
                            settings  : {
                                    slidesToShow  : 1,
                                    slidesToScroll: 1
                                }
                            },{
                            breakpoint: 480,
                            settings  : {
                                    slidesToShow  : 1,
                                    slidesToScroll: 1
                                }
                            }
                        ]
                    });
                })
            })(jQuery);
        </script>
        <div class="tab_slider '.esc_attr( implode( ' ', $master_class ) ).' '.( !empty($custom_class) ? $custom_class : '' ).' ">
            <div class="row '.esc_attr( $content_align ).'">
                <div class="col-md-6 col-sm-6">
                    <div class="event-list-content">
                        '.implode(' ',$content_array).'
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="event-list-thumbs">
                        '.implode(' ',$image_array).'
                    </div>
                </div>
            </div>
        </div>';
        return $data;
    }
}
add_shortcode('saasmaxcore_tab_slider','saasmaxcore_tab_slider_content');
?>