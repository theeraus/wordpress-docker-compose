<?php

add_action('init', 'area_bg_addon' , 99 );
if(!function_exists('area_bg_addon')){
    function area_bg_addon(){
       if( function_exists('kc_add_map') ){
           kc_add_map(array(
                'area_bg' => array(
                    'name'        => esc_html__('Area Background','saasmaxcore'),
                    'icon'        => 'bi-color-plate',
                    'description' => esc_html__( 'Use this addon for area background style.', 'saasmaxcore' ),
                    'category'    => 'THEME CORE',
                    'params'      => array(
                        'Style' => array(
                            array(
                                'name'    => 'area_bg_addon_style',
                                'type'    => 'css',
                                'options' => array(
                                    array(
                                        "screens" => "any,1024,999,767,479",
                                        'STYLE'    => array(
                                            array('property' => 'background-image', 'label' => 'Linear Gradient', 'selector' => '.area_bg'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.area_bg'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.area_bg'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.area_bg'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.area_bg'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.area_bg'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.area_bg'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.area_bg'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.area_bg'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.area_bg'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.area_bg'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.area_bg'),
                                            array('property' => 'transform-origin', 'label' => 'Transform Origin', 'selector' => '.area_bg'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.area_bg'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_bg'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.area_bg'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_bg'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_bg'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_bg'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.area_bg'),
                                        ),
                                        'BEFORE' => array(
                                            array('property' => 'background-image', 'label' => 'Linear Gradient', 'selector' => '.area_bg:before'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.area_bg:before'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.area_bg:before'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.area_bg:before'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.area_bg:before'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.area_bg:before'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.area_bg:before'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.area_bg:before'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.area_bg:before'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.area_bg:before'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.area_bg:before'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.area_bg:before'),
                                            array('property' => 'transform-origin', 'label' => 'Transform Origin', 'selector' => '.area_bg:before'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.area_bg:before'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_bg:before'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.area_bg:before'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_bg:before'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_bg:before'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_bg:before'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.area_bg:before'),
                                        ),
                                        'AFTER' => array(
                                            array('property' => 'background-image', 'label' => 'Linear Gradient', 'selector' => '.area_bg:after'),
                                            array('property' => 'background', 'label' => 'Background', 'selector' => '.area_bg:after'),
                                            array('property' => 'opacity', 'label' => 'Opacity', 'selector' => '.area_bg:after'),
                                            array('property' => 'display', 'label' => 'Display','selector' => '.area_bg:after'),
                                            array('property' => 'width', 'label' => 'WIdth','selector' => '.area_bg:after'),
                                            array('property' => 'height', 'label' => 'Height','selector' => '.area_bg:after'),
                                            array('property' => 'position', 'label' => 'Position', 'selector' => '.area_bg:after'),
                                            array('property' => 'left', 'label' => 'Left', 'selector' => '.area_bg:after'),
                                            array('property' => 'right', 'label' => 'Right', 'selector' => '.area_bg:after'),
                                            array('property' => 'top', 'label' => 'Top', 'selector' => '.area_bg:after'),
                                            array('property' => 'bottom', 'label' => 'Bottom', 'selector' => '.area_bg:after'),
                                            array('property' => 'transform', 'label' => 'Transform', 'selector' => '.area_bg:after'),
                                            array('property' => 'transform-origin', 'label' => 'Transform Origin', 'selector' => '.area_bg:after'),
                                            array('property' => 'z-index', 'label' => 'Z-Index', 'selector' => '.area_bg:after'),
                                            array('property' => 'border', 'label' => 'Border', 'selector' => '.area_bg:after'),
                                            array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.area_bg:after'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow', 'selector' => '.area_bg:after'),
                                            array('property' => 'padding', 'label' => 'Padding', 'selector' => '.area_bg:after'),
                                            array('property' => 'margin', 'label' => 'Margin', 'selector' => '.area_bg:after'),
                                            array('property' => 'overflow', 'label' => 'Overflow', 'selector' => '.area_bg:after'),
                                        ),
                                        'BOXES' => array(
                                            array('property' => 'opacity', 'label' => 'Opacity'),
                                            array('property' => 'display', 'label' => 'Display'),
                                            array('property' => 'width', 'label' => 'WIdth'),
                                            array('property' => 'height', 'label' => 'Height'),
                                            array('property' => 'position', 'label' => 'Text Align'),
                                            array('property' => 'left', 'label' => 'Left'),
                                            array('property' => 'right', 'label' => 'Right'),
                                            array('property' => 'top', 'label' => 'Top'),
                                            array('property' => 'bottom', 'label' => 'Bottom'),
                                            array('property' => 'transform', 'label' => 'Transform'),
                                            array('property' => 'transform-origin', 'label' => 'Transform Origin'),
                                            array('property' => 'z-index', 'label' => 'Z-Index'),
                                            array('property' => 'border', 'label' => 'Border'),
                                            array('property' => 'box-shadow', 'label' => 'Box Shadow'),
                                            array('property' => 'padding', 'label' => 'Padding'),
                                            array('property' => 'margin', 'label' => 'Margin'),
                                            array('property' => 'overflow', 'label' => 'Overflow'),
                                        ),
                                        'CUSTOM' => array(
                                            array('property' => 'custom', 'label' => 'Custom'),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
           ));
       }
    }
}

if( ! function_exists('area_bg_addon_content') ){
    function area_bg_addon_content( $atts , $content = '' ){
        extract( $atts );        
        $master_class = apply_filters( 'kc-el-class', $atts );

        
        $data = '
        <div class="area-bg-warapper '.esc_attr( implode( ' ', $master_class ) ).' '.( !empty($custom_class) ? $custom_class : '' ).' ">
            <div class="area_bg"></div>
        </div>';
        return $data;
        
    }
}
add_shortcode('area_bg','area_bg_addon_content');
?>